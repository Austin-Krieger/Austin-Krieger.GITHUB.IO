local old_SBDFT_init = EquipmentsTweakData.init

function EquipmentsTweakData:init(tweak_data)
    old_SBDFT_init(self, tweak_data)
	self.sentry_gun = {
		deploy_time = 0,
		dummy_unit = "units/payday2/equipment/gen_equipment_sentry/gen_equipment_sentry_dummy",
		text_id = "debug_sentry_gun",
		use_function_name = "use_sentry_gun",
		unit = 1,
		min_ammo_cost = 0,
		ammo_cost = 0,
		visual_object = "g_sentrybag",
		icon = "equipment_sentry",
		description_id = "des_sentry_gun",
		quantity = {500},
		upgrade_deploy_time_multiplier = {
			upgrade = "sentry_gun_deploy_time_multiplier",
			category = "player"
		}
	}
	self.sentry_gun_silent = {
		deploy_time = 0,
		dummy_unit = "units/payday2/equipment/gen_equipment_sentry/gen_equipment_sentry_dummy",
		text_id = "debug_sentry_gun",
		use_function_name = "use_sentry_gun",
		unit = 2,
		min_ammo_cost = 0,
		ammo_cost = 0,
		visual_object = "g_sentrybag",
		icon = "equipment_sentry_silent",
		description_id = "des_sentry_gun",
		quantity = {500},
		upgrade_deploy_time_multiplier = {
			upgrade = "sentry_gun_deploy_time_multiplier",
			category = "player"
		},
		upgrade_name = {"sentry_gun"}
	}
	self.bodybags_bag = {
		deloy_time = 0,
		dummy_unit = "units/payday2/equipment/gen_equipment_bodybags_bag/gen_equipment_bodybags_bag_dummy",
		text_id = "debug_equipment_bodybags_bag",
		use_function_name = "use_bodybags_bag",
		unit = 3,
		visual_object = "g_bodybagsbag",
		icon = "equipment_bodybags_bag",
		quantity = {500}
	}
	self.doctor_bag = {
		deloy_time = 0,
		dummy_unit = "units/payday2/equipment/gen_equipment_medicbag/gen_equipment_medicbag",
		text_id = "debug_doctor_bag",
		use_function_name = "use_doctor_bag",
		unit = 4,
		visual_object = "g_medicbag",
		icon = "equipment_doctor_bag",
		quantity = {500}
	}
	
	-- Also increased ammo bag count, but doesn't seem to work consistently
	--self.ammo_bag = {
	--	deloy_time = 0,
	--	dummy_unit = "units/payday2/equipment/gen_equipment_ammobag/gen_equipment_ammobag",
	--	text_id = "debug_ammo_bag",
	--	use_function_name = "use_ammo_bag",
	--	unit = 5,
	--	visual_object = "g_ammo_bag",
	--	icon = "equipment_ammo_bag",
	--	description_id = "des_ammo_bag",
	--	quantity = {500}
	--}
	
	-- More Ammo Bags / Armor Kits / First Aid Kits / Trip Mines
	self.ammo_bag.quantity = {500}
	self.armor_kit.quantity = {500}
	self.first_aid_kit.quantity = {500}
	self.trip_mine.quantity = {500, 500}
	
	-- More Cable Ties
	self.specials.cable_tie.quantity = 999
	self.specials.cable_tie.max_quantity = 999
end