local old_ptd_init = PlayerTweakData.init

function PlayerTweakData:init(tweak_data)
	old_ptd_init(self, tweak_data)
	-- Increased Following Hostages
	self.max_nr_following_hostages = 100
	
	-- Mask Up Faster or Instantly
	self.put_on_mask_time = 0.5
	
	-- Increased movement speed
	self.movement_state.standard.movement.speed.STANDARD_MAX = 450 -- 700
	self.movement_state.standard.movement.speed.RUNNING_MAX = 650 -- 1150
	self.movement_state.standard.movement.speed.CROUCHING_MAX = 250
	self.movement_state.standard.movement.speed.STEELSIGHT_MAX = 450 -- 1150
	self.movement_state.standard.movement.speed.INAIR_MAX = 650
	self.movement_state.standard.movement.speed.CLIMBING_MAX = 450 -- 1150 seemed like a bit much
	
	-- Infinite stamina
	self.movement_state.stamina = {
		STAMINA_INIT = 50000,
		STAMINA_REGEN_RATE = 3,
		STAMINA_DRAIN_RATE = 0,
		REGENERATE_TIME = 1,
		MIN_STAMINA_THRESHOLD = 4,
		JUMP_STAMINA_DRAIN = 0
	}
end