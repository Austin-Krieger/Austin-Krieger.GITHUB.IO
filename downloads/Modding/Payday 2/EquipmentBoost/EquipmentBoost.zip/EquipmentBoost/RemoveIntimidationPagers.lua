--local securitynp = CharacterTweakData._init_security

--function CharacterTweakData:_init_security(presets, tweak_data)
--	securitynp(self, tweak_data, presets)
		-- Turn off pagers
--		self.security.has_alarm_pager = false
--end

--if RequiredScript == "lib/units/enemies/cop/copbrain" then
	--if self._cop_pager_ready == true then
	--	self._cop_pager_ready = false
	--end
	--if not self._cop_pager_ready and self._unit:movement():cool() then
	--	self._unit:unit_data().has_alarm_pager = false
	--end
if RequiredScript == "lib/units/enemies/cop/logics/coplogicintimidated" then
	function CopLogicIntimidated._chk_begin_alarm_pager(data) 
		if managers.groupai:state():whisper_mode() and data.unit:unit_data().has_alarm_pager then
		end
	end
end