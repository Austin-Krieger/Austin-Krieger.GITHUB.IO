local old_SBAE_init = UpgradesTweakData._init_pd2_values

function UpgradesTweakData:_init_pd2_values(tweak_data)
    old_SBAE_init(self, tweak_data)
	-- Increased Melee Damage (Requires Frenzy basic)
	self.values.player.melee_damage_health_ratio_multiplier = {999}
	
	--self.values.player.fall_damage_multiplier = {0.2}
	self.values.player.pick_up_ammo_multiplier = {999, 999, 999}
	-- Increase Ammo Capacity (Requires Fully Loaded basic)
	self.values.player.extra_ammo_multiplier = {9999}
	-- Return Ammo in single fire mode (Requires Ammo Efficiency basic)
	self.values.player.head_shot_ammo_return = {
		{ammo = 999999,time = 12,headshots = 2},
		{ammo = 999999,time = 12,headshots = 2}
	}
	
	-- Infinite Magazine (Surefire Skill Required)
	self.values.player.automatic_mag_increase = {999999}
	
	-- Increase Gun Damage
	self.values.weapon.passive_damage_multiplier = {999}
	self.values.weapon.passive_headshot_damage_multiplier = {999}
	
	-- Increase Gun Accuracy & Stability
	self.values.player.weapon_movement_stability = {0.9}
	self.values.player.stability_increase_bonus_1 = {100}	-- Requires Stable Shot Basic
	self.values.player.stability_increase_bonus_2 = {100}
	self.values.player.weapon_accuracy_increase = {100}		-- Requires Steady Grip Basic
	self.values.player.not_moving_accuracy_increase = {100} -- For shotguns comment out these two lines or lower the values

	-- Crew/Bot Setup Abilities
	self.values.team.crew_add_health = {999}
	self.values.team.crew_add_armor = {999}
	self.values.team.crew_add_dodge = {999}
	self.values.team.crew_add_concealment = {100}
	self.values.team.crew_add_stamina = {999}
	--self.values.team.crew_reduce_speed_penalty = {??}
	self.values.team.crew_faster_reload = {8}
	self.values.team.crew_faster_swap = {6}
	-- Get throwables back every kill
	self.values.team.crew_throwable_regen = {1}
	self.values.team.crew_health_regen = {999}
	--self.values.team.crew_active = {1,2,3} -- (Values from left to right are for additional active a.i.)
	self.values.team.crew_inspire = {{1,1,1}} -- 230, 160, 120
	self.values.team.crew_scavenge = {{0.9,0.9,0.9}} -- 0.4, 0.5, 0.6 (UN-TESTED)
	self.values.team.crew_interact = {{0,0,0}} -- 0.8, 0.6, 0.4
	self.values.team.crew_ai_ap_ammo = {true}
	
	-- Cleaning Costs
	self.values.player.cleaner_cost_multiplier = {0.01} -- Requires Sixth Sense Aced (Making this a negative value with gain you spending cash for killing civilians)
	
	-- Sentry Guns can no longer die or run out of ammo
	self.sentry_gun_base_armor = 999999
	self.sentry_gun_base_ammo = 999999
	
	-- Increase Body Bags per case, Doctor Bag uses, Ammo Bag ammo
	self.bodybag_crate_base = 9999999
	self.doctor_bag_base = 9999999
	self.ammo_bag_base = 9999999
	
	-- Increase the number of ECM Jammers with an infinite warble duration
	self.ecm_feedback_min_duration = 999999
	self.ecm_feedback_max_duration = 999999
	self.ecm_feedback_interval = 0
	self.ecm_feedback_retrigger_interval = 0
	self.ecm_feedback_retrigger_chance = 1
	self.values.ecm_jammer.quantity = {500,500}
	
	-- Make the ECM Jammer Infinite (This will block some mission objectives involving hacking and timers, not drills)
	--self.ecm_jammer_base_battery_life = 999999
	--self.ecm_jammer_base_low_battery_life = 999999
	--self.ecm_jammer_base_range = 999999
	
	-- Infinite Messiah Charges
	self.values.player.messiah_revive_from_bleed_out = {999}
	
	-- Health Improvement (Requires a perk deck such as Crew Chief for the changes to health armor and stamina to take effect)
	self.values.player.passive_health_multiplier = {999,999,999,999}
	
	-- Infinite Dodge (This option increases dodge for the 2-piece suit)
	--self.values.player.body_armor.dodge = {500}
	
	-- Improve all body armor stats
	self.values.player.body_armor = {
		armor = {5000,5000,5000,5000,5000,5000,5000},
		movement = {1,1,1,1,1,1,1},
		concealment = {100,100,100,100,100,100,100},
		dodge = {500,500,500,500,500,500,500},
		damage_shake = {0.1,0.1,0.1,0.1,0.1,0.1,0.1},
		stamina = {1,1,1,1,1,1,1}
	}
end