local old_addgag_init = GageAssignmentTweakData.init
 
function GageAssignmentTweakData:init(tweak_data)
    old_addgag_init(self, tweak_data)
		self.NUM_ASSIGNMENT_UNITS = {999,999,999,999,999,999,999}
end