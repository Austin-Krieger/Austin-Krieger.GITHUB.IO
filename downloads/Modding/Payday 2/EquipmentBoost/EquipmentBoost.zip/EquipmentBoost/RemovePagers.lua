Hooks:PostHook(CopBrain, "post_init", "remove_pagers", function(self, ...)
	self._unit:unit_data().has_alarm_pager = false
end)