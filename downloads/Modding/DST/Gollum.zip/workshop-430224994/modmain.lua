_G = GLOBAL
p=_G.rawget(_G,"p")or print
local RECIPETABS = _G.RECIPETABS
--GetPlayer = _G.GetPlayer
local require = _G.require


_G.IsDLCEnabled = function()
	return TUNING.LIGHTNING_GOAT_DAMAGE
end

----------------------- Prefabs ------------------------
--modimport("scripts/prefabs.lua")
PrefabFiles = {
	"gollum",
	"ring",
}

Assets = {
	Asset( "IMAGE", "images/saveslot_portraits/gollum.tex" ),
	Asset( "ATLAS", "images/saveslot_portraits/gollum.xml" ),

	Asset( "IMAGE", "images/selectscreen_portraits/gollum.tex" ),
	Asset( "ATLAS", "images/selectscreen_portraits/gollum.xml" ),

	Asset( "IMAGE", "bigportraits/gollum.tex" ),
	Asset( "ATLAS", "bigportraits/gollum.xml" ),
	
	Asset("IMAGE", "images/gollum.tex"),
	Asset("ATLAS", "images/gollum.xml"),
	
	Asset("SOUNDPACKAGE", "sound/gollum.fev"),
	Asset("SOUND", "sound/gollum.fsb"),
	
	Asset("ATLAS", "images/inventoryimages/ringmap.xml"),
	Asset("IMAGE", "images/inventoryimages/ringmap.tex"),
	
	Asset("ATLAS", "images/ring_vision.xml"),
	Asset("IMAGE", "images/ring_vision.tex"),
  
	Asset("ATLAS", "images/avatars/avatar_gollum.xml"),
	Asset("IMAGE", "images/avatars/avatar_gollum.tex"),
	Asset("ATLAS", "images/avatars/avatar_ghost_gollum.xml"),
	Asset("IMAGE", "images/avatars/avatar_ghost_gollum.tex"),
	
}


AddMinimapAtlas("images/gollum.xml")
AddMinimapAtlas("images/inventoryimages/ringmap.xml")

RemapSoundEvent( "dontstarve/characters/gollum/death_voice", "gollum/gollum/death_voice" )
RemapSoundEvent( "dontstarve/characters/gollum/hurt", "gollum/gollum/hurt" )
RemapSoundEvent( "dontstarve/characters/gollum/talk_LP", "gollum/gollum/talk_LP" )

local s = _G.STRINGS
s.CHARACTER_TITLES.gollum = "No! It's me Smeagol!"
s.CHARACTER_NAMES.gollum = "gollum"
s.CHARACTER_DESCRIPTIONS.gollum = "*Has his beloved ring.\n*Likes raw meat, especially fishes.\n*He's fast, but weak."
s.CHARACTER_QUOTES.gollum = "\"My precious!\""
s.CHARACTERS.GOLLUM = require "speech_gollum"

s.NAMES.RING = "Mystery Ring"
s.CHARACTERS.GENERIC.DESCRIBE.RING = "Puissance in a pocket!"
s.CHARACTERS.WICKERBOTTOM.DESCRIBE.RING = "Made in China."
s.CHARACTERS.WILLOW.DESCRIBE.RING = "Burn... the Ring?!"
s.CHARACTERS.WOLFGANG.DESCRIBE.RING = "More mighty!"
s.CHARACTERS.WENDY.DESCRIBE.RING = "Abigail always can see me!"
s.CHARACTERS.WX78.DESCRIBE.RING = "BLACK MAGIC DETECTED!"
s.CHARACTERS.WICKERBOTTOM.DESCRIBE.RING = "Ha! Sauron my old good friend!"
s.CHARACTERS.WOODIE.DESCRIBE.RING = "NO WOOD?"



AddModCharacter("gollum","MALE")


--[[
function AddPlayersPostInit(fn)
	for i,v in ipairs(_G.DST_CHARACTERLIST) do
		AddPrefabPostInit(v,fn)
	end
	for i,v in ipairs(_G.MODCHARACTERLIST) do
		AddPrefabPostInit(v,fn)
	end
end
--]]

-------------------- AddPlayersPostInit Library ----------------
_G = GLOBAL
if not _G.rawget(_G,"mods") then _G.rawset(_G,"mods",{}) end
if not _G.mods.player_preinit_fns then
	_G.mods.player_preinit_fns={}
	--Dirty hack
	local old_MakePlayerCharacter = require("prefabs/player_common")
	local function new_MakePlayerCharacter(...)
		local inst=old_MakePlayerCharacter(...)
		for _,v in ipairs(_G.mods.player_preinit_fns) do
			v(inst)
		end
		return inst
	end
	_G.package.loaded["prefabs/player_common"] = new_MakePlayerCharacter
end

function AddPlayersPreInit(fn)
	table.insert(_G.mods.player_preinit_fns,fn)
end

local player_postinit_fns = {}
local function AddPlayersPostInit(fn)
	table.insert(player_postinit_fns,fn)
end

local done_players = {}
AddPlayersPreInit(function(inst)
	if not done_players[inst.name] then
		done_players[inst.name] = true
		AddPrefabPostInit(inst.name,function(inst)
			for _,v in ipairs(player_postinit_fns) do
				v(inst)
			end
		end)
	end
end)

--------------------- Fix crash for old speech files ----------------------

--Фиксим краши из-за отсутствующих реплик.
--if not _G.rawget(_G,"mods") then _G.rawset(_G,"mods",{}) end
if not _G.mods.GetStringOverwrite then
	_G.mods.GetStringOverwrite = true
	local old_GetString = _G.GetString
	_G.GetString = function(inst, stringtype, modifier,...)
		local character = type(inst) == "string" and string.upper(inst) or (inst ~= nil and string.upper(inst.prefab))
		if character and stringtype and type(modifier) == "table" and _G.STRINGS.CHARACTERS[character] then
			stringtype = string.upper(stringtype)
			local topic_tab = _G.STRINGS.CHARACTERS[character][stringtype]
			if topic_tab and type(topic_tab)=="table" then
				local ret = topic_tab
				for i,v in ipairs(modifier) do
					if type(ret)~="table" then
						return --No crash
					end
					ret = ret[v]
				end
			end
		end
		return old_GetString(inst, stringtype, modifier,...)
	end
end


--------------------------- Fix crash for Klei bug with inventory -------------------
local comp_inventory = require "components/inventory"
local old_RemoveItem = comp_inventory.RemoveItem
function comp_inventory:RemoveItem(item, wholestack, ...)
	if (not item)or not item:IsValid() then
		return
	end
	return old_RemoveItem(self,item, wholestack, ...)
end


------------Secret place for Gollum ----------------


--[[local params={} 
params.cellar =
{
	widget =
	{
		slotpos = {},
		--animbank = "ui_chester_shadow_3x4",
		--animbuild = "ui_chester_shadow_3x4",
		pos = _G.Vector3(0, 220, 0),
		side_align_tip = 160,
	},
	type = "chest",
}

for y = 6.5, -0.5, -1 do
	for x = 0, 9 do
		table.insert(params.cellar.widget.slotpos, _G.Vector3(75 * x - 75 * 12 + 75, 75 * y - 75 * 6 + 75, 0))
	end
end--]]

--[[
1:15 - star: 1) Gollum can't put it on ground, can't use treasure chests, can't give etc. He can only use secret places in graves.
1:15 - star: 2) He gets little sanity when it in inventory
1:16 - star: 3) He has hude penalty if he has no ring and someone near him has it.
1:16 - Hast: i totally doesn't like 3.
1:16 - Hast: Not sure why
1:16 - star: 4) Other players has no any bonuses or penalty if ring is just in inventory
1:17 - Hast: but, it makes this mod evem more complicated, esspecically when there will be like 4 rings
1:17 - star: 5) Other players can give the ring, drop etc
1:18 - star: 6) There is a 50%(???) chance of drop the ring from Gollum on death, but if and only if there are player near him
1:18 - Hast: 4 is ok. 5 is ok. 6 is kinda complicated. Like he is a monster and have loot
1:18 - Hast: 3 isn't good in my opinion
1:19 - Hast: 1 and 2 is good

--]]

----- Cache ----

local Vector3 = _G.Vector3
local small_items = {smallmeat=1,cookedsmallmeat=1,smallmeat_dried=1,drumstick_cooked=1,froglegs_cooked=1,fish_cooked=1,eel_cooked=1,
	acorn_cooked=1,bird_egg_cooked=1,batwing_cooked=1,berries_cooked=1,ring=1,seeds=1,panflute=1,sewing_kit=1,nightmare_timepiece=1,
	compass=1,mosquitosack=1,spidergland=1,bandage=1,pinecone=1,petals=1,petals_evil=1,nightmarefuel=1,foliage=1,
	manrabbit_tail=1,pigskin=1,feather_crow=1,feather_robin=1,feather_robin_winter=1,slurtleslime=1,houndstooth=1,stinger=1,gears=1,
	transistor=1,ice=1,goatmilk=1,goose_feather=1,glommerflower=1,glommerfuel=1,boneshard=1,abigail_flower=1,lighter=1,balloons_empty=1,
	butter=1,butterflywings=1,carrot_cooked=1,corn_cooked=1,deerclops_eyeball=1,honey=1,taffy=1,rottenegg=1,red_cap_cooked=1,
	green_cap_cooked=1,blue_cap_cooked=1,cutlichen=1,spoiled_food=1,poop=1,guano=1,}
--for i=1,12 do small_items["trinket_"..i]=1 end
params_gollum_cache =
{
	widget =
	{
		--slotpos = {},
		slotpos =
		{
			Vector3(-150, 64 + 32 + 8 + 4, 0), 
			--Vector3(0, 32 + 4, 0),
			--Vector3(0, -(32 + 4), 0), 
			--Vector3(0, -(64 + 32 + 8 + 4), 0),
		},
		--animbank = "ui_icepack_2x3",
		--animbuild = "ui_icepack_2x3",
		--pos = Vector3(0, 220, 0),
		pos = Vector3(200, 0, 0),
		side_align_tip = 100,
	},
	--issidewidget = true,
	acceptsstacks = false,
	type = "chest",
	itemtestfn=function(container, item, slot)
		if (item:HasTag("molebait") or small_items[item.prefab] or small_items[item.prefab.."_cooked"])
			and item.prefab~="cutstone" and not item:HasTag("groundtile")
		then
			return true
		end
		return false
	end
}



local function testring(container, item, slot,...)
	if item.prefab == "ring" and not item:HasTag("irreplaceable") then --should work only for Gollum
		local owner
		if item.components.inventoryitem then
			owner = item.components.inventoryitem.owner
		end
		if owner and owner.components.talker then
			--Dirty hack. Talking in test function. This is not right.
			owner.components.talker:Say("We should keep him in our pocket, just for sure!")
		end
		return false
	elseif container and container.old_testring then
		return container:old_testring(item, slot,...)
	end
	return true
end


local other_containers = {
	treasurechest = testring,
	pandoraschest = testring,
	skullchest = testring,
	minotaurchest = testring,
	chester = testring,
	dragonflychest = testring,
}


local containers = _G.require "containers"
--containers.MAXITEMSLOTS = math.max(containers.MAXITEMSLOTS, params.cellar.widget.slotpos ~= nil and #params.cellar.widget.slotpos or 0)
local old_widgetsetup = containers.widgetsetup
function containers.widgetsetup(container, prefab, data, ...)
	local pref = prefab or container.inst.prefab
	if pref == "gravestone" then
		data = params_gollum_cache
	end
	old_widgetsetup(container, prefab, data, ...)
	--forbid the ring in containers for client AND server
	if container and pref and other_containers[pref] then
		if container.itemtestfn and not container.old_testring then
			container.old_testring = container.itemtestfn
		end
		container.itemtestfn = other_containers[pref]
	end
end

---- Other containers ------


--[[local function GollumRing(inst)
	_G.rawset(inst.components.container,"itemtestfn",testring)
end


AddPrefabPostInit("treasurechest", GollumRing)
AddPrefabPostInit("pandoraschest", GollumRing)
AddPrefabPostInit("skullchest", GollumRing)
AddPrefabPostInit("minotaurchest", GollumRing)
--AddPrefabPostInit("backpack", GollumRing)
--AddPrefabPostInit("piggyback", GollumRing)
--AddPrefabPostInit("krampus_sack", GollumRing)
AddPrefabPostInit("chester", GollumRing)

--RoG
--AddPrefabPostInit("icepack", GollumRing)
AddPrefabPostInit("dragonflychest", GollumRing)--]]




--------------------------------Works only on host.--------------------------------------------
if _G.TheNet and _G.TheNet:GetIsServer() then

---pig man can own a ring....

--[[AddPrefabPostInit("pigman",function(inst)
	local old_test = inst.components.trader.test
	inst.components.trader:SetAcceptTest(function(inst,item,giver,...)
		print("------ item.prefab: "..tostring(item.prefab))
		print("inst.components.follower: "..tostring(inst.components.follower))
		print("inst.components.follower.leader "..tostring(inst.components.follower.leader))
		if item.prefab == "ring" and inst.components.follower
			and (not inst.components.follower.leader
				or inst.components.follower:GetLoyaltyPercent() < 0.5)
		then
			return true
		elseif old_test then 
			return old_test(inst,item,giver,...)
		end
		return true
	end)
	local old_AcceptGift = inst.components.trader.onaccept
	inst.components.trader.onaccept = function(inst, giver, item,...)
		if inst and inst.components.follower then
            if inst.components.combat.target and inst.components.combat.target == giver then
                inst.components.combat:SetTarget(nil)
            elseif giver.components.leader and not inst:HasTag("guard") then
                inst.SoundEmitter:PlaySound("dontstarve/common/makeFriend")
                giver.components.leader:AddFollower(inst)
                inst.components.follower:AddLoyaltyTime(TUNING.PIG_LOYALTY_MAXTIME)
            end
			if inst.components.sleeper:IsAsleep() then
				inst.components.sleeper:WakeUp()
			end
			if inst.AnimState then
				inst.AnimState:SetMultColour(0.2,0.2,0.2,.2)
			end
		end
		if old_AcceptGift then
			return old_AcceptGift(inst, giver, item,...)
		end
	end
end)--]]



AddPrefabPostInit("gravestone",function(inst)
	inst:AddComponent("container")
	inst.components.container:WidgetSetup("gravestone") --,params_gollum_cache)
	inst:AddTag("fridge")
	inst.known_db = {} --players, who know this place
	--inst.components.container.onopenfn = onopen
	--inst.components.container.onclosefn = onclose
end)


-------------------- Gollum Functions -----------------------
--modimport("scripts/gollumfunc.lua")
local ACTIONS = _G.ACTIONS
local TheInput = _G.TheInput
local is_debug = false


local old_ACTIONS_RUMMAGE = ACTIONS.RUMMAGE.fn
ACTIONS.RUMMAGE.fn = function(act)
	local player = act.doer
	if act.target and act.target.prefab == "gravestone" then
		local can_open = (player.prefab == "gollum") or (act.target.known_db[player.userid])
		if can_open then
			for _,p in ipairs(_G.AllPlayers) do
				if p~=player and p.prefab~="gollum" and p:GetDistanceSqToInst(player) < 10*10 and not act.target.known_db[p.userid] then
					act.target.known_db[p.userid] = true
					if p.components.talker then
						p.components.talker:Say("Now I know secret place!")
					end
				end
			end
		else
			return false, "NOTHING_HERE"
		end
	end
	return old_ACTIONS_RUMMAGE(act)
end


local old_ACTIONS_ATTACK = _G.ACTIONS.ATTACK.fn
_G.ACTIONS.ATTACK.fn = function(act) 
	local player = act.doer
	if player:HasTag("badring") then
		if player.prefab == "gollum" then
			if player.components.combat then
				return false,"has_ring"
			end	
		elseif player.components.inventory then
			for k,v in pairs(player.components.inventory.equipslots) do
				if v.prefab=="ring" then
					--print("Drop ring!")
					player.components.inventory:DropItem(v)
				end
			end
		end
	end
	return old_ACTIONS_ATTACK(act)
end



local old_ACTIONS_DROP = ACTIONS.DROP.fn
ACTIONS.DROP.fn = function(act)
	local player = act.doer
	if player.prefab == "gollum" and act.invobject.prefab == "ring" and not is_debug then
		if player.components.inventory then
			--player.components.talker:Say("No! What if we lose him?!")
			return false, "LOSE_UNWANTED"
		end
	end
	return old_ACTIONS_DROP(act)
end

local old_ACTIONS_STORE = ACTIONS.STORE.fn
ACTIONS.STORE.fn = function(act)
	local player = act.doer
	if act.target and player.prefab == "gollum" and act.invobject.prefab == "ring" and act.target.prefab~="gravestone" and not is_debug then
		if act.target.components.container and act.invobject.components.inventoryitem and player.components.inventory then
			player.components.talker:Say("We should keep him in our pocket, just for sure!")
			--print("Just for sure")
			return true
		elseif act.target.components.occupiable and act.invobject
		and act.invobject.components.occupier and act.target.components.occupiable:CanOccupy(act.invobject)
		then
			player.components.talker:Say("We should keep him in our pocket, just for sure!")
			--print("Just for sure")
			return true
		end
	elseif act.target and act.target.prefab=="gravestone" and player.prefab ~= "gollum" and not act.target.known_db[player.userid] then
		return false, "USELESS_GRAVE"
	end
	return old_ACTIONS_STORE(act)
end


local old_ACTIONS_GIVE = ACTIONS.GIVE.fn
ACTIONS.GIVE.fn = function(act)
	local player = act.doer
	if player.prefab == "gollum" and act.invobject.prefab == "ring" and not is_debug then
		return false, "ITS_MINE"
	end
	return old_ACTIONS_GIVE(act)
end


local old_ACTIONS_GIVETOPLAYER = ACTIONS.GIVETOPLAYER.fn
ACTIONS.GIVETOPLAYER.fn = function(act)
	local player = act.doer
	if player.prefab == "gollum" and act.invobject.prefab == "ring" and not is_debug then
		return false, "ITS_MINE"
	end
	return old_ACTIONS_GIVETOPLAYER(act)
end

local old_ACTIONS_ADDFUEL = ACTIONS.ADDFUEL.fn
ACTIONS.ADDFUEL.fn = function(act)
	local player = act.doer
	if player.prefab == "gollum" and act.invobject.prefab == "ring" and not is_debug then
		return false, "NO"
	end
	return old_ACTIONS_ADDFUEL(act)
end



--------------------------------- Item Functions ----------------------------------
--modimport("scripts/itemfunc.lua")
--local GetWorld = _G.GetWorld
--local GetSeasonManager = _G.GetSeasonManager


local function UpdateCharacterStrings(tab)
	if not tab then
		return
	end
	if not tab.PICK then
		tab.PICK = {}
		tab.PICK.GENERIC = "I can't do that."
	end
	--tab.PICK.NOT_GOLLUM = "Only Gollum can catch fish without fishing rod."
	tab.PICK.NOT_GOLLUM = "Can't catch.\nI need fishing rod."
	
	if not tab.RUMMAGE then
		tab.RUMMAGE = {}
		tab.RUMMAGE.GENERIC = "I can't open it."
	end
	tab.RUMMAGE.NOTHING_HERE = "Seems it's empty. Nothing here."
	
	if not tab.STORE then
		tab.STORE = {}
		tab.STORE.GENERIC = "I can't open it."
	end
	tab.STORE.USELESS_GRAVE = "There is no place for that."
end


--AddPrefabPostInit("gollum",function(inst)
--After loading other characters

local fish_sources = {pond=1,pond_mos=1,pond_cave=1}

AddPlayersPostInit(function(inst) --All characters see this string but only Gollum can catch
	local oldactionstringoverride = inst.ActionStringOverride
	function inst:ActionStringOverride(bufaction)
		if bufaction.target then
			if bufaction.action == _G.ACTIONS.PICK and fish_sources[bufaction.target.prefab] then
				return "Catch a fish in"
			elseif bufaction.action == _G.ACTIONS.RUMMAGE and bufaction.target.prefab=="gravestone" then
				return "Look inside"
			end
		end
		if oldactionstringoverride then
			return oldactionstringoverride(inst, bufaction)
		end
	end
	if type(inst.prefab)~="string" or inst.prefab == "gollum" then
		return
	end
	local tab = _G.STRINGS.CHARACTERS[string.upper(inst.prefab)]
	if tab then
		tab = tab.ACTIONFAIL
		UpdateCharacterStrings(tab)
	end
end)

--default speech
UpdateCharacterStrings(_G.STRINGS.CHARACTERS.GENERIC.ACTIONFAIL)

local old_ACTIONS_PICK = ACTIONS.PICK.fn
ACTIONS.PICK.fn = function(act)
	--p("PICK")
	if act.target and act.target.components.fishable then
		--p("fishable")
		local player = act.doer
		if player.prefab ~= "gollum"  then
			--p(player.prefab)
			return false, "NOT_GOLLUM"
		elseif act.target.components.fishable.frozen then
			--p("frozen")
			--_G.arr(act.target.components.fishable)
			return false, "ICE"
		elseif act.target.components.fishable.fishleft > 0 then
			act.target.components.fishable.fishleft = act.target.components.fishable.fishleft - 1
		end
	end
	return old_ACTIONS_PICK(act)
end



function RawMeat(inst)
	inst:AddTag("rawmeat")
end

AddPrefabPostInit("meat", RawMeat)
AddPrefabPostInit("smallmeat", RawMeat)
AddPrefabPostInit("drumstick", RawMeat)
AddPrefabPostInit("eel", RawMeat)
AddPrefabPostInit("froglegs", RawMeat)
AddPrefabPostInit("batwing", RawMeat)
AddPrefabPostInit("trunk_summer", RawMeat)
AddPrefabPostInit("trunk_winter", RawMeat)
AddPrefabPostInit("humanmeat", RawMeat)



local function CatchFishEel(prefab,item)
	AddPrefabPostInit(prefab,function(inst)
		if not inst.components.pickable then
			inst:AddComponent("pickable")
			inst.components.pickable:SetUp(item, TUNING.TOTAL_DAY_TIME*3)
			inst.components.pickable.canbepicked = true
		end
	end)
end

CatchFishEel("pond", "fish")
CatchFishEel("pond_mos", "fish")
CatchFishEel("pond_cave", "eel")


-------------------- Monitoring all rings in the world -------------

local rings_table = {}
_G.rawset(_G,"t",rings_table)

AddPrefabPostInit("forest",function(inst)
	inst:DoTaskInTime(0,function(inst)
		local rings = _G.TheSim:FindEntities(0,0,0,1500,{"gollum_ring"})
		for _,v in ipairs(rings) do
			if v.ring_userid then
				if not rings_table[v.ring_userid] then
					rings_table[v.ring_userid] = {}
				end
				local data = rings_table[v.ring_userid]
				_G.rawset(_G,"tt",data)
				local found = false
				for __,vv in ipairs(data) do
					if vv==v then
						found = true
						break
					end
				end
				if not found then
					table.insert(data,v)
				end
			end
		end
	end)
end)



--modimport("scripts/intro.lua")
------------------------------- Customization -----------------------------
--modimport("scripts/customization.lua")




local function GollumPostInit(inst)
	inst.components.health:SetMaxHealth(GetModConfigData("GollumHealth"))
	inst.components.sanity.max = (GetModConfigData("GollumSanity"))
	inst.components.hunger.max = (GetModConfigData("GollumHunger"))
	inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE*GetModConfigData("GollumHungerDrop"))
	--inst.components.locomotor.runspeed = (GetModConfigData("GollumSpeed"))
	inst.components.combat.damagemultiplier = (GetModConfigData("GollumDamage"))
	inst.rings_table = rings_table
end
AddPrefabPostInit("gollum", GollumPostInit)

local function RingPenalty(inst)
	if inst.components.equippable.dapperness then --RoG version
		inst.components.equippable.dapperness = (GetModConfigData("RingPenalty")) --TUNING.CRAZINESS_MED
	else --non-Rog
		inst:AddComponent("dapperness")
		inst.components.dapperness.dapperness = (GetModConfigData("RingPenalty")) --TUNING.CRAZINESS_MED
	end
	inst.rings_table = rings_table
end	
AddPrefabPostInit("ring", RingPenalty)


--------------------- Tall bird hack ----------------------

--[[local old_SuggestTarget --may be incompatible with rough mods
local function new_SuggestTarget(self,target,...)
	if not(target and target:HasTag("badring")) then
		--print("All Ok")
		return old_SuggestTarget(self,target,...)
	--else
		--print("Hidden gollum!")
	end
end
AddPrefabPostInit("tallbird",function(inst)
	old_SuggestTarget = inst.components.combat.SuggestTarget
	inst.components.combat.SuggestTarget = new_SuggestTarget
end)--]]

--actually filter all new monster targets

local comp_combat = _G.require "components/combat"
local old_SuggestTarget = comp_combat.SuggestTarget
function comp_combat:SuggestTarget(target,...)
	if not(target and target:HasTag("badring") and not self.inst:HasTag("player")) then
		return old_SuggestTarget(self,target,...)
	end
end

local old_SetTarget = comp_combat.SetTarget
function comp_combat:SetTarget(target,...)
	if not(target and target:HasTag("badring") and not self.inst:HasTag("player")) then
		return old_SetTarget(self,target,...)
	end
end


----------------------- No drop of ring -------------------

local function IsRing(item)
	return item.prefab == "ring"
end


local chance_of_drop = GetModConfigData("chance_of_drop") or 0.1

AddStategraphPostInit("wilson", function(sg) --SGWilson
	local old_death_fn = sg.events.death.fn
	sg.events.death.fn = function(inst, data, ...)
		if inst.components.inventory and inst.prefab == "gollum" and math.random() < chance_of_drop then
			local i = inst.components.inventory:FindItems(IsRing)
			for _,v in ipairs(i) do
				v:Remove()
			end
			for k,v in pairs(inst.components.inventory.equipslots) do
				if IsRing(v) then
					v:Remove()
				end
			end
		end
		return old_death_fn(inst, data, ...)
	end
end)


---------end of server side --------------
end


--------- No target by other players -----------------

local comb_rep = _G.require "components/combat_replica"
local old_IsAlly = comb_rep.IsAlly
function comb_rep:IsAlly(guy,...)
	if guy:HasTag("badring") then
		return true
	end
	return old_IsAlly(self,guy,...)
end


-------------------- Support of invisibility and compatibility with other mods. -----------------

--client anim function (COMMON)
local function UpdateAnim(inst,once)
	local data = inst.m_compatibility
	if data then
		if data.task then
			data.task:Cancel()
		end
		if data.time_create then
			if data.time_create + 15 > _G.GetTime() then
				once = false
			else
				data.time_create = nil
			end
		end
		data.task_cnt = once and 15 or 0
		data.task = inst:DoPeriodicTask(0.2+math.random()*0.05,function(inst)
			--print("UpdateAnim: "..tostring(data.task_cnt))
			local f = data.test
			--transp
			if inst.AnimState then
				local t = 1
				for k,m in pairs(data.transp) do
					local ofs = (f[k][1](inst) and 1 or (f[k][2](inst) and 2 or 3)) --owner/ally/neutral offset
						+(f[k][3](inst) and 0 or 3) --is it hidden at all?
					local m_val = type(m[ofs])=="function" and m[ofs](inst) or m[ofs]
					if m_val < t then
						t = m_val --minimum
					end
				end
				inst.AnimState:SetMultColour(t,t,t,t)
			end
			--icon
			if inst.MiniMapEntity then
				local show_icon = true
				for k,m in pairs(data.icon) do
					local ofs = (f[k][1](inst) and 1 or (f[k][2](inst) and 2 or 3)) --owner/ally/neutral offset
						+(f[k][3](inst) and 0 or 3) --is it hidden at all?
					if not m[ofs] then
						show_icon = false
						break
					end
				end
				inst.MiniMapEntity:SetEnabled(show_icon)
			end
			--shadow
			if inst.DynamicShadow then
				local show_shadow = true
				for k,m in pairs(data.shadow) do
					local ofs = (f[k][1](inst) and 1 or (f[k][2](inst) and 2 or 3)) --owner/ally/neutral offset
						+(f[k][3](inst) and 0 or 3) --is it hidden at all?
					if not m[ofs] then
						show_shadow = false
						break
					end
				end
				inst.DynamicShadow:Enable(show_shadow)
			end
			--indicator
			local show_indicator = true
			for k,m in pairs(data.indicator) do
				local ofs = (f[k][1](inst) and 1 or (f[k][2](inst) and 2 or 3)) --owner/ally/neutral offset
					+(f[k][3](inst) and 0 or 3) --is it hidden at all?
				if not m[ofs] then
					show_indicator = false
					break
				end
			end
			if show_indicator then
				inst:RemoveTag("noplayerindicator")
			else
				inst:AddTag("noplayerindicator")
			end
			--time out
			data.task_cnt = data.task_cnt + 1
			if data.task_cnt > 15 then
				data.task:Cancel()
				data.task = nil
			end
		end,0.05)
	end
end


--client test functions
local function test_owner(inst)
	return (inst == _G.ThePlayer)
end

local function test_ally(inst)
	return _G.ThePlayer and inst.m_friends and inst.m_friends[_G.ThePlayer.userid]
	--return false
end

local function test_hidden(inst)
	return inst.is_badring
end

--Network update for client
local function OnIsBadring(inst)
	inst.is_badring = inst.net_is_badring:value()
	--print("OnIsBadring: "..tostring(inst.is_badring))
	inst.m_compatibility.UpdateAnim(inst)
	if inst.is_badring then
		inst:AddTag("badring")
	else	
		inst:RemoveTag("badring")
	end
	inst.GollumSetHUDState(inst)
end

local function transparent_enemy(inst)
	
end

local function SetHUDState(inst) --, data)
	if inst~=_G.ThePlayer then --HUD only for player
		return
	end
	--print("SetHUDState")
	if inst:HasTag("badring") and not inst.HUD.gollumOL then
		inst:DoTaskInTime(0.1, function()
			inst.HUD.gollumOL = inst.HUD.under_root:AddChild(_G.Image("images/ring_vision.xml", "ring_vision.tex"))
			inst.HUD.gollumOL:SetVRegPoint(_G.ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetHRegPoint(_G.ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetVAnchor(_G.ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetHAnchor(_G.ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetScaleMode(_G.SCALEMODE_FILLSCREEN)
			inst.HUD.gollumOL:SetClickable(false)
		
			--induceinsanity(true, inst)
		end)
	--[[elseif not inst:HasTag("badring") then
		if inst.HUD.gollumOL then
			inst.HUD.gollumOL:Kill()
			inst.HUD.gollumOL = nil
		end]]
	elseif (not inst:HasTag("badring")) and inst.HUD.gollumOL then
		inst.HUD.gollumOL:Kill()
		inst.HUD.gollumOL = nil
		--induceinsanity(nil, inst)
	end
end	

local function MakeTransparentAsGollum(inst)
	--print("MakeTransparentAsGollum "..tostring(inst))
	--Common part
	if not inst.m_compatibility then
		inst.m_compatibility =
		{
			transp = {}, --mods
			test = {}, --criteria functions
			icon = {},
			shadow = {},
			indicator = {},
			UpdateAnim = UpdateAnim,
			time_create = _G.GetTime(),
			--current = {},
		}
	end
	--Gollum part
	local data = inst.m_compatibility
	data.test.gollum = { test_owner, test_ally, test_hidden } --only 2 functions, because neutral is default result
	data.transp.gollum = {0.3,0.1,function() return 0 end,1,1,1} --hidden owner/ally/neutral + unhidden owner/ally/neutral
	data.icon.gollum = {true,false,false,true,true,true} --false is better
	data.shadow.gollum = {false,false,false,true,true,true} --false is better
	data.indicator.gollum = {true,false,false,true,true,true} --false is better
	inst.GollumSetHUDState = SetHUDState
	--Network part
	inst.is_badring = false
	inst.net_is_badring = _G.net_bool(inst.GUID,"is_badring","event_is_badring")
	if not _G.TheWorld.ismastersim then
		inst:ListenForEvent("event_is_badring", OnIsBadring)
		return
	end
end


AddPlayersPostInit(MakeTransparentAsGollum) --Make all player prefabs hideable



