name = "Gollum DST"
description = "This mod adds new character to the game - Gollum! He is obsessed about the ring, and he loves fishes. Can you help him to survive ? Mod works with DLC and with vanila game."
author = "Hast, Star and Kuloslav"
version = "0.16"

forumthread = ""
api_version = 10

icon_atlas = "modicon.xml"
icon = "modicon.tex"

dont_starve_compatible = false
reign_of_giants_compatible = false
dst_compatible = true

all_clients_require_mod = true
client_only_mod = false

server_filter_tags = {"gollum"}

priority = 0.00430224994 --unique.

configuration_options =
{
	{
        name = "GollumHealth",
        label = "Health",
        options =
        {
		    {description = "50", data = 50},
            {description = "60", data = 60},			
            {description = "70", data = 70},			
            {description = "80", data = 80},
            {description = "90", data = 90},			
            {description = "100", data = 100},			
            {description = "110", data = 110},
            {description = "120", data = 120},			
            {description = "130", data = 130},		
            {description = "140 (default)", data = 140},
            {description = "150", data = 150},					
            {description = "160", data = 160},
            {description = "170", data = 170},					
            {description = "180", data = 180},
            {description = "190", data = 190},					
            {description = "200", data = 200},
            --[[{description = "210", data = 210},					
            {description = "220", data = 220},
			{description = "230", data = 230},		
            {description = "240", data = 240},			
            {description = "250", data = 250},			--]]
       },
        default = 140,
    },	
    {
        name = "GollumSanity",
        label = "Sanity",
        options =
        {
		    {description = "50", data = 50},
            {description = "60", data = 60},			
            {description = "70", data = 70},			
            {description = "80", data = 80},
            {description = "90", data = 90},			
            {description = "100", data = 100},			
            {description = "110", data = 110},
            {description = "120", data = 120},			
            {description = "130", data = 130},		
            {description = "140", data = 140},
            {description = "150", data = 150},					
            {description = "160 (default)", data = 160},
            {description = "170", data = 170},					
            {description = "180", data = 180},
            {description = "190", data = 190},					
            {description = "200", data = 200},
            --[[{description = "210", data = 210},					
            {description = "220", data = 220},
			{description = "230", data = 230},		
            {description = "240", data = 240},			
            {description = "250", data = 250},--]]
       },
        default = 160,
    },		
	{
        name = "GollumHunger",
        label = "Hunger",
        options =
        {
		    {description = "50", data = 50},
            {description = "60", data = 60},			
            {description = "70", data = 70},			
            {description = "80", data = 80},
            {description = "90", data = 90},			
            {description = "100", data = 100},			
            {description = "110", data = 110},
            {description = "120", data = 120},			
            {description = "130", data = 130},		
            {description = "140 (default)", data = 140},
            {description = "150", data = 150},					
            {description = "160", data = 160},
            {description = "170", data = 170},					
            {description = "180", data = 180},
            {description = "190", data = 190},					
            {description = "200", data = 200},
            --[[{description = "210", data = 210},			
            {description = "220", data = 220},
			{description = "230", data = 230},		
            {description = "240", data = 240},			
            {description = "250", data = 250},--]]
       },
        default = 140,
    },	
	{
        name = "GollumHungerDrop",
        label = "Hunger Drop",
        options =
        {
            {description = "3x", data = 3},
            {description = "2.5x", data = 2.5},
			{description = "2x", data = 2},
            {description = "1.8x", data = 1.8},
            {description = "1.6x", data = 1.6},
			{description = "1.4x", data = 1.4},
            {description = "1.2x", data = 1.2},			
			{description = "1.0x(wilson)", data = 1.0},
            {description = "0.9x", data = 0.9},			
            {description = "0.8x(default)", data = 0.8},
			{description = "0.7x", data = 0.7},
            {description = "0.6x", data = 0.6},	
            {description = "0.5x", data = 0.5},			
       },
        default = 0.8,
    },		
	--[[{
        name = "GollumSpeed",
        label = "Speed",
        options =
        {
            {description = "0.8x", data = 4.8},			
            {description = "0.9x", data = 5.4},		
            {description = "1.0x (wilson)", data = 6},			
            {description = "1.1x", data = 6.6},
			{description = "1.2x", data = 7.2},
			{description = "1.3x (default)", data = 7.8},	
			{description = "1.4x", data = 8.4},	
			{description = "1.5x", data = 9},	
			{description = "1.6x", data = 9.6},		
			{description = "1.7x", data = 10.2},
			{description = "1.8x", data = 10.8},
			{description = "1.9x", data = 11.4},				
            {description = "2x", data = 12},			
       },
        default = 7.8,	
    },--]]
	{
        name = "GollumDamage",
        label = "Damage",
        options =
        {
            {description = "0.75 (default)", data = 0.75},
            {description = "1.0 (wilson)", data = 1.0},			
            {description = "1.25 (wigfrid)", data = 1.25},
            --[[{description = "1.5", data = 1.5},			
            {description = "1.75", data = 1.75},
            {description = "2", data = 2},	--]]
       },
        default = 0.75,
    },	
	{
        name = "RingPenalty",
        label = "Ring Penalty",
        options =
        {
            {description = "Micro!", data = -(100/800)},				
            {description = "Tiny", data = -(100/400)},				
            {description = "Low", data = -(100/200)},		
            {description = "Medium", data = -(100/110)},		
            {description = "Fast(default)", data = -(100/90)},
            {description = "High", data = -(100/70)},
            {description = "Very High", data = -(100/50)},
            {description = "Extreme", data = -(100/30)},
            {description = "Insane!", data = -(100/5)},			
       },
        default = -(100/90),
    },	
	{
        name = "chance_of_drop",
        label = "Drop Chance",
		hover = "Chance of dropping the ring on death of Gollum.\n100% for other characters.",
        options =
        {
            {description = "0%", data = 0.00},				
            {description = "1%", data = 0.01},				
            {description = "2%", data = 0.02},		
            {description = "3%", data = 0.03},
            {description = "5%", data = 0.05},
            {description = "10%", data = 0.1},
            {description = "15%", data = 0.15},
            {description = "20%", data = 0.2},
            {description = "30%", data = 0.3},
            {description = "40%", data = 0.4},
            {description = "50%", data = 0.5},
       },
       default = 0.1,
    },		
}

