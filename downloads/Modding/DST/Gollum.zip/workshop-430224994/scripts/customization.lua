

local function GollumHealth(inst)
    inst.components.health:SetMaxHealth(GetModConfigData("GollumHealth"))
end	
AddPrefabPostInit("gollum", GollumHealth)

local function GollumSanity(inst)
    inst.components.sanity.max = (GetModConfigData("GollumSanity"))
end	
AddPrefabPostInit("gollum", GollumSanity)

local function GollumHunger(inst)
    inst.components.hunger.max = (GetModConfigData("GollumHunger"))
end	
AddPrefabPostInit("gollum", GollumHunger)

local function GollumHungerDrop(inst)
    inst.components.hunger:SetRate(GetModConfigData("GollumHungerDrop"))
end	
AddPrefabPostInit("gollum", GollumHungerDrop)

local function GollumSpeed(inst)
    inst.components.locomotor.runspeed = (GetModConfigData("GollumSpeed"))
end	
AddPrefabPostInit("gollum", GollumSpeed)

local function GollumDamage(inst)
    inst.components.combat.damagemultiplier = (GetModConfigData("GollumDamage"))
end	
AddPrefabPostInit("gollum", GollumDamage)

local function RingPenalty(inst)
    inst.components.equippable.dapperness = (GetModConfigData("RingPenalty"))
end	
AddPrefabPostInit("ring", RingPenalty)