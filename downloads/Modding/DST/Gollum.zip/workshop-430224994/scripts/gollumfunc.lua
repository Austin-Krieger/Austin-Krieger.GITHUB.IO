local ACTIONS = GLOBAL.ACTIONS
local require = GLOBAL.require
local TheInput = GLOBAL.TheInput


GLOBAL.ACTIONS.ATTACK.fn = function(act) 
	if GetPlayer().prefab == "gollum" and GetPlayer():HasTag("badring") then
			if act.target.components.combat then
				act.doer.components.talker:Say("I can't attack now...")
				return false
			end	
	else 
	
	if act.target.components.combat then
        act.doer.components.combat:SetTarget(act.target)
        return true
    end
		
	end
end

local function GollumRing(inst)
	
	local function testring(inst, item, slot)
		if item.prefab ~= "ring" then
		return true
		end
	end

inst.components.container.itemtestfn = testring
	
end


AddPrefabPostInit("treasurechest", GollumRing)
AddPrefabPostInit("pandoraschest", GollumRing)
AddPrefabPostInit("skullchest", GollumRing)
AddPrefabPostInit("minotaurchest", GollumRing)
AddPrefabPostInit("backpack", GollumRing)
AddPrefabPostInit("piggyback", GollumRing)
AddPrefabPostInit("krampus_sack", GollumRing)
AddPrefabPostInit("chester", GollumRing)

if GLOBAL.IsDLCEnabled(GLOBAL.REIGN_OF_GIANTS) then 
AddPrefabPostInit("icepack", GollumRing)
end

if GLOBAL.IsDLCEnabled(GLOBAL.REIGN_OF_GIANTS) then 
AddPrefabPostInit("dragonflychest", GollumRing)
end

ACTIONS.DROP.fn = function(act) 
	if GetPlayer().prefab == "gollum" and act.invobject.prefab == "ring" then
	
		if act.doer.components.inventory then
			act.doer.components.talker:Say("No! What if we lose him?!")
			return true
		end


	else
		if act.doer.components.inventory then
			local wholestack = act.options.wholestack
			if act.invobject and act.invobject.components.stackable and act.invobject.components.stackable.forcedropsingle then
				wholestack = false	
			end
			return act.doer.components.inventory:DropItem(act.invobject, wholestack, false, act.pos) 
		end
	end
end

ACTIONS.STORE.fn = function(act)

	if GetPlayer().prefab == "gollum" and act.invobject.prefab == "ring" then
		if act.target.components.container and act.invobject.components.inventoryitem and act.doer.components.inventory then
					act.doer.components.talker:Say("We should keep him in our pocket, just for sure!")

			return true
		
		
		elseif act.target.components.occupiable and act.invobject and act.invobject.components.occupier and act.target.components.occupiable:CanOccupy(act.invobject) then
					act.doer.components.talker:Say("We should keep him in our pocket, just for sure!")

			return true
			
		end
	

	
	else
		if act.target.components.container and act.invobject.components.inventoryitem and act.doer.components.inventory then
        
			if not act.target.components.container:CanTakeItemInSlot(act.invobject) then
				return false, "NOTALLOWED"
			end

			local item = act.invobject.components.inventoryitem:RemoveFromOwner(act.target.components.container.acceptsstacks)
			if item then
				if not act.target.components.inventoryitem then
					act.target.components.container:Open(act.doer)
				end
			
				if not act.target.components.container:GiveItem(item,nil,nil,false) then
					if TheInput:ControllerAttached() then
						act.doer.components.inventory:GiveItem(item)
					else
						act.doer.components.inventory:GiveActiveItem(item)
					end
					return false
				end
					return true
            
			end
		elseif act.target.components.occupiable and act.invobject and act.invobject.components.occupier and act.target.components.occupiable:CanOccupy(act.invobject) then
			local item = act.invobject.components.inventoryitem:RemoveFromOwner()
			return act.target.components.occupiable:Occupy(item)
		end
	end
end




AddMinimapAtlas("images/gollum.xml")
AddMinimapAtlas("images/inventoryimages/ringmap.xml")

RemapSoundEvent( "dontstarve/characters/gollum/death_voice", "gollum/gollum/death_voice" )
RemapSoundEvent( "dontstarve/characters/gollum/hurt", "gollum/gollum/hurt" )
RemapSoundEvent( "dontstarve/characters/gollum/talk_LP", "gollum/gollum/talk_LP" )

GLOBAL.STRINGS.CHARACTER_TITLES.gollum = "No! It's me Smeagol!"
GLOBAL.STRINGS.CHARACTER_NAMES.gollum = "gollum"
GLOBAL.STRINGS.CHARACTER_DESCRIPTIONS.gollum = "*Has his beloved ring.\n*Likes raw meat, especially fishes.\n*He's fast, but weak."
GLOBAL.STRINGS.CHARACTER_QUOTES.gollum = "\"My precious!\""
GLOBAL.STRINGS.CHARACTERS.GOLLUM = require "speech_gollum"




table.insert(GLOBAL.CHARACTER_GENDERS.MALE, "gollum")

AddModCharacter("gollum")