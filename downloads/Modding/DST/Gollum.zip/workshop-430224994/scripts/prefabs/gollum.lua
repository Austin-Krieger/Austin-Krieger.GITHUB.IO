local MakePlayerCharacter = require "prefabs/player_common"

local assets = {
	Asset( "ANIM", "anim/player_basic.zip" ),
	Asset( "ANIM", "anim/player_idles_shiver.zip" ),
	Asset( "ANIM", "anim/player_actions.zip" ),
	Asset( "ANIM", "anim/player_actions_axe.zip" ),
	Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
	Asset( "ANIM", "anim/player_actions_shovel.zip" ),
	Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
	Asset( "ANIM", "anim/player_actions_eat.zip" ),
	Asset( "ANIM", "anim/player_actions_item.zip" ),
	Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
	Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
	Asset( "ANIM", "anim/player_actions_fishing.zip" ),
	Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
	Asset( "ANIM", "anim/player_bush_hat.zip" ),
	Asset( "ANIM", "anim/player_attacks.zip" ),
	Asset( "ANIM", "anim/player_idles.zip" ),
	Asset( "ANIM", "anim/player_rebirth.zip" ),
	Asset( "ANIM", "anim/player_jump.zip" ),
	Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
	Asset( "ANIM", "anim/player_teleport.zip" ),
	Asset( "ANIM", "anim/wilson_fx.zip" ),
	Asset( "ANIM", "anim/player_one_man_band.zip" ),
	Asset( "ANIM", "anim/shadow_hands.zip" ),
	Asset( "ANIM", "anim/beard.zip" ),
		
	Asset("ANIM", "anim/player_woodie.zip"),
	Asset("ANIM", "anim/player_wolfgang.zip"),
	
	Asset( "SOUND", "sound/sfx.fsb" ),
	Asset( "SOUND", "sound/wilson.fsb" ),

	Asset("ANIM", "anim/gollum.zip"),

	Asset( "ANIM", "anim/ghost_gollum_build.zip" ),
}
local prefabs = {}

local start_inv = 
{
	--"ring",
	"fish",
	"fish",
	"fish",
	"fish",
}

STRINGS.NORING = {
	"Where is he? Where is he?",
	"We lost our precious! We lost him!",
	"Myy PRECIOUS!",
	"Poor little me...",
}

local function RandomTalk(sayings) 
	return sayings[math.random(#sayings)]
end

local disallowed_equipment = {
	fishingrod = true,
}
 
local function NoFishingrod ( inst, data )
	local item = data.item
	if disallowed_equipment[item.prefab] then
		inst.components.talker:Say("I don't need it! I've hands you fool!")
		inst:DoTaskInTime(0.5, function(inst)
			inst.components.inventory:DropItem(item)
		end)
	end
end


local gollum_food_no_penalty = {
	icecream = 1,
}


local gollum_food_database =
{	--health / hunger / sanity
	fish = { 20,25,20 },
	monstermeat = { 23,0,15 },
	cookedmonstermeat = {3,0,10},
	monstermeat_dried = {3,0,5},
	
	--[[
	--Cooked food
	turkeydinner = {0,0,-6},
	
	--Waiter 101
	sticky_bun = {0,0,-12},
	molasses = {0,0,-7},
	mush_melon = {0,0,-30},
	mush_melon_cooked = {0,0,-30},
	beefalo_wings = {0,0,-8},
	surf_n_turf = {0,0,-8},
	sweet_n_sour = {0,0,-8},
	mushroom_burger = {0,0,-7},
	cactus_soup = {0,0,-22},
	chowder = {0,0,-11},
	gumbo = {0,0,-6},
	oleo = {0,0,-10},
	--]]
	
	--Constants
	any_veggie = -20,
	any_raw_meat = 15,
}

--Penalty for spoiled food.
local food_mult_fresh = {1,1,1}
local food_mult_stale = {0.33,0.66,0.33}
local food_mult_spoiled = {0,0.5,0}

local function gollumfood(inst, food)
	if gollum_food_no_penalty[food.prefab] then
		--do nothing
	elseif inst.components.eater and food.components.edible.foodtype == "VEGGIE" then
		inst.components.sanity:DoDelta(gollum_food_database.any_veggie)
		inst.components.talker:Say("Blech!")
	elseif gollum_food_database[food.prefab] then
		local mult = food:HasTag("stale") and food_mult_stale or (food:HasTag("spoiled") and food_mult_spoiled or food_mult_fresh)
		inst.components.health:DoDelta(gollum_food_database[food.prefab][1]*mult[1])
		inst.components.hunger:DoDelta(gollum_food_database[food.prefab][2]*mult[2])
		inst.components.sanity:DoDelta(gollum_food_database[food.prefab][3]
			*(gollum_food_database[food.prefab][3]<0 and 1 or mult[3]))
	elseif inst.components.eater and food:HasTag("rawmeat") then
		local mult = food:HasTag("stale") and food_mult_stale or (food:HasTag("spoiled") and food_mult_spoiled or food_mult_fresh)
		inst.components.sanity:DoDelta(gollum_food_database.any_raw_meat*mult[3])
	end
end

local function noringtalk(inst)
	inst.components.talker:Say(RandomTalk(STRINGS.NORING))
end

local function noringtalktimer(inst)
	local TalkTime = math.random(25,50)
	inst.talktask = inst:DoPeriodicTask(TalkTime, function(inst) noringtalk(inst) end)
end

--[[local function horrorcontrol(inst, data)
	if not inst.components.inventory:Has("ring", 1) and not inst:HasTag("badring") then
		if not inst.talktask then
			noringtalktimer(inst)
		end
		inst.components.sanity.dapperness = -(100/300)
	else 
		inst.components.sanity.dapperness = 0
		if inst.talktask then 
			inst.talktask:Cancel() 
			inst.talktask = nil 
		end	
	end
end

local function ringcheck(inst)
	local CheckRingTime = 1.7 + math.random()*0.1
	inst.ringsanity = inst:DoPeriodicTask(CheckRingTime, function() horrorcontrol(inst) end)
end--]]


	
--[[local function SetHUDState(inst, data)
	if inst:HasTag("badring") and not inst.HUD.gollumOL then
		inst:DoTaskInTime(0.1, function()
			inst.HUD.gollumOL = inst.HUD.under_root:AddChild(Image("images/ring_vision.xml", "ring_vision.tex"))
			inst.HUD.gollumOL:SetVRegPoint(ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetHRegPoint(ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetVAnchor(ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetHAnchor(ANCHOR_MIDDLE)
			inst.HUD.gollumOL:SetScaleMode(SCALEMODE_FILLSCREEN)
			inst.HUD.gollumOL:SetClickable(false)
		
			induceinsanity(true, inst)
		end)
	--elseif not inst:HasTag("badring") then
	--	if inst.HUD.gollumOL then
	--		inst.HUD.gollumOL:Kill()
	--		inst.HUD.gollumOL = nil
	--	end
	elseif inst:HasTag("character") and inst.HUD.gollumOL then
		inst.HUD.gollumOL:Kill()
		inst.HUD.gollumOL = nil
		induceinsanity(nil, inst)
	end
end	

local function hudcheck(inst)
	local CheckRingTime = 1.4 + math.random()*0.1
	inst.ringhud = inst:DoPeriodicTask(CheckRingTime, function(inst) SetHUDState(inst) end)
end--]]

local function IsRing(item)
	return item.prefab == "ring"
end

local function SpawnRingAgain(inst)
	if inst.rings_table then
		if not inst.rings_table[inst.userid] then
			inst.rings_table[inst.userid] = {}
		end
		local data = inst.rings_table[inst.userid]
		--clean up
		for i=#data,1,-1 do
			local v = data[i]
			if not (v.persists and v:IsValid()) then --garbage
				table.remove(data,i)
			end
		end
		if #data > 0 then
			--There is a ring in the world.
			return
		end
		local rings = inst.components.inventory:FindItems(IsRing)
		if #rings == 0 then
			local r = SpawnPrefab("ring")
			if r then
				inst.components.inventory:GiveItem(r)
			end
		end
	else
		print("Error on spawning the ring! No rings_table!")
	end
end

local common_postinit = function(inst)
	inst.soundsname = "gollum"
	--inst.entity:AddMiniMapEntity()
end

local SANITY_DOOR_1 = 30*30
local SANITY_DOOR_2 = 15*15
local SANITY_DOOR_3 = 5*5


local function sanityfn(inst)
	--Sanity per second
	--0.01 is invisible
	local delta = 0
	local found = false
	--Little sanity if have a ring
	if inst.components.inventory then
		local rings = inst.components.inventory:FindItems(IsRing)
		if #rings > 0 then
			delta = 0.01001 --TUNING.SANITYAURA_TINY/11
			found = true
		else
			for k,v in pairs(inst.components.inventory.equipslots) do
				if IsRing(v) then
					--delta = 1 --TUNING.SANITYAURA_TINY/11
					found = true
					break
				end
			end
		end
	end
	--Crazyness if someone have HIS ring.
	if delta==0 and inst.rings_table and inst.rings_table[inst.userid] then
		local data = inst.rings_table[inst.userid]
		if #data > 0 then
			--if #data>1 then --???
			for _,ring in ipairs(data) do
				local owner = ring.components.inventoryitem and ring.components.inventoryitem.owner
				if ring.persists and ring:IsValid() and ring.inlimbo and owner
					and (owner:HasTag("player") or owner:HasTag("chester")
						or (owner.components.inventoryitem and owner.components.inventoryitem.owner
							and owner.components.inventoryitem.owner:HasTag("player")
						)
					)
				then
					local distsq = inst:GetDistanceSqToInst(ring)
					if distsq < SANITY_DOOR_1 then
						delta = -0.05
						if distsq < SANITY_DOOR_3 then
							delta = -0.31
						elseif distsq < SANITY_DOOR_2 then
							delta = -0.15
						end
						break
					end
				end
			end
		end
	end
	return delta
end

local master_postinit = function(inst)
	inst.MiniMapEntity:SetIcon("gollum.tex")
	inst.components.eater:SetOnEatFn(gollumfood)
	
	--inst.components.health:SetMaxHealth(140)
	--inst.components.hunger:SetMax(140)
	--inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * 0.8)
	--inst.components.sanity:SetMax(160)
	inst.components.sanity.night_drain_mult = 0.5
	inst.components.sanity.neg_aura_mult = 1
	inst.components.combat.damagemultiplier = 0.75
	inst.components.sanity.custom_rate_fn = sanityfn

	
	--[[if not inst.ringsanity then
		ringcheck(inst)
	end--]]
	inst.food_database = gollum_food_database
	
	--[[if not inst.ringhud then
		hudcheck(inst)
	end--]]
	
	inst.components.locomotor.runspeed = (TUNING.WILSON_RUN_SPEED * 1.1)
	inst.components.locomotor.walkspeed = (TUNING.WILSON_WALK_SPEED * 0.5)
	
	inst:ListenForEvent( "equip", NoFishingrod )
	--inst:ListenForEvent( "equip", SetHUDState )
	--inst:ListenForEvent( "unequip", SetHUDState )
		
	--[[inst:DoPeriodicTask(0.2+math.random()*0.05, function(inst)
		if inst:HasTag("badring") and not inst.badring then
			inst.AnimState:SetMultColour(0.05, 0.05, 0.05, 0.5)	
			inst.badring = true
		elseif inst.badring and not inst:HasTag("badring") then
			inst.AnimState:SetMultColour(1, 1, 1, 1)
			inst.badring = nil
		end
	end)--]]
	inst:ListenForEvent("ms_respawnedfromghost",SpawnRingAgain)
	inst:DoTaskInTime(0,SpawnRingAgain)
end




return MakePlayerCharacter("gollum", prefabs, assets, common_postinit, master_postinit, start_inv)
