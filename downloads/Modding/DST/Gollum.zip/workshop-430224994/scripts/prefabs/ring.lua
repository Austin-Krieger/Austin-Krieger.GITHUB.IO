local assets=
{ 
	Asset("ANIM", "anim/ring.zip"),

	Asset("ATLAS", "images/inventoryimages/ring.xml"),
	Asset("IMAGE", "images/inventoryimages/ring.tex"),
	
	Asset("ATLAS", "images/inventoryimages/ringmap.xml"),
	Asset("IMAGE", "images/inventoryimages/ringmap.tex"),
	
}

local prefabs = 
{
}

local p = rawget(_G,"p") or print

local function induceinsanity(val,inst) --val=true/nil
	if inst.components.sanity then
		--inst.components.sanity.inducedinsanity = val
	end

	local pt = inst:GetPosition()
	local ents = _G.TheSim:FindEntities(pt.x,pt.y,pt.z, 100, nil, nil, {'rabbit', 'manrabbit'})

	for k,v in pairs(ents) do
		if v.CheckTransformState then
			v.CheckTransformState(v)
		end
	end
end	

local function DropTargets(owner)
	local x,y,z = owner.Transform:GetWorldPosition()	
	local ents = TheSim:FindEntities(x, y, z, 50)

	for k,v in pairs(ents) do
		if v.components.combat and v.components.combat.target == owner then
			v.components.combat.target = nil
		end
		--if v:HasTag("hound") and v.components.follower and v.components.follower.leader == owner then
		--	v.components.follower:SetLeader(nil)
		--end
	end
end

local AGGR_TIME = 4

local function AddDropTargetsTimer(owner)
	-- Stop anyone from actively attacking me (notarget tag will make it so you dont get retarggeted)
	local timer = 0
	owner.task_drop_targets = owner:DoPeriodicTask(0.2,function(inst)
		timer = timer + 0.2
		if timer > AGGR_TIME then
			DropTargets(inst)
		end
		if inst.task_drop_targets and (timer > AGGR_TIME or not inst:HasTag("badring"))  then
			inst.task_drop_targets:Cancel()
			inst.task_drop_targets = nil
		end
	end)
end

local function GoInvisible(owner)
	if owner:HasTag("badring") then
		return
	end
	owner:AddTag("badring")
	owner:AddTag("notarget")
	owner:RemoveTag("character")
	if owner:HasTag("scarytoprey") then --compatible with Savya character
		owner.was_scarytoprey = true
	end
	owner:RemoveTag("scarytoprey")
	owner.is_badring = true
	owner.m_compatibility.UpdateAnim(owner,true) --true means only once
	owner.net_is_badring:set(true)
	owner.GollumSetHUDState(owner)
	induceinsanity(true,owner)
	if owner.task_drop_targets then
		owner.task_drop_targets:Cancel()
	end
	AddDropTargetsTimer(owner)
end

local function GoVisible(owner)
	if not owner:HasTag("badring") then
		return
	end
	owner:RemoveTag("badring")
	owner:RemoveTag("notarget")
	owner:AddTag("character")
	if owner.was_scarytoprey then
		owner:AddTag("scarytoprey")
	end
	owner.is_badring = false
	owner.m_compatibility.UpdateAnim(owner,true)
	owner.net_is_badring:set(false)
	owner.GollumSetHUDState(owner)
	induceinsanity(nil,owner)
end



local function RingActiveTick(inst,owner)
	--print("Tick")
	if owner and owner.components.sanity then
		if owner:HasTag("badring") then
			if owner.components.sanity.current <= 0 then
				GoVisible(owner)
				--[[if owner.components.inventory and inst:IsValid() then
					owner.components.inventory:Unequip(inst)
				end--]]
			end
		else
			if owner.components.sanity.current > 10 then
				GoInvisible(owner)
			end
		end
	end
end


local function OnDeath(inst)
	--print("OnDeath")
	GoVisible(inst)
	if inst.ring_task ~= nil then
		inst.ring_task:Cancel()
		inst.ring_task = nil
	end
end

local function OnEquip(inst, owner) 
	--print("OnEquip "..tostring(owner))
	if not (owner.components.sanity and owner.components.sanity.current <=10) then
		GoInvisible(owner)
	end
	if owner.ring_task ~= nil then
		owner.ring_task:Cancel()
	end
	owner.ring_task = inst:DoPeriodicTask(0.9+math.random()*0.1, function() RingActiveTick(inst,owner) end)
	owner:ListenForEvent("ondeath", OnDeath)
end

local function OnUnequip(inst, owner) 
	--print("OnUnequip "..tostring(owner))
	OnDeath(owner)
	owner:RemoveEventCallback("ondeath", OnDeath)
end

local function IsRing(item)
	return item.prefab == "ring"
end


local function OnDropped(inst)
	inst:AddTag("irreplaceable")
end

local function Say(player,phrase)
	if player and player.components.talker then
		player.components.talker:Say(phrase)
	end
end

local function MakeNewMaster(inst,owner)
	--p("MakeNewMaster")
	local is_master = true
	local key = owner.userid
	if key and key ~= "" then --test owner
		if not inst.ring_userid then --ring is not initialized
			--p("Fresh ring")
			inst.ring_userid = key
			if not inst.rings_table[key] then
				inst.rings_table[key] = {}
			end
			local data = inst.rings_table[key]
			--clean up the table
			for i=#data,1,-1 do
				local v = data[i]
				if (not v.persists) or not v:IsValid() then --garbage
					table.remove(data,i)
				elseif v == inst then --double ring (err)
					--Probably is a bug of mod. But we will try to fix it.
					table.remove(data,i) --Removing here, and will add later.
				else --another ring???
					--user is trying to hack the mod? What should we do?
					--Hast: WE SHOULD REMOVE NEW RING.
					--me: Ok, we will.
					inst:DoTaskInTime(0,function(inst) inst:Remove() end)
					Say(owner,"Cheating? No cheats!")
					--table.remove(data,i)
					return false
				end
			end
			--add new ring pointer
			table.insert(data,inst)
			--
			if not inst.owner then --compatible with unknown mods
				inst.owner = owner.name --compatible with Tell Me mod
			end
		else --ring must be in table
			--Let's check it.
			--p("Not fresh")
			if not inst.rings_table[inst.ring_userid] then
				inst.rings_table[inst.ring_userid] = {} --For example, after load saved game.
			end
			local data = inst.rings_table[inst.ring_userid]
			--clean up the table
			for i=#data,1,-1 do
				local v = data[i]
				if (not v.persists) or not v:IsValid() then --garbage
					table.remove(data,i)
				elseif v == inst then --Ring exists.
					--All ok.
					--table.remove(data,i) --Ignoring.
				else --another ring???
					--user is trying to hack the mod? What should we do?
					if inst.ring_userid == key then --True master of the ring!
						--Let's remove another ring.
						v:DoTaskInTime(0,function(inst) inst:Remove() end)
						table.remove(data,i)
					else --Gollum got not his ring.
						--Probably another Gollum has his own ring.
						--So we need delete this ring.
						inst:DoTaskInTime(0,function(inst) inst:Remove() end)
						Say(owner,"It's gone!")
						table.remove(data,i)
						return false
					end
				end
			end
			if #data>1 then
				for i=#data,2,-1 do
					table.remove(data,i)
				end
			end
			if inst.ring_userid ~= key then
				is_master = false
			end
		end
	else
		--p("No userid")
	end
	if is_master then
		--p("MAKE MASTER!")
		inst:RemoveTag("irreplaceable")
	else
		--p("WRONG master!")
		inst:AddTag("irreplaceable")
	end
	return true
end


local function ContainerOnInventory(inst,owner)
	--p("ContainerOnInventory")
	if inst.components.container then
		local rings = inst.components.container:FindItems(IsRing)
		if #rings > 0 then
			local gollum
			if owner and owner:HasTag("player") and owner.prefab == "gollum" then
				gollum = true
			else
				gollum = false
			end
			for _,v in ipairs(rings) do
				if gollum then
					--v:RemoveTag("irreplaceable")
					MakeNewMaster(v,owner)
					--here inst might be nil
				else
					v:AddTag("irreplaceable")
				end
			end
		end
	end
	if inst.components.inventoryitem.gollum_old_fn then
		return inst.components.inventoryitem.gollum_old_fn(inst,owner)
	end
end


local function OnPutInInventory(inst, owner)
	--p("OnPutInInventory")
	--print(tostring(owner))
	if not owner then
		--p("No owner")
		inst:AddTag("irreplaceable")
	elseif owner:HasTag("player") then
		--p("Found player")
		if owner.prefab == "gollum" then
			MakeNewMaster(inst, owner)
			--here inst might be nil
		else
			--p("Not gollum")
			inst:AddTag("irreplaceable")
		end
	elseif owner.components.container and owner.components.inventoryitem then
		--p("Is container")
		local inv = owner.components.inventoryitem
		local master = inv.owner
		if master and master:HasTag("player") and master.prefab=="gollum" then
			MakeNewMaster(inst, master)
			--here inst might be nil
		else
			--p("Not gollum")
			inst:AddTag("irreplaceable")
		end
		--inject to backpack
		if (not owner.gollum_injected) then
			owner.gollum_injected = true
			if inv.onputininventoryfn then
				inv.gollum_old_fn = inv.onputininventoryfn
			end
			inv:SetOnPutInInventoryFn(ContainerOnInventory)
		end
	else
		--p("Unknown place")
		inst:AddTag("irreplaceable")
	end
end

local function OnSave(inst, data)
	data.ring_userid = inst.ring_userid
	if type(data.owner)=="string" then
		data.owner = inst.owner
	end
end

local function OnLoad(inst, data)
	if data then
		inst.ring_userid = data.ring_userid
		if not inst.owner then
			inst.owner = data.owner
		end
		if not inst.rings_table then
			print('Error on load! Not inst.rings_table!')
		end
		if inst.ring_userid and inst.rings_table then
			local key = inst.ring_userid
			if not inst.rings_table[key] then
				inst.rings_table[key] = {}
			end
			table.insert(inst.rings_table[key],inst)
		end
	end
end

local function OnRemove(inst)
	if inst.rings_table and inst.ring_userid and inst.rings_table[inst.ring_userid] then
		local data = inst.rings_table[inst.ring_userid]
		for i=#data,1,-1 do
			if data[i] == inst then
				table.remove(data,i)
			end
		end
	end
end

local function fn(Sim)

	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)

	local minimap = inst.entity:AddMiniMapEntity()
	minimap:SetIcon( "ringmap.tex" )
	
	--inst:AddTag("irreplaceable")
	--inst:AddTag("nonpotatable")
	inst:AddTag("gollum_ring")
	inst:AddTag("icebox_valid")
	inst:AddTag("molebait")
	--inst:AddTag("cattoy")
	
	anim:SetBank("ring")
	anim:SetBuild("ring")
	anim:PlayAnimation("idle")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "ring"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/ring.xml"
	inst.components.inventoryitem.keepondeath = true
    inst.components.inventoryitem:SetOnDroppedFn(OnDropped)
    inst.components.inventoryitem:SetOnPutInInventoryFn(OnPutInInventory)
	
	inst:AddComponent("inspectable")
		
	inst:AddComponent("spellcaster")
	inst.components.spellcaster:SetSpellFn()
	inst.components.spellcaster.canuseontargets = false
	inst.components.spellcaster.canusefrominventory = false
	inst.components.spellcaster.canuseonpoint = false
		
	
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( OnEquip )
	inst.components.equippable:SetOnUnequip( OnUnequip )
--	  inst.components.equippable.dapperness = -(100/90)

	inst:AddComponent("bait")

	
	
	if SEASONS.AUTUMN then
		inst:AddComponent("waterproofer")
		inst.components.waterproofer:SetEffectiveness(0)
	end
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad
	inst.OnRemoveEntity = OnRemove

	
	return inst
end


return	Prefab("common/inventory/ring", fn, assets, prefabs)