local GetWorld = GLOBAL.GetWorld
local GetSeasonManager = GLOBAL.GetSeasonManager

AddSimPostInit(function(inst)

local oldactionstringoverride = inst.ActionStringOverride
	
	function inst:ActionStringOverride(bufaction)
		if bufaction.action == GLOBAL.ACTIONS.PICK and bufaction.target and bufaction.target.prefab == "pond" then
			return "Catch a fish in"
		elseif bufaction.action == GLOBAL.ACTIONS.PICK and bufaction.target and bufaction.target.prefab == "pond_mos" then
			return "Catch a fish in"
		elseif bufaction.action == GLOBAL.ACTIONS.PICK and bufaction.target and bufaction.target.prefab == "pond_cave" then
			return "Catch a fish in"
		end
		if oldactionstringoverride then
			return oldactionstringoverride(inst, bufaction)
		end
	end


	inst:DoPeriodicTask(0.01, function()
		if inst:HasTag("badring") then
			inst.AnimState:SetMultColour(0.05, 0.05, 0.05, 0.5)	
		else
			inst.AnimState:SetMultColour(1, 1, 1, 1)
		end
	end)
end)

function RawMeat(inst)
	inst:AddTag("rawmeat")
end

AddPrefabPostInit("meat", RawMeat)
AddPrefabPostInit("smallmeat", RawMeat)
AddPrefabPostInit("drumstick", RawMeat)
AddPrefabPostInit("eel", RawMeat)
AddPrefabPostInit("froglegs", RawMeat)
AddPrefabPostInit("batwing", RawMeat)
AddPrefabPostInit("trunk_summer", RawMeat)
AddPrefabPostInit("trunk_winter", RawMeat)

local function nowintercatch(inst)

		
	if GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsWinter() then
		if inst.components.pickable then
				inst:RemoveComponent("pickable")
		end
	
	
	elseif GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsSummer() then
			if not inst.components.pickable then
				inst:AddComponent("pickable")
				inst.components.pickable:SetUp("fish", TUNING.GRASS_REGROW_TIME)
			end

	
	elseif GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsSpring() then
			if not inst.components.pickable then
				inst:AddComponent("pickable")
				inst.components.pickable:SetUp("fish", TUNING.GRASS_REGROW_TIME)
			end	

	
	elseif GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsAutumn() then
			if not inst.components.pickable then
				inst:AddComponent("pickable")
				inst.components.pickable:SetUp("fish", TUNING.GRASS_REGROW_TIME)
			end	

end
end
	
function nowintercatch1(inst)


if GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsWinter() then
		if inst.components.pickable then
				inst:RemoveComponent("pickable")
		end


elseif GetPlayer().prefab == "gollum" and (inst.prefab == "pond" or inst.prefab == "pond_mos") and GetSeasonManager():IsSummer() then
		if not inst.components.pickable then
			inst:AddComponent("pickable")
			inst.components.pickable:SetUp("fish", TUNING.GRASS_REGROW_TIME)
		end	


end
end

	function CatchFish (inst)
		if GLOBAL.IsDLCEnabled(GLOBAL.REIGN_OF_GIANTS) then 
		inst:ListenForEvent( "seasonChange", function() nowintercatch(inst) end , GetWorld())
		nowintercatch(inst)
		else
		inst:ListenForEvent( "seasonChange", function() nowintercatch1(inst) end , GetWorld())
		nowintercatch1(inst)
		end
	
	end
	

function CatchEel (inst)
	--local function nowintercath (inst) 
		if GetPlayer().prefab == "gollum" then
					inst:AddComponent("pickable")
					inst.components.pickable:SetUp("eel", TUNING.GRASS_REGROW_TIME)
				--end
		end
	end

AddPrefabPostInit("pond", CatchFish)
AddPrefabPostInit("pond_mos", CatchFish)
AddPrefabPostInit("pond_cave", CatchEel)
