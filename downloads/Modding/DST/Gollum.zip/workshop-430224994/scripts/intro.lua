local function ModMaxwellIntro(inst)
    if GLOBAL.GetPlayer().prefab == "gollum" then
        inst.components.maxwelltalker.speeches.SANDBOX_1 =
        {
            appearsound = "dontstarve/maxwell/disappear",
	        voice = "dontstarve/maxwell/talk_LP",
		    appearanim = "appear",
		    idleanim= "idle",
		    dialogpreanim = "dialog_pre",
		    dialoganim="dial_loop",
		    dialogpostanim = "dialog_pst",
		    disappearanim = "disappear",
            disableplayer = true,
            skippable = false,
            {
                string = "You don't look so.. what? What do you have here?",
                wait = 3,
                anim = nil,
                sound = nil,
            },
            {
                string = " What a nice and shiny ring. I want to have it!",
                wait = 3,
                anim = nil,
                sound = nil,
            },
            {
                string = " It doesn't matter. I'll take it from what's left of you!",
                wait = 3,
                anim = nil,
                sound = nil,
            },

	}
    end
end

AddPrefabPostInit("maxwellintro", ModMaxwellIntro)
