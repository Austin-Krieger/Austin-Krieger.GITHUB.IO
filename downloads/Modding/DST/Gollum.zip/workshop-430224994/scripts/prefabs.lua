PrefabFiles = {
	"gollum",
	"ring",
}

Assets = {
    Asset( "IMAGE", "images/saveslot_portraits/gollum.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/gollum.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/gollum.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/gollum.xml" ),

    Asset( "IMAGE", "bigportraits/gollum.tex" ),
    Asset( "ATLAS", "bigportraits/gollum.xml" ),
	
	Asset("IMAGE", "images/gollum.tex"),
	Asset("ATLAS", "images/gollum.xml"),
	
	Asset("SOUNDPACKAGE", "sound/gollum.fev"),
	Asset("SOUND", "sound/gollum.fsb"),
	
	Asset("ATLAS", "images/inventoryimages/ringmap.xml"),
    Asset("IMAGE", "images/inventoryimages/ringmap.tex"),
	
	Asset("ATLAS", "images/ring_vision.xml"),
    Asset("IMAGE", "images/ring_vision.tex"),
  
}

