return {
	ACTIONFAIL =
	{
		SHAVE =
		{
			AWAKEBEEFALO = "It's to risky!",
			GENERIC = "We can't do this!",
			NOBITS = "We took everything from him!",
		},
		STORE =
		{
			GENERIC = "It's full, precious.",
			NOTALLOWED = "That can't go in there!",
		},
		ATTACK =
		{
			HAS_RING = "We can't attack now...",
		},
		DROP =
		{
			LOSE_UNWANTED = "No! What if we lose him?!",
		},
		GIVE =
		{
			ITS_MINE = "No! It's mine!",
		},
		GIVETOPLAYER =
		{
			ITS_MINE = "No! It's mine!",
		},
		PICK =
		{
			GENERIC = "We can't do that...",
			ICE = "We can't break the ice.",
		},
		ADDFUEL =
		{
			NO = "Noooooo!!!"
		},
	},
	ACTIONFAIL_GENERIC = "We can't do this!",
	ANNOUNCE_ADVENTUREFAIL = "We failed.",
	ANNOUNCE_BEES = "Filthy, little insects.",
	ANNOUNCE_BOOMERANG = "It hurts us!",
	ANNOUNCE_CHARLIE = "Shadow is after us!",
	ANNOUNCE_CHARLIE_ATTACK = "Smeagol is hurt!",
	ANNOUNCE_COLD = "Smeagol freezes!",
	ANNOUNCE_HOT = "It's to hot for us, Precious!",
	ANNOUNCE_CRAFTING_FAIL = "We failed, we failed!.",
	ANNOUNCE_DEERCLOPS = "We need to hide! Evil is near!",
	ANNOUNCE_DUSK = "The day is growing darker.",
	ANNOUNCE_EAT =
	{
		GENERIC = "We love that taste, precious!",
		PAINFUL = "We shouldn't eat this.",
		SPOILED = "Aaaaa! Horrible, horrible food!",
		STALE = "What's this, precious?",
		INVALID = "We can't eat this, precious.",
	},
	ANNOUNCE_ENTER_DARK = "They do not see what lies ahead, when Sun has faded and Moon is dead!",
	ANNOUNCE_ENTER_LIGHT = "We will follow the light.",
	ANNOUNCE_FREEDOM = "Smeagol is freeee!",
	ANNOUNCE_HIGHRESEARCH = "We made it, we made it!",
	ANNOUNCE_HOUNDS = "Sneaking? Sneaking?",
	ANNOUNCE_HUNGRY = "Our only wish, to catch a fish!",
	ANNOUNCE_HUNT_BEAST_NEARBY = "We will catch him soon!",
	ANNOUNCE_HUNT_LOST_TRAIL = "We lost it, we lost the trail!",
	ANNOUNCE_HUNT_LOST_TRAIL_SPRING = "We lost it, because of that stupid rain!",
	ANNOUNCE_INV_FULL = "Smeagol is too weak!",
	ANNOUNCE_KNOCKEDOUT = "Smeagol is hurt so much.",
	ANNOUNCE_LOWRESEARCH = "We failed again.",
	ANNOUNCE_MOSQUITOS = "Horrible insects from the wetlands!",
	ANNOUNCE_NODANGERSLEEP = "We can't close our eyes now!",
	ANNOUNCE_NODAYSLEEP = "It's day, precious. We can't sleep now.",
	ANNOUNCE_NODAYSLEEP_CAVE = "No sleep now!",
	ANNOUNCE_NOHUNGERSLEEP = "We need food, precious!",
	ANNOUNCE_NOSLEEPONFIRE = "Smeagol can't breath!",
	ANNOUNCE_NODANGERSIESTA = "Now we can't sleep!",
	ANNOUNCE_NONIGHTSIESTA = "No naps!",
	ANNOUNCE_NONIGHTSIESTA_CAVE = "We are too nervous, precious!",
	ANNOUNCE_NOHUNGERSIESTA = "We are too hungry!",
	ANNOUNCE_NO_TRAP = "It's broken..",
	ANNOUNCE_PECKED = "Bad pet!",
	ANNOUNCE_QUAKE = "The ground is moving!",
	ANNOUNCE_RESEARCH = "Smeagol is smart!",
	ANNOUNCE_SHELTER = "We are hiding! We are tricky!",
	ANNOUNCE_THORNS = "It hurts us!",
	ANNOUNCE_BURNT = "Why?!",
	ANNOUNCE_TORCH_OUT = "We are back in shadows.",
	ANNOUNCE_TRAP_WENT_OFF = "No! Not again!",
	ANNOUNCE_UNIMPLEMENTED = "You are a lier!",
	ANNOUNCE_WORMHOLE = "Filthy!",
	ANNOUNCE_CANFIX = "\nWe can fix this!",
	ANNOUNCE_ACCOMPLISHMENT = "We made it!",
	ANNOUNCE_ACCOMPLISHMENT_DONE = "If only my friends could see me now...",	
	ANNOUNCE_INSUFFICIENTFERTILIZER = "You need food, plant?",
	ANNOUNCE_TOOL_SLIP = "What?!",
	ANNOUNCE_LIGHTNING_DAMAGE_AVOIDED = "We cheated elements, precious.",

	ANNOUNCE_DAMP = "We are getting wet.",
	ANNOUNCE_WET = "Smeagol is wet!",
	ANNOUNCE_WETTER = "Too many water!",
	ANNOUNCE_SOAKED = "We came in like a water ball!",
	
	BATTLECRY =
	{
		GENERIC = "Murder!",
		PIG = "Die fat creature!",
		PREY = "Come to us! We want you to eat!",
		SPIDER = "Soon you'll be... eaten!",
		SPIDER_WARRIOR = "Soon! Soon you'll be... eaten!",
	},
	COMBAT_QUIT =
	{
		GENERIC = "He ran away! Aggggh!",
		PIG = "Stupid! Stupid pig!",
		PREY = "He's too fast, precious!",
		SPIDER = "We can go now.",
		SPIDER_WARRIOR = "We can go now.",
	},
	DESCRIBE =
	{
		RING = "My precious!",
        GLOMMER = "Naughty, big fly.",
        GLOMMERFLOWER = 
        {
        	GENERIC = "Smeagol likes this flower. It's pretty.",
        	DEAD = "Old flower.",
        },
        GLOMMERWINGS = "This wings are out of order! We are funny, precious.",
        GLOMMERFUEL = "Bleeeeh!",
        BELL = "Smeagol can play this cute bell.",
        STATUEGLOMMER = 
        {	
        	GENERIC = "What a waste of marble. Bleeeh!",
        	EMPTY = "Smeagol didn't touch anything!",
    	},

		WEBBERSKULL = "Special, ordinary skull?",
		WORMLIGHT = "Tricky plant! But we are smarter!",
		WORM =
		{
		    PLANT = "Tricky plant!",
		    DIRT = "Moving dirt. Smeagol is afraid!",
		    WORM = "We need to run, precious!",
		},
		MOLE =
		{
			HELD = "We can eat him! Yes we can!",
			UNDERGROUND = "Food is moving!",
			ABOVEGROUND = "We wants you, we wants you in our pot!",
		},
		MOLEHILL = "We don't know what we can find here!",
		MOLEHAT = "Smeagol looks stupid.",

		EEL = "Delicious fish from the depths.",
		EEL_COOKED = "Looks tasty, we need to try it!",
		UNAGI = "We made something odd, precious.",
		EYETURRET = "He wants our precious! We can't let him!",
		EYETURRET_ITEM = "We have created a dark lord?",
		MINOTAURHORN = "Smeagol has a trophy!",
		MINOTAURCHEST = "Chest full of treasures?",
		THULECITE_PIECES = "Strange pieces of metal.",
		POND_ALGAE = "Don't follow the lights.",
		GREENSTAFF = "This staff is full of magic.",
		POTTEDFERN = "Smeagol wants to decorate!",

		THULECITE = "Is this dwarven material?",
		ARMORRUINS = "Smeagol is well protected!",
		RUINS_BAT = "Smeagol can kill a lot of pigs!",
		RUINSHAT = "Smeagol is a king now!",
		NIGHTMARE_TIMEPIECE =
		{
		CALM = "Smeagol is safe.",
		WARN = "We must be prepared.",
		WAXING = "It's beautiful!",
		STEADY = "World is changing!",
		WANING = "Weakens...",
		DAWN = "World is changing again!",
		NOMAGIC = "Useless rock!",
		},
		BISHOP_NIGHTMARE = "We found evil priest!",
		ROOK_NIGHTMARE = "Rusty creatures, precious.",
		KNIGHT_NIGHTMARE = "Smeagol needs to escape!",
		MINOTAUR = "He's very powerful, precious! We Should avoid any contact.",
		SPIDER_DROPPER = "Filthy spider ambush us!",
		NIGHTMARELIGHT = "Some kind of evil source.",
		NIGHTSTICK = "How it works? We don't know, we don't know.",
		GREENGEM = "It's green like.. Smeagol can't remember.",
		RELIC = "Is is elven art?",
		RUINS_RUBBLE = "We don't like to put our food on the table!",
		MULTITOOL_AXE_PICKAXE = "Smeagol made something useful!",
		ORANGESTAFF = "We put a gem on a stick. That's all.",
		YELLOWAMULET = "This gem is very rare.",
		GREENAMULET = "Smeagol can change the world!",
		SLURPERPELT = "Much better than orcs skin, precious.",	

		SLURPER = "We never knew that something like this lives here!",
		SLURPER_PELT = "Much better than orcs skin, precious.",
		ARMORSLURPER = "Smeagol is hairy!",
		ORANGEAMULET = "This gem absorbs things!",
		YELLOWSTAFF = "Shiny yellow staff we made!",
		YELLOWGEM = "It's so yellow.",
		ORANGEGEM = "It's so orange, just like.. we don't know what.",
		TELEBASE = 
		{
			VALID = "It's ready to go!",
			GEMS = "We needs more shiny gems!",
		},
		GEMSOCKET = 
		{
			VALID = "Looks ready, precious.",
			GEMS = "It still needs a gem.",
		},
		STAFFLIGHT = "Pure light, precious.",
	
        ANCIENT_ALTAR = "Odd structure, precious.",

        ANCIENT_ALTAR_BROKEN = "Odd structure is broken!",

        ANCIENT_STATUE = "Dark statue. Smeagol don't like this!",

        LICHEN = "Looks good, taste good?",
		CUTLICHEN = "Is this macaroni with spinach? We hope not.",

		CAVE_BANANA = "Smeagol is not a wild animal!",
		CAVE_BANANA_COOKED = "Taste great, precious!",
		CAVE_BANANA_TREE = "Smeagol is not a wild animal!",
		ROCKY = "Mountain troll is revived?",
		
		COMPASS =
		{
			GENERIC="What's this?",
			N = "That way!",
			S = "This way!",
			E = "Here!",
			W = "That way!",
			NE = "Here!",
			SE = "Here!",
			NW = "That way!",
			SW = "This way",
		},

		NIGHTMARE_TIMEPIECE =
		{
		    WAXING = "It's beautiful!",
		    STEADY = "World is changing!",
			WANING = "Weakens...",
			DAWN = "World looks again like before!",
			WARN = "We must be prepared.",
			CALM = "Smeagol is safe.",
			NOMAGIC = "Useless rock!",
		},

		HOUNDSTOOTH="It's sharp, precious!",
		ARMORSNURTLESHELL="Smeagol is protected!",
		BAT="Blind creatures. We hate them!",
		BATBAT = "Demonic weapon! We are happy!",
		BATWING="Bat is broken.",
		BATWING_COOKED="Tasty meat won't fly away!",
		BEDROLL_FURRY="We used to sleep on rocks.",
		BUNNYMAN="Big, fat and hairy meat!",
		FLOWER_CAVE="Is this an elven plant?",
		FLOWER_CAVE_DOUBLE="Is this an elven plant?",
		FLOWER_CAVE_TRIPLE="Is this an elven plant?",
		GUANO="Similar to troll poop.",
		LANTERN="Smeagol is enlightened.",
		LIGHTBULB="Can we eat this or not?",
		MANRABBIT_TAIL="For luck.",
		MUSHTREE_TALL  ="Smeagol is dizzy.",
		MUSHTREE_MEDIUM="Smeagol is dizzy.",
		MUSHTREE_SMALL ="Smeagol is dizzy.",
		RABBITHOUSE=
		{
			GENERIC = "Giant veggie! No!",
			BURNT = "Veggie house is gone!",
		},
		SLURTLE="Filthy creature full of slime!",
		SLURTLE_SHELLPIECES="How we can use it?",
		SLURTLEHAT="Too big for our head?",
		SLURTLEHOLE="Filthy cocoon!",
		SLURTLESLIME="We can use this, instead of gunpowder!",
		SNURTLE="Filthy creature full of slime!",
		SPIDER_HIDER="Armoured spider!",
		SPIDER_SPITTER="We spit on you!",
		SPIDERHOLE="Rock full of webs!",
		STALAGMITE="We used to jump on that rocks.",
		STALAGMITE_FULL="We used to jump on that rocks.",
		STALAGMITE_LOW="We used to sleep on that rocks.",
		STALAGMITE_MED="We used to eat on that rocks.",
		STALAGMITE_TALL="We used to jump on that rocks.",
		STALAGMITE_TALL_FULL="We used to jump on that rocks.",
		STALAGMITE_TALL_LOW="We used to sleep on that rocks.",
		STALAGMITE_TALL_MED="We used to eat on that rocks.",

		TURF_CARPETFLOOR = "Some ground, precious.",
		TURF_CHECKERFLOOR = "Some ground, precious.",
		TURF_DIRT = "Some ground, precious.",
		TURF_FOREST = "Some ground, precious.",
		TURF_GRASS = "Some ground, precious.",
		TURF_MARSH = "Some ground, precious.",
		TURF_ROAD = "Some ground, precious.",
		TURF_ROCKY = "Some ground, precious.",
		TURF_SAVANNA = "Some ground, precious.",
		TURF_WOODFLOOR = "Some ground, precious.",

		TURF_CAVE="Some ground, precious.",
		TURF_FUNGUS="Some ground, precious.",
		TURF_SINKHOLE="Some ground, precious.",
		TURF_UNDERROCK="Some ground, precious.",
		TURF_MUD="Some ground, precious.",

		TURF_DECIDUOUS = "Some ground, precious.",
		TURD_SANDY = "Some ground, precious.",
		TURF_BADLANDS = "Some ground, precious.",

		POWCAKE = "Useless.",
        CAVE_ENTRANCE = 
        {
            GENERIC="Something is hidden, precious.",
            OPEN = "Dark hole. We smell caves.",
        },
        CAVE_EXIT = "Smeagol don't want to go up.",
		MAXWELLPHONOGRAPH = "We wish it could play Arwen's song. Hihi.",
		BOOMERANG = "We can kill in the distance!",
		PIGGUARD = "This pig is crazy, precious.",
		ABIGAIL = "Friendly ghost? That's odd, precious.",
		ADVENTURE_PORTAL = "A poor copy of a black gate!",
		AMULET = "Smeagol can cheat death!",
		ANIMAL_TRACK = "We are hunting!",
		ARMORGRASS = "We can hide in a grass!",
		ARMORMARBLE = "We can't run fast anymore using it!",
		ARMORWOOD = "We made flammable armor.",
		ARMOR_SANITY = "We just imagined armor.",
		ASH =
		{
			GENERIC = "All that's left after fire, precious.",
			REMAINS_GLOMMERFLOWER = "The flower was consumed by fire, precious!",
			REMAINS_EYE_BONE = "The eyebone was consumed by fire, precious!!",
			REMAINS_THINGIE = "This was once some thing before it got burned, precious.",
		},
		AXE = "We can chop animals!",
		BABYBEEFALO = "Smeagol don't want to hurt him!",
		BACKPACK = "We can put a lot of fishes in it!",
		BACONEGGS = "We need to taste it!",
		BANDAGE = "Smeagol can patch himself!",
		BASALT = "Unbreakable rock, precious!",
		BATBAT = "Demonic weapon! We are happy!",
		BEARDHAIR = "Smaller than dwarven beard.",
		BEARGER = "We never encounter such powerful bear!",
		BEARGERVEST = "Smeagol has some new clothes!",
		ICEPACK = "Our fishes will stay fresh much longer!",
		BEARGER_FUR = "A fur ripped from beast.",
		BEDROLL_STRAW = "We prefer rocks as a bed.",
		BEE =
		{
			GENERIC = "Nasty insects!",
			HELD = "Smeagol has a new pet!",
		},
		BEEBOX =
		{
			FULLHONEY = "A lot of sweets!.",
			GENERIC = "A cage for useful insects.",
			NOHONEY = "It's empty, precious.",
			SOMEHONEY = "We should wait for more.",
			BURNT = "We lost our cage! We hate fire!",
		},
		BEEFALO =
		{
			FOLLOWER = "Our own servant!",
			GENERIC = "Our meal is hidden under the wool!",
			NAKED = "Meal is no longer hidden!",
			SLEEPING = "Beast is sleeping now.",
		},
		BEEFALOHAT = "Smeagol looks more aggressive now?",
		BEEFALOWOOL = "It's soft and practical.",
		BEEHAT = "Insects can't hurt us!",
		BEEHIVE = "Colony of.. 6 bees. Maybe more.",
		BEEMINE = "A bomb full of anger.",
		BEEMINE_MAXWELL = "Bottled bloodsuckers!",
		BERRIES = "We like something more meaty, precious.",
		BERRIES_COOKED = "It's ugly paste!",
		BERRYBUSH =
		{
			BARREN = "We need poop.",
			WITHERED = "This plant is dead, precious.",
			GENERIC = "Some awful fruits.",
			PICKED = "We don't need it.",
		},
		BIGFOOT = "What's this, precious?!",
		BIRDCAGE =
		{
			GENERIC = "We can have a slave!",
			OCCUPIED = "You will do as we say!",
			SLEEPING = "You can sleep for a while.",
		},
		BIRDTRAP = "Smeagol is smart!",
		BIRD_EGG = "We can steal it!",
		BIRD_EGG_COOKED = "Tasty, precious!",
		BISHOP = "Our mechanical enemy!",
		BLOWDART_FIRE = "We can set fire, over the mountains!",
		BLOWDART_SLEEP = "Sweet dreams, prey.",
		BLOWDART_PIPE = "We can stub enemies from far away!",
		BLUEAMULET = "It's so cold, precious! So cold.",
		BLUEGEM = "It's blue and cold.",
		BLUEPRINT = "Something is written on it?",
		BELL_BLUEPRINT = "Something is written here.",
		BLUE_CAP = "We are used to the meat.",
		BLUE_CAP_COOKED = "Now it's much better!",
		BLUE_MUSHROOM =
		{
			GENERIC = "We are used to the meat.",
			INGROUND = "Where is the cap?",
			PICKED = "It will regrow, precious.",
		},
		BOARDS = "Organized wood.",
		BOAT = "Filthy cheater! You are using console again?!",
		BONESHARD = "Bits of bone from beasts.",
		BONESTEW = "Tasty meal, only for us!",
		BUGNET = "We can catch insects using it!",
		BUSHHAT = "Smeagol is hiding!",
		BUTTER = "What's this, precious?",
		BUTTERFLY =
		{
			GENERIC = "What's this? Is it edible?",
			HELD = "We will eat you!",
		},
		BUTTERFLYMUFFIN = "This meal is too odd!",
		BUTTERFLYWINGS = "Some food ripped from flying ones.",
		BUZZARD = "It's a very ugly bird.",
		CACTUS = 
		{
			GENERIC = "Aggressive plant!",
			PICKED = "It has spikes on it.",
		},
		CACTUS_MEAT_COOKED = "It's burned. Is it better now?",
		CACTUS_MEAT = "You can't trick us, it's not a meat!",
		CACTUS_FLOWER = "Colourful part of the plant.",

		COLDFIRE =
		{
			EMBERS = "It's getting weaker, my precious.",
			GENERIC = "Cold fire? What magic is this?",
			HIGH = "We enjoy it! We enjoy it!",
			LOW = "Weak flame of ice.",
			NORMAL = "It's rather calm, precious.",
			OUT = "No, No!",
		},
		CAMPFIRE =
		{
			EMBERS = "It's getting weaker, my precious.",
			GENERIC = "We can rise the fire level!",
			HIGH = "Cosy, cosy and warm!",
			LOW = "Not so big anymore.",
			NORMAL = "Nothing special. Nothing interesting.",
			OUT = "No more light for us.",
		},
		CANE = "Smeagol is faster!",
		CATCOON = "This beast is crazy. Right precious?",
		CATCOONDEN = 
		{
			GENERIC = "Someone lives here. We can smell it.",
			EMPTY = "Too small, we can't live here.",
		},
		CATCOONHAT = "We never used to wear hats.",
		COONTAIL = "We cut it, we cut it!",
		CARROT = "Blah! We prefer meat!",
		CARROT_COOKED = "Pieces of veggie, nothing tasty!",
		CARROT_PLANTED = "We prefer meat! Not veggie!",
		CARROT_SEEDS = "We know, we know what's inside. Filthy carrot!",
		WATERMELON_SEEDS = "Wet seeds, precious.",
		CAVE_FERN = "We can burn it for light!",
		CHARCOAL = "Darkness possessed this wood!",
        CHESSJUNK1 = "It's broken, but we can fix it!",
        CHESSJUNK2 = "We need something to patch this!",
        CHESSJUNK3 = "Smeagol wants to fix this!",
		CHESTER = "You want fishes? Never!",
		CHESTER_EYEBONE =
		{
			GENERIC = "Is this a goblin artefact?",
			WAITING = "It's sleeping now.",
		},
		COOKEDMANDRAKE = "We killed it! With fire!",
		COOKEDMEAT = "Aah! We love it! We love it!",
		COOKEDMONSTERMEAT = "It's not an ordinary meat, precious.",
		COOKEDSMALLMEAT = "A small snack for us!",
		COOKPOT =
		{
			COOKING_LONG = "Something is happening inside.",
			COOKING_SHORT = "Is it going to explode, precious?",
			DONE = "Surprise!",
			EMPTY = "There's nothing here! Gollum! Gollum!",
			BURNT = "We can't used it now!",
		},
		CORN = "What is that?!",
		CORN_COOKED = "Smells funny, precious.",
		CORN_SEEDS = "Some seed, sit here.",
		CROW =
		{
			GENERIC = "Spies everywhere!",
			HELD = "You can't run now!",
		},
		CUTGRASS = "What now? What should we do with it?",
		CUTREEDS = "We can clean ears using it!",
		CUTSTONE = "We are great in cutting stones!",
		DEADLYFEAST = "Filthy cheater! You are using console again?!",
		DEERCLOPS = "Don't hurt us! We are only.. sneaking.",
		DEERCLOPS_EYEBALL = "We can eat it or use somehow.",
		EYEBRELLAHAT =	"Very odd hat for us.",
		DEPLETED_GRASS =
		{
			GENERIC = "Old grass, precious.",
		},
		DEVTOOL = "???",
		DEVTOOL_NODEV = "???",
		DIRTPILE = "Pile of dirt, left by prey!",
		DIVININGROD =
		{
			COLD = "We are going to lose it!",
			GENERIC = "We can search for treasures!",
			HOT = "It's shaking!",
			WARM = "It's getting warmer, precious.",
			WARMER = "Very, very warm!",
		},
		DIVININGRODBASE =
		{
			GENERIC = "What's this? How it works?",
			READY = "We need a key!",
			UNLOCKED = "It's ready, it's ready!",
		},
		DIVININGRODSTART = "Useful! Useful!",
		DRAGONFLY = "There is no web that can catch this fly!",
		ARMORDRAGONFLY = "Too heavy for us!",
		DRAGON_SCALES = "We can use it, as a protection.",
		DRAGONFLYCHEST = "We want to keep precious in our pocket!",
		LAVASPIT = 
		{
			HOT = "It can hurt us!",
			COOL = "Not so hot now, precious.",
		},
		DRAGONFRUIT = "Bleh. We hate it!",
		DRAGONFRUIT_COOKED = "We know, it's still just an ugly fruit!",
		DRAGONFRUIT_SEEDS = "Some filthy fruit seeds.",
		DRAGONPIE = "Bleeh!",
		DRUMSTICK = "We love the taste!",
		DRUMSTICK_COOKED = "We love it! So tasty!",
		DUG_BERRYBUSH = "We can burn it! Yes precious!",
		DUG_GRASS = "We should toss it into the fire!",
		DUG_MARSH_BUSH = "Aggressive plant will burn!",
		DUG_SAPLING = "Should we replant it, or burn?",
		DURIAN = "Bleh! Ugly smell!",
		DURIAN_COOKED = "It's horrible, precious!",
		DURIAN_SEEDS = "Seeds with horrible smell!",
		EARMUFFSHAT = "Smeagol looks nice!",
		EGGPLANT = "Purple and.. ugly, precious!",
		EGGPLANT_COOKED = "Still insipid!",
		EGGPLANT_SEEDS = "Some egg seeds.",
		DECIDUOUSTREE = 
		{
			BURNING = "Smeagol wouldn't hurt a fly!",
			BURNT = "Corpse of a tree.",
			CHOPPED = "This resource has already been used.",
			POISON = "This tree is possessed!",
			GENERIC = "Looks like tree from elven town! Bleh!",
		},
		ACORN = 
		{
		    GENERIC = "Maybe we could use it as a weapon?",
		    PLANTED = "We are creating nature!",
		},
		ACORN_COOKED = "Some pieces.",
		BIRCHNUTDRAKE = "Awful! Just like goblins!",
		EVERGREEN =
		{
			BURNING = "What happened, precious?!",
			BURNT = "Not much left.",
			CHOPPED = "It's already chopped, precious.",
			GENERIC = "Looks like tree from darkwood.",
		},
		EVERGREEN_SPARSE =
		{
			BURNING = "What happened, precious?!",
			BURNT = "Not much left.",
			CHOPPED = "It's already chopped, precious.",
			GENERIC = "Nothing special, precious.",
		},
		EYEPLANT = "What's this? Meat or plant?",
		FARMPLOT =
		{
			GENERIC = "We can use it to plant useless fruits and veggies!",  
			GROWING = "It grows, we don't care!",
			NEEDSFERTILIZER = "We can use poop, or we can just leave it.",
			BURNT = "Ha! It's gone, precious.",
		},
		FEATHERHAT = "Smeagol has a camouflage!",
		FEATHER_CROW = "A spy feather.",
		FEATHER_ROBIN = "We can use it somehow.",
		FEATHER_ROBIN_WINTER = "Cold feathers.",
		FEM_PUPPET = "It's a trap!",
		FIREFLIES =
		{
			GENERIC = "We shouldn't follow the light.",
			HELD = "Not so dangerous anymore.",
		},
		FIREHOUND = "Look like angry warg!",
		FIREPIT =
		{
			EMBERS = "It's getting weaker, my precious.",
			GENERIC = "We can rise the fire level!",
			HIGH = "Cosy, cosy and warm!",
			LOW = "Not so big anymore.",
			NORMAL = "Nothing special. Nothing interesting.",
			OUT = "No more light for us.",
		},
		COLDFIREPIT =
		{
			EMBERS = "It's getting weaker, my precious.",
			GENERIC = "Cold fire? What magic is this?",
			HIGH = "We enjoy it! We enjoy it!",
			LOW = "Weak flame of ice.",
			NORMAL = "It's rather calm, precious.",
			OUT = "No, No!",
		},
		FIRESTAFF = "Funny weapon, precious.",
		FIRESUPPRESSOR = 
		{	
			ON = "It can protect us from fire!",
			OFF = "It's sleeping.",
			LOWFUEL = "We need fuel, precious.",
		},

		FISH = "So juicy sweet!",
		FISHINGROD = "We don't need this, silly!",
		FISHSTICKS = "Smell good! Smells fantastic!",
		FISHTACOS = "We love it! We must taste it!",
		FISH_COOKED = "Cooked fishes are so delicious!",
		FLINT = "It's very useful, very useful!",
		FLOWER = "Some silly decoration.",
		FLOWERHAT = "Smeagol is pretty!",
		FLOWER_EVIL = "Cute plant.",
		FOLIAGE = "Leafy. Nothing else.",
		FOOTBALLHAT = "We are protected, we can fight!",
		FROG =
		{
			DEAD = "Meat isn't moving!",
			GENERIC = "Jumping meat!",
			SLEEPING = "Meat is sleeping.",
		},
		FROGGLEBUNWICH = "Tasty!",
		FROGLEGS = "A small snack for just for us!",
		FROGLEGS_COOKED = "That's even tastier, precious!",
		FRUITMEDLEY = "So ugly!",
		GEARS = "What's this? Looks complicated.",
		GHOST = "Evil is after us!",
		GOLDENAXE = "Shiny axe!",
		GOLDENPICKAXE = "So shiny!",
		GOLDENPITCHFORK = "Such a waste of gold, precious.",
		GOLDENSHOVEL = "Golden shovel!",
		GOLDNUGGET = "Our precious has more value!",
		GRASS =
		{
			BARREN = "Useless now.",
			WITHERED = "No grass, no use.",
			BURNING = "No! We need this!",
			GENERIC = "It's a grass, precious.",
			PICKED = "Smeagol can make.. something!",
		},
		GREEN_CAP = "We are used to the meat.",
		GREEN_CAP_COOKED = "Now it's better.",
		GREEN_MUSHROOM =
		{
			GENERIC = "We are used to the meat.",
			INGROUND = "Where is the cap?",
			PICKED = "It will regrow, precious.",
		},
		
		GUNPOWDER = "Such power!",
		HAMBAT = "Tasty weapon!",
		HAMMER = "We can smash anything!",
		HEALINGSALVE = "Ugly healing.",
		HEATROCK =
		{
			FROZEN = "It's freezing!",
			COLD = "So cold, precious.",
			GENERIC = "Stone.",
			WARM = "Warm rock, precious.",
			HOT = "Very hot! Very hot!",
		},
		HOME = "What's home precious?",
		HOMESIGN = 
		{
			GENERIC = "Useful marker.",
			BURNT = "It's dead!",
		},
		HONEY = "Tasty, precious.",
		HONEYCOMB = "Part of home of insects.",
		HONEYHAM = "Our meaty meal taste better!",
		HONEYNUGGETS = "So tasty, precious!",
		HORN = "Nice trophy, precious!",
		HOUND = "Aggressive warg!",
		HOUNDBONE = "Bones from warg.",
		HOUNDMOUND = "Ugly warg den.",
		ICEBOX = "Box for fishes!",
		ICEHAT = "It's so heavy!",
		ICEHOUND = "Frozen warg!",
		INSANITYROCK =
		{
			ACTIVE = "What's this?!",
			INACTIVE = "Strange stone, precious.",
		},
		JAMMYPRESERVES = "Bleh!",
		KABOBS = "Interesting, precious!",
		KILLERBEE =
		{
			GENERIC = "Aggressive insect!",
			HELD = "Now you want hurt us!",
		},
		KNIGHT = "Horrible creation, precious!",
		KOALEFANT_SUMMER = "So many warm meat! We need to catch him!",
		KOALEFANT_WINTER = "So many cold meat! We need to catch him!",
		KRAMPUS = "Stay away from precious!",
		KRAMPUS_SACK = "We can put a lot of stuff here! We are lucky!",
		LEIF = "Ent isn't sleeping!",
		LEIF_SPARSE = "That's huge ent!",
		LIGHTNING_ROD =
		{
			CHARGED = "The power is ours!",
			GENERIC = "Protection against storm, precious.",
		},
		LIGHTNINGGOAT = 
		{
			GENERIC = "Mad creature, not like us!",
			CHARGED = "Evil possessed this creature!",
		},
		LIGHTNINGGOATHORN = "What can we do with this, precious?",
		GOATMILK = "Milk from goats. Bleh!",
		LITTLE_WALRUS = "We will eat you.. soon!",
		LIVINGLOG = "Wood from ent?",
		LOCKEDWES = "Little fellow, precious.",
		LOG =
		{
			BURNING = "We have light!",
			GENERIC = "We can burn it, precious.",
		},
		LUREPLANT = "We can't trust him!",
		LUREPLANTBULB = "Evil seed!",
		MALE_PUPPET = "He's trapped!",
		MANDRAKE =
		{
			DEAD = "We love silence!",
			GENERIC = "This plant is different, precious.",
			PICKED = "Too loud, too loud!",
		},
		MANDRAKESOUP = "Soop is silly!",
		MANDRAKE_COOKED = "It won't scream anymore!",
		MARBLE = "Very durable material, precious.",
		MARBLEPILLAR = "We could destroy it!",
		MARBLETREE = "We can crash it! Yes, we can!",
		MARSH_BUSH =
		{
			BURNING = "It's wasted, precious.",
			GENERIC = "Thorny!",
			PICKED = "We can plant this cute bushes.",
		},
		MARSH_PLANT = "Thorny!",
		MARSH_TREE =
		{
			BURNING = "Very big torch!",
			BURNT = "It's dead.",
			CHOPPED = "We destroyed it!",
			GENERIC = "Look sharp!",
		},
		MAXWELL = "He is full of evil!",
		MAXWELLHEAD = "Smeagol is afraid!",
		MAXWELLLIGHT = "Evil light, precious.",
		MAXWELLLOCK = "A hole.",
		MAXWELLTHRONE = "Evil is here.",
		MEAT = "We love this sweet taste!",
		MEATBALLS = "We shouldn't play with our food!",
		MEATRACK =
		{
			DONE = "Dried meat! It's great, precious!",
			DRYING = "We need to wait.",
			DRYINGINRAIN = "Nasty rain! Nasty!",
			GENERIC = "We can make even tastier meat!",
			BURNT = "End of story.",
		},
		MEAT_DRIED = "We wants it! We wants it!",
		MERM = "This fish is too large to be able to chew it!",
		MERMHEAD = 
		{
			GENERIC = "Poor fish.",
			BURNT = "Nothing left from this fat fish.",
		},
		MERMHOUSE = 
		{
			GENERIC = "Fishes used to leave in water.",
			BURNT = "What a shame, precious.",
		},
		MINERHAT = "We can explore caves easier!",
		MONKEY = "Hairy thief! Stay away!",
		MONKEYBARREL = "What's inside?",
		MONSTERLASAGNA = "Only sandwich we like!",
		FLOWERSALAD = "A bowl full of bleh!",
        ICECREAM = "Stupid idea, precious.",
        WATERMELONICLE = "Bleh on a stick!",
        TRAILMIX = "We don't trust it.",
        HOTCHILI = "Hot! So hot!",
        GUACAMOLE = "Interesting, precious.",
		MONSTERMEAT = "Smells strange, but we want to try it!",
		MONSTERMEAT_DRIED = "Even tastier meat!",
		MOOSE = "Crazy bird! We should run, precious!",
		MOOSEEGG = "Magic egg!",
		MOSSLING = "We should eat them before they grow up!",
		FEATHERFAN = "Smeagol is fancy!",
		GOOSE_FEATHER = "So nice! We like it!",
		STAFF_TORNADO = "Chaotic weapon is ours!",
		MOSQUITO =
		{
			GENERIC = "He wants our blood!",
			HELD = "Maybe we can use you somehow.",
		},
		MOSQUITOSACK = "We can use it, precious.",
		MOUND =
		{
			DUG = "We never used to dig graves.",
			GENERIC = "A tomb, precious.",
		},
		NIGHTLIGHT = "Very strange type of fire.",
		NIGHTMAREFUEL = "Evil can be material?",
		NIGHTSWORD = "Great power in our hands!",
		NITRE = "Something useful, maybe.",
		ONEMANBAND = "We used to leave in silence!",
		PANDORASCHEST = "New treasures, precious?",
		PANFLUTE = "Magic artefact.",
		PAPYRUS = "Some paper, precious.",
		PENGUIN = "Fat bird!",
		PERD = "Come back running meat!",
		PEROGIES = "Not so special.",
		PETALS = "What should we do with this?",
		PETALS_EVIL = "It looks cute, precious.",
		PICKAXE = "Not so durable, precious.",
		PIGGYBACK = "Large backpack made from meat!",
		PIGHEAD = 
		{	
			GENERIC = "Meaty head, precious.",
			BURNT = "What's this?",
		},
		PIGHOUSE =
		{
			FULL = "Fat pig is hiding!",
			GENERIC = "House of pigs.",
			LIGHTSOUT = "Give me light!",
			BURNT = "It's dead.",
		},
		PIGKING = "Large ham!",
		PIGMAN =
		{
			DEAD = "A lot of meat!",
			FOLLOWER = "Stupid pig will fight for us!",
			GENERIC = "Walking ham!",
			GUARD = "Very aggressive meat!",
			WEREPIG = "Crazy ham, precious!",
		},
		PIGSKIN = "Tasty material.",
		PIGTENT = "Smells like meat, precious.",
		PIGTORCH = "This torch is attracting meat.",
		PINECONE = 
		{
		    GENERIC = "Wood seed. Nothing special.",
		    PLANTED = "Smeagol is a gardener now!",
		},
		PITCHFORK = "That's useful tool, precious.",
		PLANTMEAT = "Veggie meat? Bleh!",
		PLANTMEAT_COOKED = "It wants to trick us!",
		PLANT_NORMAL =
		{
			GENERIC = "Bleh! Waste of time!",
			GROWING = "We don't care!",
			READY = "We can toss it now!",
			WITHERED = "Yes! Heat destroyed it!",
		},
		POMEGRANATE = "We don't like it!",
		POMEGRANATE_COOKED = "Bleh!",
		POMEGRANATE_SEEDS = "Seed...seed...seed.",
		POND = "Give it to us raw, and wriggling!",
		POOP = "Stinky poop!",
		FERTILIZER = "Awful, precious! It's awful!",
		PUMPKIN = "We don't want to eat it!",
		PUMPKINCOOKIE = "Horrible!",
		PUMPKIN_COOKED = "Bleh!",
		PUMPKIN_LANTERN = "Veggie gives light!",
		PUMPKIN_SEEDS = "Some seeds.",
		PURPLEAMULET = "We have our precious! Do we need this?",
		PURPLEGEM = "It contains evil!",
		RABBIT =
		{
			GENERIC = "Eat them, eat them!",
			HELD = "What we have found?",
		},
		RABBITHOLE = 
		{
			GENERIC = "Hole of a rabbit.",
			SPRING = "Soaked hole!",
		},
		RAINOMETER = 
		{	
			GENERIC = "What's this?",
			BURNT = "No longer useful, precious.",
		},
		RAINCOAT = "We are safe now.",
		RAINHAT = "We are safe. We don't like to be wet.",
		RATATOUILLE = "Ugly meal!",
		RAZOR = "Can we use it as a weapon, precious?",
		REDGEM = "It's warm, precious.",
		RED_CAP = "We are used to the meat.",
		RED_CAP_COOKED = "Still ugly!",
		RED_MUSHROOM =
		{
			GENERIC = "We are used to the meat.",
			INGROUND = "Where is the cap?",
			PICKED = "It will regrow, precious.",
		},
		
		REEDS =
		{
			BURNING = "Funny sticks are burning!",
			GENERIC = "It's a reeds, precious.",
			PICKED = "Nothing left.",
		},
        RELIC = 
        {
            GENERIC = "What's this?",
            BROKEN = "It's broken, precious.",
        },
        RUINS_RUBBLE = "We can fix it!",
        RUBBLE = "Pieces of rock.",
		RESEARCHLAB = 
		{	
			GENERIC = "Strange machine.",
			BURNT = "It's dead.",
		},
		RESEARCHLAB2 = 
		{
			GENERIC = "Strange machine, precious.",
			BURNT = "It's dead.",
		},
		RESEARCHLAB3 = 
		{
			GENERIC = "What is it, precious? Tell me!",
			BURNT = "It's dead.",
		},
		RESEARCHLAB4 = 
		{
			GENERIC = "Impressive! Right precious?",
			BURNT = "It's dead.",
		},
		RESURRECTIONSTATUE = 
		{
			GENERIC = "How it works? We want to know!",
			BURNT = "It's dead.",
		},
		RESURRECTIONSTONE = "How it works, precious?",
		ROBIN =
		{
			GENERIC = "We should catch him, precious!",
			HELD = "Stay calm, and we won't hurt you.. yet.",
		},
		ROBIN_WINTER =
		{
			GENERIC = "Smeagol wants a pet!",
			HELD = "Stay calm, meat.",
		},
		ROBOT_PUPPET = "It's trapped, precious!",
		ROCK_LIGHT =
		{
			GENERIC = "It's odd, precious.",
			OUT = "Looks fragile right?",
			LOW = "The lava's crusting over, precious.",
			NORMAL = "Nice! Nice!",
		},
		ROCK = "It's Full of smaller rocks, precious.",
		ROCK_ICE = 
		{
			GENERIC = "Giant piece of ice, precious.",
			MELTED = "Rock is falling apart.",
		},
		ROCK_ICE_MELTED = "Ice rock is falling apart.",
		ICE = "Very cold, very cold.",
		ROCKS = "We used to toss them!",
        ROOK = "Dangerous enemy!",
		ROPE = "We can use it for sure, precious!",
		ROTTENEGG = "Looks awful, precious!",
		SANITYROCK =
		{
			ACTIVE = "Evil rock!",
			INACTIVE = "Little rock full of evil.",
		},
		SAPLING =
		{
			BURNING = "It's burning!",
			WITHERED = "Heat killed it!",
			GENERIC = "A plant full of sticks, precious.",
			PICKED = "It's not here, precious.",
		},
		SEEDS = "Seeds. What's inside?",
		SEEDS_COOKED = "We prefer meat, even small snacks.",
		SEWING_KIT = "What now? How it works?",
		SHOVEL = "We can dig in the ground.",
		SILK = "Stinky material.",
		SKELETON = "He probably run out of meat!",
		SKELETON_PLAYER = "Better him, precious!",
		SKULLCHEST = "Interesting chest, cheater!",
		SMALLBIRD =
		{
			GENERIC = "Meat full of feathers.",
			HUNGRY = "Stop making noises!",
			STARVING = "Smeagol will feed you!",
		},
		SMALLMEAT = "Raw piece of meat, just for us!",
		SMALLMEAT_DRIED = "Dried meat taste much better, precious!",
		SPEAR = "Not so powerful, precious.",
		SPIDER =
		{
			DEAD = "It's dead for good.",
			GENERIC = "We used to meet bigger spiders.",
			SLEEPING = "Now we can surprise him!",
		},
		SPIDERDEN = "Cocoon made of silk.",
		SPIDEREGGSACK = "We can start colony of spiders.",
		SPIDERGLAND = "Could be useful, precious.",
		SPIDERHAT = "Smeagol looks horrible with this!",
		SPIDER_WARRIOR =
		{
			DEAD = "Finally it's not moving!",
			GENERIC = "Fighting meat!",
			SLEEPING = "Be gone ugly monster!",
		},
		SPOILED_FOOD = "Meal is dead! No!",
		STATUEHARP = "ugly statue!",
		STATUEMAXWELL = "We hate him! We hate him!",
		STINGER = "It can hurt someone!",
		STRAWHAT = "Smeagol will look like a farmer!",
		STUFFEDEGGPLANT = "Bleeeh!",
		SUNKBOAT = "Console again! Gollum! Gollum!",
		SWEATERVEST = "It's gross!",
		REFLECTIVEVEST = "We look better without it!",
		HAWAIIANSHIRT = "Smeagol will look stupid?",
		TAFFY = "What's this, precious?",
		TALLBIRD = "Ugly and evil bird!",
		TALLBIRDEGG = "It's so colourful!",
		TALLBIRDEGG_COOKED = "It looks much worst now!",
		TALLBIRDEGG_CRACKED =
		{
			COLD = "It's very cold, precious!",
			GENERIC = "It's moving!",
			HOT = "This egg will burn!",
			LONG = "Too long, precious.",
			SHORT = "It should hatch soon.",
		},
		TALLBIRDNEST =
		{
			GENERIC = "Bird's bed.",
			PICKED = "Bird's bed.",
		},
		TEENBIRD =
		{
			GENERIC = "This bird is evil!",
			HUNGRY = "Hungry meat.",
			STARVING = "Leave us alone!",
		},
		TELEBASE =
		{
			VALID = "It's ready! Ready!",
			GEMS = "It needs more evil gems, precious.",
		},
		GEMSOCKET = 
		{
			VALID = "Looks ready, precious.",
			GEMS = "It still needs a gem.",
		},
		TELEPORTATO_BASE =
		{
			ACTIVE = "Going home, going home!",
			GENERIC = "Is this some sort of a gate?",
			LOCKED = "We need something!",
			PARTIAL = "Almost done, precious!",
		},
		TELEPORTATO_BOX = "Maybe we should keep it?",
		TELEPORTATO_CRANK = "Maybe we should keep it?",
		TELEPORTATO_POTATO = "Maybe we should keep it?",
		TELEPORTATO_RING = "Maybe we should keep it?",
		TELESTAFF = "Staff full of magic!",
		TENT = 
		{
			GENERIC = "Smells like a fat pig.",
			BURNT = "No more sleep in it!",
		},
		SIESTAHUT = 
		{
			GENERIC = "We can hide from sun!",
			BURNT = "Destroyed!",
		},
		TENTACLE = "Evil arm!",
		TENTACLESPIKE = "Wet and ugly weapon!",
		TENTACLESPOTS = "Very durable, precious.",
		TENTACLE_PILLAR = "No! No! be gone!",
		TENTACLE_PILLAR_ARM = "Smaller ones! Die!",
		TENTACLE_GARDEN = "What's this?",
		TOPHAT = "Smeagol is fancy!",
		TORCH = "It's primitive! Not like us!",
		TRANSISTOR = "What's this? Is it useful?",
		TRAP = "Simple trap to get some meat!",
		TRAP_TEETH = "We can kill them!",
		TRAP_TEETH_MAXWELL = "Clever trap, precious!",
		TREASURECHEST = 
		{
			GENERIC = "We can put stuff here, except precious!",
			BURNT = "It's dead.",
		},
		TREASURECHEST_TRAP = "We failed!",
		TREECLUMP = "Stop using console! Gollum!",
		TRINKET_1 = "We don't need this, right precious?",
		TRINKET_10 = "We don't need this, right precious?",
		TRINKET_11 = "We don't need this, right precious?",
		TRINKET_12 = "We don't need this, right precious?",
		TRINKET_2 = "We don't need this, right precious?",
		TRINKET_3 = "We don't need this, right precious?",
		TRINKET_4 = "We don't need this, right precious?",
		TRINKET_5 = "We don't need this, right precious?",
		TRINKET_6 = "We don't need this, right precious?",
		TRINKET_7 = "We don't need this, right precious?",
		TRINKET_8 = "We don't need this, right precious?",
		TRINKET_9 = "We don't need this, right precious?",
		TRUNKVEST_SUMMER = "It's ugly, precious.",
		TRUNKVEST_WINTER = "It's ugly and cold, precious.",
		TRUNK_COOKED = "Smells very good!",
		TRUNK_SUMMER = "Best part of this fat beast!",
		TRUNK_WINTER = "Best part of this fat beast!",
		TUMBLEWEED = "Something is hiding there!",
		TURF_CARPETFLOOR = "Some ground, precious.",
		TURF_CHECKERFLOOR = "Some ground, precious.",
		TURF_DIRT = "Some ground, precious.",
		TURF_FOREST = "Some ground, precious.",
		TURF_GRASS = "Some ground, precious.",
		TURF_MARSH = "Some ground, precious.",
		TURF_ROAD = "Some ground, precious.",
		TURF_ROCKY = "Some ground, precious.",
		TURF_SAVANNA = "Some ground, precious.",
		TURF_WOODFLOOR = "Some ground, precious.",
		TURKEYDINNER = "Meaty meal time!",
		TWIGS = "Twigs, precious. Just twigs.",
		UMBRELLA = "We don't like it!",
		GRASS_UMBRELLA = "What's this?",
		UNIMPLEMENTED = "Smeagol needs to wait.",
		WAFFLES = "Bleh!",
		WALL_HAY = 
		{	
			GENERIC = "It will burn soon!",
			BURNT = "Burned and useless wall.",
		},
		WALL_HAY_ITEM = "We can use it as a fuel!",
		WALL_STONE = "That will protect us!",
		WALL_STONE_ITEM = "We made it!",
		WALL_RUINS = "Very strong wall, precious!",
		WALL_RUINS_ITEM = "Great work!",
		WALL_WOOD = 
		{
			GENERIC = "Nice fuel, precious.",
			BURNT = "It's dead now.",
		},
		WALL_WOOD_ITEM = "Nice work, right precious?",
		WALRUS = "We will get you!",
		WALRUSHAT = "Smeagol is fancy!",
		WALRUS_CAMP =
		{
			EMPTY = "Somebody lives here.",
			GENERIC = "A lot of ice, precious.",
		},
		WALRUS_TUSK = "A trophy!",
		WARG = "King of wargs!",
		WASPHIVE = "We don't trust!",
		WATERMELON = "Bleh!",
		WATERMELON_COOKED = "We don't want it!",
		WATERMELONHAT = "What a bad idea!",
		WETGOOP = "We failed.",
		WINTERHAT = "A silly hat.",
		WINTEROMETER = 
		{
			GENERIC = "How it works?",
			BURNT = "It's dead.",
		},
		WORMHOLE =
		{
			GENERIC = "Ugly creature!",
			OPEN = "He want to eat me!",
		},
		WORMHOLE_LIMITED = "It's getting weak.",
		ACCOMPLISHMENT_SHRINE = "How it end up here?",        
		LIVINGTREE = "Sleeping ent.",
		ICESTAFF = "It's so cold, precious.",
	},
	DESCRIBE_GENERIC = "What's this, precious?",
	DESCRIBE_TOODARK = "It's too dark, precious!",
	DESCRIBE_SMOLDERING = "It will burn soon!",
	EAT_FOOD =
	{
		TALLBIRDEGG_CRACKED = "A meal?",
	},
}
