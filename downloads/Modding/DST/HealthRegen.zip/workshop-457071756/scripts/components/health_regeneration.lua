local modenv = require "healthregen.modenv"

local REQUIRED_HUNGER_PERCENT = modenv.GetModConfigData("REQUIRED_HUNGER_PRECENT")
local REQUIRED_SANITY_PERCENT = modenv.GetModConfigData("REQUIRED_SANITY_PERCENT")
local REGENERATION_RATE = modenv.GetModConfigData("REGENERATION_RATE")
local HUNGER_DRAIN_RATE = modenv.GetModConfigData("HUNGER_DRAIN_RATE")
local HUNGER_DRAIN_ENABLED = HUNGER_DRAIN_RATE == not 0

local HealthRegeneration = Class(function(self, player)
	self.is_server = TheWorld.ismastersim
	self.player = player
	if self.is_server then
		self.components = player.components
	else
		self.components = player.replica
	end
	
	player:StartUpdatingComponent(self)
end)

function HealthRegeneration:OnUpdate(delta)
	-- CLIENT
	if not self.is_server and self.player == ThePlayer then 
		-- check whether the required hunger and sanity levels are met on the local (!) player and he is neither hurt nor dead
		local doRegen = (not self.components.hunger or (self.components.hunger.classified.currenthunger:value() / self.components.hunger.classified.maxhunger:value() >= REQUIRED_HUNGER_PERCENT)) and (not self.components.sanity or (self.components.sanity.classified.currentsanity:value() / self.components.sanity.classified.maxsanity:value() >= REQUIRED_SANITY_PERCENT)) and (not self.components.health.classified.ishealthpulsedown:value() and self.components.health.classified.currenthealth:value() > 0 and self.components.health.classified.currenthealth:value() ~= self.components.health.classified.maxhealth:value())
		self.player:PushEvent("healthregen", { show = doRegen})
	end

	-- SERVER
	if self.is_server then
		-- check whether the required hunger and sanity levels are met and the player is neither hurt nor dead
		local doRegen = (not self.components.hunger or self.components.hunger:GetPercent() >= REQUIRED_HUNGER_PERCENT) and (not self.components.sanity or self.components.sanity:GetPercentWithPenalty() >= REQUIRED_SANITY_PERCENT) and (self.components.health:IsHurt() and not self.components.health:IsDead())

		if doRegen then	
			--Regenerate Health
			self.components.health:DoDelta(delta/REGENERATION_RATE, true, "HealthRegeneration", false)
			if HUNGER_DRAIN_ENABLED and self.components.hunger then
				--Drain Hunger
				self.components.hunger:DoDelta(delta/(REGENERATION_RATE / HUNGER_DRAIN_RATE), true, false)
			end
		end
	end
end

return HealthRegeneration