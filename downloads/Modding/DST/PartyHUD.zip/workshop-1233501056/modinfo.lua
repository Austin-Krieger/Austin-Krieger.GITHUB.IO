name="PartyHUD"
description= "A DST mod that displays the health status of other players. Set Position and layout in config."
author= "James Niemira (UrmaneHendrake)"
version="0.5.1"
forumthread=""

api_version = 10 -- the current version of the modding api
dont_starve_compatible = true
reign_of_giants_compatible = true
dst_compatible = true

all_clients_require_mod = true
client_only_mod = false
priority = -1000 -- low priority mod, loads last-ish

icon_atlas = "modicon.xml" -- for custom icons
icon = "modicon.tex"       -- image encoding

server_filter_tags = {"party hud"}

configuration_options= {
    {
        name="layout",
        label="HUD Layout",
        hover="Choose the Layout of the health indicators",
        options={
            {description = "Compact Grid", data = 0},
            {description = "Horizontal", data = 1},
            {description = "Vertical", data = 2},
            {description = "Alt Grid", data = 3},
        },
        default=3,
    },
    {
        name="position",
        label="HUD Position",
        hover="Choose the placement of the health indicators. Minimap settings are compatible with Squeek's minimap HUD",
        options={
            {description = "Minimap", data = 0},
            {description = "Minimap XL", data = 1},
            {description = "Standard", data = 2},
        },
        default=2,
    },
}
