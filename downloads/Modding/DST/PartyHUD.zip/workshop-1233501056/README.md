# PartyHud-Forked
A Don't Starve Together mod that displays the health and status of other players on the server.

Forked version of snekoo's [url=http://steamcommunity.com/sharedfiles/filedetails/?id=782961570] PartyHUD - Team Health Display[/url]

Only shows teammate hearts if they're in range - not sure if this is a bug or a feature :-)


[h1]Next Steps[/h1]
Investigate if we can have hearts full-time, or only if teammates are near
Investigate client-only (not clear this is possible, or desired)
Investigate other stats (sanity, hunger) - would need smaller badges ...

[h1]Changelog[/h1]
v0.5:
-Fixed corpses as per Hero's suggestion
v0.4:
-Bugfix for short player names
-Screenshot updated
-No longer displays your own health
v0.3:
-Names truncated to 8 characters (not clear how this impacts unicode/UTF-x names)
-Added vertical placement.  WARNING: interferes with backpack for keyboard users!!
-Alt grid now default layout; two tall and extends left for any number of players.
-Default placement now alt grid and standard position (guessing most now use minimap)
