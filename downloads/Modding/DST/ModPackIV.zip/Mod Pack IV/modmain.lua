-- Gem Crafting
STRINGS = GLOBAL.STRINGS
RECIPETABS = GLOBAL.RECIPETABS
Recipe = AddRecipe
Ingredient = GLOBAL.Ingredient
TECH = GLOBAL.TECH

STRINGS.RECIPE_DESC.REDGEM = "A magical red gem!" 
STRINGS.RECIPE_DESC.BLUEGEM = "A magical blue gem!"
STRINGS.RECIPE_DESC.YELLOWGEM = "A magical yellow gem!"
STRINGS.RECIPE_DESC.ORANGEGEM = "A magical orange gem!"
STRINGS.RECIPE_DESC.GREENGEM = "A magical green gem!"

if GetModConfigData("crafting") == "easy" then
 AddRecipe("redgem",  {Ingredient("flint", 5),Ingredient("red_cap",1),Ingredient("goldnugget",2)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1) 
 AddRecipe("bluegem", {Ingredient("flint", 5),Ingredient("blue_cap", 1),Ingredient("goldnugget",2)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("yellowgem", {Ingredient("flint", 5),Ingredient("honeycomb", 1),Ingredient("goldnugget",2)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("orangegem", {Ingredient("flint", 5),Ingredient("pumpkin", 1),Ingredient("goldnugget",2)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("greengem", {Ingredient("flint", 5),Ingredient("green_cap", 1),Ingredient("goldnugget",2)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
elseif GetModConfigData("crafting") == "normal" then
 AddRecipe("redgem",  {Ingredient("flint", 10),Ingredient("red_cap",2),Ingredient("goldnugget",4)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1) 
 AddRecipe("bluegem", {Ingredient("flint", 10),Ingredient("blue_cap", 2),Ingredient("goldnugget",4)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("yellowgem", {Ingredient("flint", 10),Ingredient("honeycomb", 2),Ingredient("goldnugget",4)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("orangegem", {Ingredient("flint", 10),Ingredient("pumpkin", 2),Ingredient("goldnugget",4)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("greengem", {Ingredient("flint", 10),Ingredient("green_cap", 2),Ingredient("goldnugget",4)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
elseif GetModConfigData("crafting") == "hard" then
 AddRecipe("redgem",  {Ingredient("flint", 15),Ingredient("red_cap",3),Ingredient("goldnugget",6)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1) 
 AddRecipe("bluegem", {Ingredient("flint", 15),Ingredient("blue_cap", 3),Ingredient("goldnugget",6)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("yellowgem", {Ingredient("flint", 15),Ingredient("honeycomb", 3),Ingredient("goldnugget",6)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("orangegem", {Ingredient("flint", 15),Ingredient("pumpkin", 3),Ingredient("goldnugget",6)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
 AddRecipe("greengem", {Ingredient("flint", 15),Ingredient("green_cap", 3),Ingredient("goldnugget",6)}, RECIPETABS.MAGIC, TECH.MAGIC_TWO ,nil,nil,nil,1)
end
-- Gem Tools
TUNING.AAXE_USES = 150
TUNING.AAXE_DAMAGE = 40
TUNING.APICK_USES = 150
TUNING.APICK_DAMAGE = 40
TUNING.ASHOVEL_USES = 150
TUNING.ASHOVEL_DAMAGE = 40

TUNING.RAXE_USES = 125
TUNING.RAXE_DAMAGE = 35
TUNING.RPICK_USES = 125
TUNING.RPICK_DAMAGE = 35
TUNING.RSHOVEL_USES = 125
TUNING.RSHOVEL_DAMAGE = 35

TUNING.SAXE_USES = 100
TUNING.SAXE_DAMAGE = 30
TUNING.SPICK_USES = 100
TUNING.SPICK_DAMAGE = 30
TUNING.SSHOVEL_USES = 100
TUNING.SSHOVEL_DAMAGE = 30

TUNING.TAXE_USES = 125
TUNING.TAXE_DAMAGE = 30
TUNING.TPICK_USES = 125
TUNING.TPICK_DAMAGE = 30
TUNING.TSHOVEL_USES = 125
TUNING.TSHOVEL_DAMAGE = 30

TUNING.AMAXE_USES = 150
TUNING.AMAXE_DAMAGE = 35
TUNING.AMPICK_USES = 150
TUNING.AMPICK_DAMAGE = 35
TUNING.AMSHOVEL_USES = 150
TUNING.AMSHOVEL_DAMAGE = 35

TUNING.EAXE_USES = 200
TUNING.EAXE_DAMAGE = 40
TUNING.EPICK_USES = 200
TUNING.EPICK_DAMAGE = 40
TUNING.ESHOVEL_USES = 200
TUNING.ESHOVEL_DAMAGE = 40

TUNING.RAINHAM_USES = 1000000
TUNING.RAINHAM_DAMAGE = 45
TUNING.RAINFORK_USES = 1000000
TUNING.RAINFORK_DAMAGE = 45

PrefabFiles = {
    "aaxe",
    "apick",
    "ashovel",
    "raxe",
    "rpick",
    "rshovel",
    "saxe",
    "spick",
    "sshovel",
    "taxe",
    "tpick",
    "tshovel",
    "amaxe",
    "ampick",
    "amshovel",
    "eaxe",
    "epick",
    "eshovel",
    "rainham",
    "rainfork",
}

Assets = {
    Asset( "IMAGE", "images/inventoryimages/aaxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/aaxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/apick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/apick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/ashovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/ashovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/raxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/raxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/rpick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/rpick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/rshovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/rshovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/saxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/saxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/spick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/spick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/sshovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/sshovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/taxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/taxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/tpick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/tpick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/tshovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/tshovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/amaxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/amaxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/ampick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/ampick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/amshovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/amshovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/eaxe.tex" ),
    Asset( "ATLAS", "images/inventoryimages/eaxe.xml" ),
    Asset( "IMAGE", "images/inventoryimages/epick.tex" ),
    Asset( "ATLAS", "images/inventoryimages/epick.xml" ),
    Asset( "IMAGE", "images/inventoryimages/eshovel.tex" ),
    Asset( "ATLAS", "images/inventoryimages/eshovel.xml" ),

    Asset( "IMAGE", "images/inventoryimages/rainham.tex" ),
    Asset( "ATLAS", "images/inventoryimages/rainham.xml" ),
    Asset( "IMAGE", "images/inventoryimages/rainfork.tex" ),
    Asset( "ATLAS", "images/inventoryimages/rainfork.xml" ),
}
local STRINGS = GLOBAL.STRINGS
local RECIPETABS = GLOBAL.RECIPETABS
local Recipe = AddRecipe
local Ingredient = GLOBAL.Ingredient
local TECH = GLOBAL.TECH

STRINGS.NAMES.AAXE = "Amethyst Axe"
STRINGS.NAMES.APICK = "Amethyst Pickaxe"
STRINGS.NAMES.ASHOVEL = "Amethyst Shovel"
STRINGS.RECIPE_DESC.AAXE = "An axe made of Amethyst."
STRINGS.RECIPE_DESC.APICK = "A pickaxe made of Amethyst."
STRINGS.RECIPE_DESC.ASHOVEL = "A shovel made of Amethyst."

STRINGS.NAMES.RAXE = "Ruby Axe"
STRINGS.NAMES.RPICK = "Ruby Pickaxe"
STRINGS.NAMES.RSHOVEL = "Ruby Shovel"
STRINGS.RECIPE_DESC.RAXE = "An axe made of Ruby."
STRINGS.RECIPE_DESC.RPICK = "A pickaxe made of Ruby."
STRINGS.RECIPE_DESC.RSHOVEL = "A shovel made of Ruby."

STRINGS.NAMES.SAXE = "Sapphire Axe"
STRINGS.NAMES.SPICK = "Sapphire Pickaxe"
STRINGS.NAMES.SSHOVEL = "Sapphire Shovel"
STRINGS.RECIPE_DESC.SAXE = "An axe made of Sapphire."
STRINGS.RECIPE_DESC.SPICK = "A pickaxe made of Sapphire."
STRINGS.RECIPE_DESC.SSHOVEL = "A shovel made of Sapphire."

STRINGS.NAMES.TAXE = "Topaz Axe"
STRINGS.NAMES.TPICK = "Topaz Pickaxe"
STRINGS.NAMES.TSHOVEL = "Topaz Shovel"
STRINGS.RECIPE_DESC.TAXE = "An axe made of Topaz."
STRINGS.RECIPE_DESC.TPICK = "A pickaxe made of Topaz."
STRINGS.RECIPE_DESC.TSHOVEL = "A shovel made of Topaz."

STRINGS.NAMES.AMAXE = "Amber Axe"
STRINGS.NAMES.AMPICK = "Amber Pickaxe"
STRINGS.NAMES.AMSHOVEL = "Amber Shovel"
STRINGS.RECIPE_DESC.AMAXE = "An axe made of Amber."
STRINGS.RECIPE_DESC.AMPICK = "A pickaxe made of Amber."
STRINGS.RECIPE_DESC.AMSHOVEL = "A shovel made of Amber."

STRINGS.NAMES.EAXE = "Emerald Axe"
STRINGS.NAMES.EPICK = "Emerald Pickaxe"
STRINGS.NAMES.ESHOVEL = "Emerald Shovel"
STRINGS.RECIPE_DESC.EAXE = "An axe made of Emerald."
STRINGS.RECIPE_DESC.EPICK = "A pickaxe made of Emerald."
STRINGS.RECIPE_DESC.ESHOVEL = "A shovel made of Emerald."

STRINGS.NAMES.RAINHAM = "Prismal Hammer"
STRINGS.NAMES.RAINFORK = "Prismal Fork"
STRINGS.RECIPE_DESC.RAINHAM = "A hammer made from various gems."
STRINGS.RECIPE_DESC.RAINFORK = "A pitchfork made from various gems."


-----Config-----

--on/off--

if GetModConfigData("aaxe") == true then
    local aaxe = AddRecipe("aaxe",{Ingredient("purplegem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        aaxe.atlas = "images/inventoryimages/aaxe.xml"
end

if GetModConfigData("apick") == true then
    local apick = AddRecipe("apick",{Ingredient("purplegem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        apick.atlas = "images/inventoryimages/apick.xml"
end

if GetModConfigData("ashovel") == true then
    local ashovel = AddRecipe("ashovel",{Ingredient("purplegem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        ashovel.atlas = "images/inventoryimages/ashovel.xml"
end

if GetModConfigData("raxe") == true then
    local raxe = AddRecipe("raxe",{Ingredient("redgem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        raxe.atlas = "images/inventoryimages/raxe.xml"
end

if GetModConfigData("rpick") == true then
    local rpick = AddRecipe("rpick",{Ingredient("redgem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        rpick.atlas = "images/inventoryimages/rpick.xml"
end

if GetModConfigData("rshovel") == true then
    local rshovel = AddRecipe("rshovel",{Ingredient("redgem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        rshovel.atlas = "images/inventoryimages/rshovel.xml"
end

if GetModConfigData("saxe") == true then
    local saxe = AddRecipe("saxe",{Ingredient("bluegem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO) 
        saxe.atlas = "images/inventoryimages/saxe.xml"
end

if GetModConfigData("spick") == true then
    local spick = AddRecipe("spick",{Ingredient("bluegem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        spick.atlas = "images/inventoryimages/spick.xml"
end

if GetModConfigData("rshovel") == true then
    local sshovel = AddRecipe("sshovel",{Ingredient("bluegem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        sshovel.atlas = "images/inventoryimages/sshovel.xml"
end

if GetModConfigData("taxe") == true then
    local taxe = AddRecipe("taxe",{Ingredient("yellowgem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO) 
        taxe.atlas = "images/inventoryimages/taxe.xml"
end

if GetModConfigData("tpick") == true then
    local tpick = AddRecipe("tpick",{Ingredient("yellowgem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        tpick.atlas = "images/inventoryimages/tpick.xml"
end

if GetModConfigData("tshovel") == true then
    local tshovel = AddRecipe("tshovel",{Ingredient("yellowgem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        tshovel.atlas = "images/inventoryimages/tshovel.xml"
end

if GetModConfigData("amaxe") == true then
    local amaxe = AddRecipe("amaxe",{Ingredient("orangegem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO) 
        amaxe.atlas = "images/inventoryimages/amaxe.xml"
end

if GetModConfigData("ampick") == true then
    local ampick = AddRecipe("ampick",{Ingredient("orangegem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        ampick.atlas = "images/inventoryimages/ampick.xml"
end

if GetModConfigData("amshovel") == true then
    local amshovel = AddRecipe("amshovel",{Ingredient("orangegem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        amshovel.atlas = "images/inventoryimages/amshovel.xml"
end

if GetModConfigData("eaxe") == true then
    local eaxe = AddRecipe("eaxe",{Ingredient("greengem", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO) 
        eaxe.atlas = "images/inventoryimages/eaxe.xml"
end

if GetModConfigData("epick") == true then
    local epick = AddRecipe("epick",{Ingredient("greengem", 3),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)
        epick.atlas = "images/inventoryimages/epick.xml"
end

if GetModConfigData("eshovel") == true then
    local eshovel = AddRecipe("eshovel",{Ingredient("greengem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        eshovel.atlas = "images/inventoryimages/eshovel.xml"
end

if GetModConfigData("rainham") == true then
    local rainham = AddRecipe("rainham",{Ingredient("redgem", 1),Ingredient("orangegem", 1),Ingredient("yellowgem", 1),Ingredient("greengem", 1),Ingredient("bluegem", 1),Ingredient("purplegem", 1),Ingredient("rope", 2),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        rainham.atlas = "images/inventoryimages/rainham.xml"
end

if GetModConfigData("rainfork") == true then
    local rainfork = AddRecipe("rainfork",{Ingredient("redgem", 1),Ingredient("orangegem", 1),Ingredient("yellowgem", 1),Ingredient("greengem", 1),Ingredient("bluegem", 1),Ingredient("purplegem", 1),Ingredient("twigs", 4)}, RECIPETABS.TOOLS, TECH.SCIENCE_TWO)        
        rainfork.atlas = "images/inventoryimages/rainfork.xml"
end