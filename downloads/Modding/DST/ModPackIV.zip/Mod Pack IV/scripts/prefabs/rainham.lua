local assets =
{
	Asset("ANIM", "anim/rainham.zip"),
	Asset("ANIM", "anim/swap_rainham.zip"),
    Asset("ATLAS", "images/inventoryimages/rainham.xml"),
    Asset("IMAGE", "images/inventoryimages/rainham.tex"),
}

local function onfinished(inst)
    inst:Remove()
end

local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_rainham", "swap_hammer")
    owner.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
end
    
local function fn(Sim)
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	
    inst.AnimState:SetBank("hammer")
    inst.AnimState:SetBuild("rainham")
    inst.AnimState:PlayAnimation("idle")
	
    inst:AddTag("hammer")

    if not TheWorld.ismastersim then
        return inst
    end

    inst.entity:SetPristine()

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(TUNING.RAINHAM_DAMAGE)

	-----

    inst:AddComponent("tool")
    inst.components.tool:SetAction(ACTIONS.HAMMER, 3)

    -------

    inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetMaxUses(TUNING.RAINHAM_USES)
    inst.components.finiteuses:SetUses(TUNING.RAINHAM_USES)
    inst.components.finiteuses:SetOnFinished(onfinished)
    inst.components.finiteuses:SetConsumption(ACTIONS.HAMMER, 0.25)

    -------

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.atlasname = "images/inventoryimages/rainham.xml"

    inst:AddComponent("equippable")

    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("common/inventory/rainham", fn, assets)