local assets=
{
	Asset("ANIM", "anim/tshovel.zip"),
	Asset("ANIM", "anim/swap_tshovel.zip"),
	Asset("IMAGE", "images/inventoryimages/tshovel.tex"),
    Asset("ATLAS", "images/inventoryimages/tshovel.xml"),
}
    
local function onfinished(inst)
    inst:Remove()
end
    
local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_object", "swap_tshovel", "swap_shovel")
    owner.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
    owner.AnimState:Show("ARM_carry") 
    owner.AnimState:Hide("ARM_normal") 
end

local function onunequip(inst, owner) 
    owner.AnimState:Hide("ARM_carry") 
    owner.AnimState:Show("ARM_normal") 
end
    
    
local function fn(Sim)
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    if not TheWorld.ismastersim then
        return inst
    end

    inst.AnimState:SetBank("shovel")
    inst.AnimState:SetBuild("tshovel")
    inst.AnimState:PlayAnimation("idle")
    
    
    -----
    inst:AddComponent("tool")
    inst.components.tool:SetAction(ACTIONS.DIG)

    -------

    inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetMaxUses(TUNING.TSHOVEL_USES)
    inst.components.finiteuses:SetUses(TUNING.TSHOVEL_USES)
    inst.components.finiteuses:SetOnFinished( onfinished) 
    inst.components.finiteuses:SetConsumption(ACTIONS.DIG, 0.1)

    -------

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(TUNING.TSHOVEL_DAMAGE)
    
    inst:AddInherentAction(ACTIONS.DIG)
    
    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.atlasname = "images/inventoryimages/tshovel.xml"
    
    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip( onequip )
    inst.components.equippable:SetOnUnequip( onunequip )

    MakeHauntableLaunch(inst)
    
    return inst
end


return Prefab( "common/inventory/tshovel", fn, assets)
