name = "Mod Pack IV"
description = "Multiple Mods Part IV"
author = "ownsaucepimp"
version = "1.0.0"
forumthread = ""
api_version = 10
dst_compatible = true
dont_starve_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
    -- Gem Crafting
    {
        name = "crafting",
        label = "Difficulty",
        hover = "How difficult is it to craft?",
        options = {
            {description = "Easy", data = "easy", hover = "5 flint, 1 color, 2 gold nuggets"},
            {description = "Normal", data = "normal", hover = "10 flint, 2 color, 4 gold nuggets"},
            {description = "Hard", data = "hard", hover = "15 flint, 3 color, 6 gold nuggets"},
            },
        default = "normal",
    },
    -- Gem Tools
        {name = "aaxe", 
        label = "Amethyst Axe?",
        hover = "Do you want to have access to the Amethyst Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amethyst Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Amethyst Axes"},},
        default = true,},

        {name = "eaxe", 
        label = "Emerald Axe?",
        hover = "Do you want to have access to the Emerald Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Emerald Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Emerald Axes"},},
        default = true,},

        {name = "apick", 
        label = "Amethyst Pick?",
        hover = "Do you want to have access to the Amethyst Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amethyst Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Amethyst Picks"},},
        default = true,},

        {name = "epick", 
        label = "Emerald Pick?",
        hover = "Do you want to have access to the Emerald Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Emerald Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Emerald Picks"},},
        default = true,},

        {name = "ashovel", 
        label = "Amethyst Shovel?",
        hover = "Do you want to have access to the Amethyst Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amethyst Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Amethyst Shovels"},},
        default = true,},

        {name = "eshovel", 
        label = "Emerald Shovel?",
        hover = "Do you want to have access to the Emerald Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Emerald Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Emerald Shovels"},},
        default = true,},

        {name = "raxe", 
        label = "Ruby Axe?",
        hover = "Do you want to have access to the Ruby Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Ruby Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Ruby Axes"},},
        default = true,},

        {name = "amaxe", 
        label = "Amber Axe?",
        hover = "Do you want to have access to the Amber Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amber Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Amber Axes"},},
        default = true,},

        {name = "rpick", 
        label = "Ruby Pick?",
        hover = "Do you want to have access to the Ruby Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Ruby Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Ruby Picks"},},
        default = true,},

        {name = "ampick", 
        label = "Amber Pick?",
        hover = "Do you want to have access to the Amber Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amber Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Amber Picks"},},
        default = true,},

        {name = "rshovel", 
        label = "Ruby Shovel?",
        hover = "Do you want to have access to the Ruby Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Ruby Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Ruby Shovels"},},
        default = true,},

        {name = "amshovel", 
        label = "Amber Shovel?",
        hover = "Do you want to have access to the Amber Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Amber Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Amber Shovels"},},
        default = true,},

        {name = "saxe", 
        label = "Sapphire Axe?",
        hover = "Do you want to have access to the Sapphire Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Sapphire Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Sapphire Axes"},},
        default = true,},

        {name = "taxe", 
        label = "Topaz Axe?",
        hover = "Do you want to have access to the Topaz Axe?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Topaz Axes"},
        {description = "Yes", data = true, hover = "You will be able to use Topaz Axes"},},
        default = true,},

        {name = "spick", 
        label = "Sapphire Pick?",
        hover = "Do you want to have access to the Sapphire Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Sapphire Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Sapphire Picks"},},
        default = true,},

        {name = "tpick", 
        label = "Topaz Pick?",
        hover = "Do you want to have access to the Topaz Pick?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Topaz Picks"},
        {description = "Yes", data = true, hover = "You will be able to use Topaz Picks"},},
        default = true,},

        {name = "sshovel", 
        label = "Sapphire Shovel?",
        hover = "Do you want to have access to the Sapphire Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Sapphire Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Sapphire Shovels"},},
        default = true,},

        {name = "tshovel",
        label = "Topaz Shovel?",
        hover = "Do you want to have access to the Topaz Shovel?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Topaz Shovels"},
        {description = "Yes", data = true, hover = "You will be able to use Topaz Shovels"},},
        default = true,},

        {name = "rainham",
        label = "Prismal Hammer?",
        hover = "Do you want to have access to the Prismal Hammer?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Prismal Hammers"},
        {description = "Yes", data = true, hover = "You will be able to use Prismal Hammers"},},
        default = true,},

        {name = "rainfork",
        label = "Prismal Fork?",
        hover = "Do you want to have access to the Prismal Fork?",
        options = 
        {{description = "No", data = false, hover = "You will not be able to use or craft Prismal Forks"},
        {description = "Yes", data = true, hover = "You will be able to use Prismal Forks"},},
        default = true,},
}