name = "AFK Detection"
description = "Prevents all that Don't Starve randomness ruining your day when AFK"
author = "Ninja101"
version = "1.8.4"
forumthread = ""
icon_atlas = "modicon.xml"
icon = "modicon.tex"

dst_compatible = true
client_only_mod = false
all_clients_require_mod = false

api_version = 10

configuration_options = {
	-- DEBUG
	-- { name = "debug", label = "Debug", { {description = "No", data = false}, {description = "Yes", data = true} }, default = true },

	-- AFK
	{
		name = "afk_enabled",
		label = "Enabled",
		options =
		{
			{description = "No", data = false},
			{description = "Yes", data = true}
		},
		default = true
	},
	{
		name = "afk_time",
		label = "Time To Mark As AFK",
		options =
		{
			{description = "30 seconds", data = 30},
			{description = "1 minute", data = 60},
			{description = "2 minutes", data = 120},
			{description = "3 minutes", data = 180},
			{description = "5 minutes", data = 300}
		},
		default = 120
	},
	{
		name = "afk_max_time",
		label = "Max Time Spent AFK",
		options =
		{
			{description = "No Limit", data = 0},
			{description = "1 minute", data = 60},
			{description = "2 minutes", data = 120},
			{description = "3 minutes", data = 180},
			{description = "5 minutes", data = 300},
			{description = "10 minutes", data = 600},
			{description = "15 minutes", data = 900},
			{description = "30 minutes", data = 1800}
		},
		default = 0
	},
	{
		name = "afk_max_action",
		label = "Action at Max AFK",
		options =
		{
			{description = "Disable AFK Immunity", data = 1},
			{description = "Kick Player", data = 2}
		},
		default = 1
	},
	{
		name = "afk_host_immunity",
		label = "Admin Immunity",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_hunger_decrease",
		label = "Prevent Hunger Loss",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_stop_death",
		label = "Prevent Death",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_stop_sanity",
		label = "Prevent Sanity Loss",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_stop_wet",
		label = "Prevent Wetness",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_stop_beaver",
		label = "Pause Beaverness",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
	{
		name = "afk_temp",
		label = "Prevent Overheating",
		options =
		{
			{description = "Off", data = false},
			{description = "On", data = true}
		},
		default = true
	},
}