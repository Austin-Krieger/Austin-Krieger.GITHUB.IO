
-- local debug = GetModConfigData( "debug" )

local afk_enabled = GetModConfigData( "afk_enabled" )
local afk_host_immunity = GetModConfigData( "afk_host_immunity" )
local afk_time = GetModConfigData( "afk_time" )
local afk_max_time = GetModConfigData( "afk_max_time" )
local afk_max_action = GetModConfigData( "afk_max_action" )
local afk_stop_death = GetModConfigData( "afk_stop_death" )
local afk_stop_hunger = GetModConfigData( "afk_hunger_decrease" )
local afk_stop_sanity = GetModConfigData( "afk_stop_sanity" )
local afk_stop_wet = GetModConfigData( "afk_stop_wet" )
local afk_stop_beaver = GetModConfigData( "afk_stop_beaver" )
local afk_temp = GetModConfigData( "afk_temp" )

local function PostInit( inst )
	-- AFK
	if afk_enabled and inst:HasTag( "player" ) and not inst:HasTag( "CLASSIFIED" ) then
		inst:AddComponent( "afk" )

		-- inst.components.afk.debug = debug
		inst.components.afk.host_immunity = afk_host_immunity
		inst.components.afk.min_afk_time = afk_time
		inst.components.afk.max_afk_time = afk_max_time
		inst.components.afk.max_afk_action = afk_max_action
		inst.components.afk.stop_death = afk_stop_death
		inst.components.afk.stop_hunger = afk_stop_hunger
		inst.components.afk.stop_sanity = afk_stop_sanity
		inst.components.afk.stop_wet = afk_stop_wet
		inst.components.afk.stop_beaver = afk_stop_beaver
		inst.components.afk.afk_temp = afk_temp
	end
end

if GLOBAL.TheNet:GetIsServer( ) then
	AddPrefabPostInitAny( PostInit )
end