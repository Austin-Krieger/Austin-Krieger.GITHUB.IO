name = "Mod Pack I"
description = "Multiple Mods Part I"
author = "ownsaucepimp"
version = "1.0.0"
forumthread = ""
api_version = 10
dst_compatible = true
dont_starve_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
    -- Increase Inventory Slots
    {
        name = "INVENTORYSIZE",
        label = "Change the size of inventory",
        hover = "Change the size of inventory.",
        options = {
            {description = "Default", data = 15},
            {description = "+10", data = 25},
            {description = "+30", data = 45},
            },
        default = 45,
    },
    {
      name = "EXTRASLOT",
      label = "Enable more extra slots.",
      hover = "Enable more extra slots.",
      options = {
            {description = "1", data = 1},
      },
      default = 1,
    },
    -- Ressurect From Skeleton
    {
        name = 'skeleton_player',
        label = '',
        options = {
            {description = '', data = true},
            },
        default = true,
    },
    {
        name = 'bekkitt_skeleton_pen',
        label = 'Blood sacrifice',
        default = 0,
        options = {
            {description = '0%',data = 0, hover = "No health pentalty"},
            {description = '5%', data = 0.05, hover = "5% health pentalty"},
            {description = '10%', data = 0.1, hover = "10% health pentalty"},
            {description = '25%', data = 0.25, hover = "Default 25% health pentalty"},
            {description = '30%', data = 0.3, hover = "30% health pentalty"},
            {description = '40%', data = 0.4, hover = "40% health pentalty"},
            {description = '50%', data = 0.5, hover = "50% health pentalty"},
            {description = '60%', data = 0.6, hover = "60% health pentalty"},
            {description = '70%', data = 0.7, hover = "70% health pentalty"},
            {description = '75%', data = 0.75, hover = "75% health pentalty"},
        },
    },
    -- Faster Cane
    {
        name = "YourSpeed",
        hover = "Speed x",
        options =   {
                        {description = "x1.25", data = 1.25, hover = "original cane"},
                        {description = "x1.5", data = 1.5, hover = "original cane x2"},
                        {description = "x1.75", data = 1.75, hover = "original cane x3"},
                        {description = "x2", data = 2, hover = "original cane x4"},
                    },
        default = 2,
    },
    {
        name = "DisableSpiderWarriors",
        label = "DisableSpiderWarriors",
        options =   {
                        {description = "Off", data = false},
                        {description = "On", data = true},
                    },
        default = false,

    },
    -- Infinite Tent Uses
    {
        name = "InfiniteTentUses",
        label = "InfiniteTentUses",
        options =   {
                        {description = "Off", data = false},
                        {description = "On", data = true},
                    },
        default = true,
    },
    -- Infinite Canopy Uses
    {
        name = "InfiniteSiestaCanopyUses",
        label = "InfiniteSiestaCanopyUses",
        options =   {
                        {description = "Off", data = false},
                        {description = "On", data = true},
                    },
        default = true,

    },
    -- Infinite Fridge Freshness
    {
        name = "InfiniteFridge",
        label = "FridgeFreshForever",
        options =   {
                        {description = "Off", data = false},
                        {description = "On", data = true},
                    },
        default = true,

    },
    -- Increase Stack Size
    --[[{
        name = "InventoryStackSize",
        label = "Max Stack Size: 999",
        options =   {
                        {description = "Off", data = false},
                        {description = "On", data = true},
                    },
        default = true,
    },]]
    {
        name = "MAXSTACKSIZE",
        label = "Max stacksize",
        options =   {
                        {description = "20", data = 20},
                        {description = "40", data = 40},
                        {description = "60", data = 60},
                        {description = "80", data = 80},
                        {description = "99", data = 99},
                        {description = "120", data = 120},
                        {description = "150", data = 150},
                        {description = "200", data = 200},
                        {description = "250", data = 250},
                        {description = "999", data = 999},
                    },

        default = 999,
    },
    -- Infinite Durabilities
    {
        name = "WEAPON_DURABILITY",
        label = "Weapon Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "ARMOR_DURABILITY",
        label = "Armor Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "STAFF_DURABILITY",
        label = "Staff Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "AMULET_DURABILITY",
        label = "Amulet Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "TOOL_DURABILITY",
        label = "Tool Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "GOLD_DURABILITY",
        label = "Gold Tool Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "TRAP_DURABILITY",
        label = "Trap Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },    
    {
        name = "CLOTHING_DURABILITY",
        label = "Clothing Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "LIGHT_DURABILITY",
        label = "Light Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "CAMPING_DURABILITY",
        label = "Camping Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "BOOK_DURABILITY",
        label = "Book Durability",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },
        default = "Infinite",
    },
    {
        name = "FOOD_PRESERVATION",
        label = "Food Preservation",
        options =   {
                        {description = "25%", data = 0.25},
                        {description = "50%", data = 0.5},
                        {description = "75%", data = 0.75},
                        {description = "Default", data = "Default"},
                        {description = "200%", data = 2},
                        {description = "300%", data = 3},
                        {description = "400%", data = 4},
                        {description = "500%", data = 5},
                        {description = "750%", data = 7.5},
                        {description = "1000%", data = 10},
                        {description = "Infinite", data = "Infinite"},
                    },

        default = "Infinite",
    },
    {
        name = "FOOD_SELECTION",
        label = "Food Tweak",
        hover = "Tells the mod to either tweak all foods, or just those preserved with a meat rack or ice box.",
        options =   {
                        {description = "All Food", data = "All"},
                        {description = "Preserved", data = "Preserved"},
                    },
        default = "All Food",
    },
}