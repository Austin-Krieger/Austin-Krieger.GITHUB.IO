-- Faster Cane
GLOBAL.TUNING.CANE_SPEED_MULT = GetModConfigData("YourSpeed")

-- Slower Metabolism (no change in modinfo)
GLOBAL.TUNING.WILSON_HUNGER_RATE = 0.075

-- Remove Revive Penalty (no change in modinfo)
GLOBAL.TUNING.REVIVE_HEALTH_PENALTY_AS_MULTIPLE_OF_EFFIGY = 0
GLOBAL.TUNING.EFFIGY_HEALTH_PENALTY = 0
GLOBAL.TUNING.REVIVE_HEALTH_PENALTY = 0
GLOBAL.TUNING.MAXIMUM_HEALTH_PENALTY = 0

-- Dissable Spider Warriors
if GetModConfigData('DisableSpiderWarriors') then
    GLOBAL.TUNING.SPIDERDEN_WARRIORS={0,0,0}
    GLOBAL.TUNING.SPIDERDEN_EMERGENCY_WARRIORS = {0,0,0}
end

-- Infinite Fridge Freshness
if GetModConfigData('InfiniteFridge') then
    GLOBAL.TUNING.PERISH_FRIDGE_MULT = 0
end

-- Increase Stack Size
--[[if GetModConfigData('InventoryStackSize') then
    --local size = GetModConfigData('StackSize');
    GLOBAL.TUNING.STACK_SIZE_LARGEITEM = 999
	GLOBAL.TUNING.STACK_SIZE_MEDITEM = 999
	GLOBAL.TUNING.STACK_SIZE_SMALLITEM = 999
	local r_s = GLOBAL.require("components/stackable_replica")
	r_s._ctor = function(self, inst)
		self.inst = inst
		self._stacksize = GLOBAL.net_shortint(inst.GUID, "stackable._stacksize", "stacksizedirty")
		self._maxsize = GLOBAL.net_tinybyte(inst.GUID, "stackable._maxsize")
	end
end]]
local require = GLOBAL.require
local stackable_replica = require "components/stackable_replica"
local IsServer = GLOBAL.TheNet:GetIsServer()

local size = GetModConfigData("MAXSTACKSIZE")
local TUNING = GLOBAL.TUNING
local net_byte = GLOBAL.net_byte

TUNING.STACK_SIZE_LARGEITEM = size
TUNING.STACK_SIZE_MEDITEM = size
TUNING.STACK_SIZE_SMALLITEM = size 

-- Define functions
local stackable_replica_ctorBase = stackable_replica._ctor or function() return true end    
function stackable_replica._ctor(self, inst)
    self.inst = inst

    self._stacksize = net_byte(inst.GUID, "stackable._stacksize", "stacksizedirty")
    self._maxsize = size
end

local stackable_replicaSetMaxSize_Base = stackable_replica.SetMaxSize or function() return true end
function stackable_replica:SetMaxSize(maxsize)
    self._maxsize = size
end

local stackable_replicaMaxSize_Base = stackable_replica.MaxSize or function() return true end
function stackable_replica:MaxSize()
    return self._maxsize
end

if IsServer then
AddPrefabPostInit("rabbit",function(inst)
   if(inst.components.stackable == nil) then
      inst:AddComponent("stackable")
   end
   inst.components.inventoryitem:SetOnDroppedFn(function(inst)
        inst.components.perishable:StopPerishing()
        inst.sg:GoToState("stunned")
        if inst.components.stackable then
            while inst.components.stackable:StackSize() > 1 do
                local item = inst.components.stackable:Get()
                if item then
                    if item.components.inventoryitem then
                        item.components.inventoryitem:OnDropped()
                    end
                    item.Physics:Teleport(inst.Transform:GetWorldPosition() )
                end
            end
         end
    end)
end)
end
-- Increase Durabilities
local TUNING = GLOBAL.TUNING
local WEAPON_DURABILITY = GetModConfigData("WEAPON_DURABILITY")
local ARMOR_DURABILITY = GetModConfigData("ARMOR_DURABILITY")
local STAFF_DURABILITY = GetModConfigData("STAFF_DURABILITY")
local AMULET_DURABILITY = GetModConfigData("AMULET_DURABILITY")
local TOOL_DURABILITY = GetModConfigData("TOOL_DURABILITY")
local GOLD_DURABILITY = GetModConfigData("GOLD_DURABILITY")
local TRAP_DURABILITY = GetModConfigData("TRAP_DURABILITY")
local CLOTHING_DURABILITY = GetModConfigData("CLOTHING_DURABILITY")
local LIGHT_DURABILITY = GetModConfigData("LIGHT_DURABILITY")
local CAMPING_DURABILITY = GetModConfigData("CAMPING_DURABILITY")
local BOOK_DURABILITY = GetModConfigData("BOOK_DURABILITY")
local FOOD_PRESERVATION = GetModConfigData("FOOD_PRESERVATION")
local FOOD_SELECTION = GetModConfigData("FOOD_SELECTION")

local function GetDurabilitySetting(inst)
	local DURABILITYSETTING = "Default"
	if inst:HasTag("TweakClothes") then
		DURABILITYSETTING = CLOTHING_DURABILITY
	elseif inst:HasTag("TweakWeapon") then
		DURABILITYSETTING = WEAPON_DURABILITY
	elseif inst:HasTag("TweakStaff") then
		DURABILITYSETTING = STAFF_DURABILITY
	elseif inst:HasTag("TweakAmulet") then
		DURABILITYSETTING = AMULET_DURABILITY
	elseif inst:HasTag("TweakTool") then
		DURABILITYSETTING = TOOL_DURABILITY
	elseif inst:HasTag("TweakGold") then
		DURABILITYSETTING = GOLD_DURABILITY
	elseif inst:HasTag("TweakTrap") then
		DURABILITYSETTING = TRAP_DURABILITY
	elseif inst:HasTag("TweakArmor") then
		DURABILITYSETTING = ARMOR_DURABILITY
	elseif inst:HasTag("TweakLight") then
		DURABILITYSETTING = LIGHT_DURABILITY
	elseif inst:HasTag("TweakCamping") then
		DURABILITYSETTING = CAMPING_DURABILITY
	elseif inst:HasTag("TweakBook") then
		DURABILITYSETTING = BOOK_DURABILITY
	elseif inst:HasTag("TweakJerky") then
		DURABILITYSETTING = FOOD_PRESERVATION
	elseif inst:HasTag("TweakFood") then
		DURABILITYSETTING = FOOD_PRESERVATION
	end
	return DURABILITYSETTING
end

-- Check if the user isn't a client.
if not GLOBAL.TheNet:GetIsClient() then

	-- Weapons
	-- Tweak durability based on tag  
	function AddWeaponTag(inst)
		-- Sets up the Tagging function for weapons
				inst:AddTag("TweakWeapon")
	end
	
    AddPrefabPostInit("batbat", AddWeaponTag)
    AddPrefabPostInit("blowdart_fire", AddWeaponTag)
    AddPrefabPostInit("blowdart_pipe", AddWeaponTag)
    AddPrefabPostInit("blowdart_poison", AddWeaponTag)
    AddPrefabPostInit("blowdart_sleep", AddWeaponTag)
    AddPrefabPostInit("boomerang", AddWeaponTag)
    AddPrefabPostInit("cutlass", AddWeaponTag)
    AddPrefabPostInit("hambat", AddWeaponTag)
    AddPrefabPostInit("harpoon", AddWeaponTag)
    AddPrefabPostInit("javelin", AddWeaponTag)
    AddPrefabPostInit("nightstick", AddWeaponTag)
    AddPrefabPostInit("nightsword", AddWeaponTag)
    AddPrefabPostInit("obsidianmachete", AddWeaponTag)
    AddPrefabPostInit("obsidianspeargun", AddWeaponTag)
    AddPrefabPostInit("peg_leg", AddWeaponTag)
    AddPrefabPostInit("ruins_bat", AddWeaponTag)
    AddPrefabPostInit("scythe", AddWeaponTag)
    AddPrefabPostInit("spear", AddWeaponTag)
    AddPrefabPostInit("spear_obsidian", AddWeaponTag)
    AddPrefabPostInit("spear_poison", AddWeaponTag)
    AddPrefabPostInit("spear_wathgrithr", AddWeaponTag)
    AddPrefabPostInit("speargun", AddWeaponTag)
    AddPrefabPostInit("speargun_poison", AddWeaponTag)
    AddPrefabPostInit("staff_tornado", AddWeaponTag)
    AddPrefabPostInit("tentaclespike", AddWeaponTag)
    AddPrefabPostInit("trident", AddWeaponTag)

	-- Armor
	function AddArmorTag(inst)
		-- Sets up the Tagging function for Armors
				inst:AddTag("TweakArmor")
	end
	
    AddPrefabPostInit("armor_sanity", AddArmorTag)
    AddPrefabPostInit("armordragonfly", AddArmorTag)
    AddPrefabPostInit("armorgrass", AddArmorTag)
    AddPrefabPostInit("armorlimestone", AddArmorTag)
    AddPrefabPostInit("armormarble", AddArmorTag)
    AddPrefabPostInit("armorobsidian", AddArmorTag)
    AddPrefabPostInit("armorruins", AddArmorTag)
    AddPrefabPostInit("armorseashell", AddArmorTag)
    AddPrefabPostInit("armorsnurtleshell", AddArmorTag)
    AddPrefabPostInit("armorwood", AddArmorTag)
    AddPrefabPostInit("beefalo_hide", AddArmorTag)
    AddPrefabPostInit("beehat", AddArmorTag)
    AddPrefabPostInit("footballhat", AddArmorTag)
    AddPrefabPostInit("ruinshat", AddArmorTag)
    AddPrefabPostInit("slurtlehat", AddArmorTag)
    AddPrefabPostInit("wathgrithrhat", AddArmorTag) 
	AddPrefabPostInit("armorskeleton", AddArmorTag)

	
	-- Staffs
	function AddStaffTag(inst)
		-- Sets up the Tagging function for Staves
				inst:AddTag("TweakStaff")
	end
	
    AddPrefabPostInit("firestaff", AddStaffTag)
    AddPrefabPostInit("greenstaff", AddStaffTag)
    AddPrefabPostInit("icestaff", AddStaffTag)
    AddPrefabPostInit("orangestaff", AddStaffTag)
    AddPrefabPostInit("telestaff", AddStaffTag)
    AddPrefabPostInit("volcanostaff", AddStaffTag)
    AddPrefabPostInit("yellowstaff", AddStaffTag)
	AddPrefabPostInit("opalstaff", AddStaffTag)

	
	-- Amulets
	function AddAmuletTag(inst)
		-- Sets up the Tagging function for Amulets
			inst:AddTag("TweakAmulet")
	end
	
	AddPrefabPostInit("amulet", AddAmuletTag)
	AddPrefabPostInit("blueamulet", AddAmuletTag)
	AddPrefabPostInit("greenamulet", AddAmuletTag)
	AddPrefabPostInit("yellowamulet", AddAmuletTag)
	AddPrefabPostInit("purpleamulet", AddAmuletTag)
	AddPrefabPostInit("orangeamulet", AddAmuletTag)
	
	-- Tools
	function AddToolTag(inst)
		-- Sets up the Tagging function for Tools
				inst:AddTag("TweakTool")
	end
	
	AddPrefabPostInit("axe", AddToolTag)
    AddPrefabPostInit("bell", AddToolTag)
    AddPrefabPostInit("boatrepairkit", AddToolTag)
    AddPrefabPostInit("bugnet", AddToolTag)
    AddPrefabPostInit("compass", AddToolTag)
    AddPrefabPostInit("featherfan", AddToolTag)
    AddPrefabPostInit("fertilizer", AddToolTag)
    AddPrefabPostInit("firesuppressor", AddToolTag)
    AddPrefabPostInit("fishingrod", AddToolTag)
    AddPrefabPostInit("hammer", AddToolTag)
    AddPrefabPostInit("horn", AddToolTag)
    AddPrefabPostInit("icemaker", AddToolTag)
    AddPrefabPostInit("machete", AddToolTag)
    AddPrefabPostInit("minifan", AddToolTag)  
    AddPrefabPostInit("monkeyball", AddToolTag)
    AddPrefabPostInit("multitool_axe_pickaxe", AddToolTag)
    AddPrefabPostInit("obsidianaxe", AddToolTag)
    AddPrefabPostInit("panflute", AddToolTag)
    AddPrefabPostInit("pickaxe", AddToolTag)
    AddPrefabPostInit("pitchfork", AddToolTag)
    AddPrefabPostInit("saddle_basic", AddToolTag)
	AddPrefabPostInit("saddle_race", AddToolTag)
    AddPrefabPostInit("saddle_war", AddToolTag)
    AddPrefabPostInit("sail_stick", AddToolTag)
	AddPrefabPostInit("saddlehorn", AddToolTag)
	AddPrefabPostInit("brush", AddToolTag)
    AddPrefabPostInit("seatrap", AddToolTag)
    AddPrefabPostInit("sewing_kit", AddToolTag)
    AddPrefabPostInit("shovel", AddToolTag)
    AddPrefabPostInit("supertelescope", AddToolTag)
    AddPrefabPostInit("telescope", AddToolTag)
    AddPrefabPostInit("tropicalfan", AddToolTag)
    AddPrefabPostInit("whip", AddToolTag)
    AddPrefabPostInit("wind_conch", AddToolTag)
	AddPrefabPostInit("perdfan", AddToolTag)
	
	function AddGoldTag(inst)
		-- Sets up the Tagging function for Tools
				inst:AddTag("TweakGold")
	end
	
    AddPrefabPostInit("goldenaxe", AddGoldTag)
    AddPrefabPostInit("goldenmachete", AddGoldTag)
    AddPrefabPostInit("goldenpickaxe", AddGoldTag)
    AddPrefabPostInit("goldenshovel", AddGoldTag)  

	if TOOL_DURABILITY ~= "Default" then

		if TOOL_DURABILITY == "Infinite" then
  
			-- Effectively remove the durability from the heatrock.
			TUNING.HEATROCK_NUMUSES = 100000000
		else                                                                                                
			-- Tweak the uses left of the heatrock.                                                             
			TUNING.HEATROCK_NUMUSES = ( TUNING.HEATROCK_NUMUSES * TOOL_DURABILITY )
		end
	end 
	
	-- Traps
	function AddTrapTag(inst)
		-- Sets up the Tagging function for Traps
				inst:AddTag("TweakTrap")
	end
	
	AddPrefabPostInit("birdtrap", AddTrapTag)
	AddPrefabPostInit("trap", AddTrapTag)
	AddPrefabPostInit("trap_teeth", AddTrapTag)
	
	-- Clothes
	function AddClothesTag(inst)
		-- Sets up the Tagging function for Clothes
				inst:AddTag("TweakClothes")
	end
		
    AddPrefabPostInit("aerodynamichat", AddClothesTag)
    AddPrefabPostInit("armor_lifejacket", AddClothesTag)
    AddPrefabPostInit("armor_snakeskin", AddClothesTag)
    AddPrefabPostInit("armor_windbreaker", AddClothesTag)
    AddPrefabPostInit("armorslurper", AddClothesTag)
    AddPrefabPostInit("beargervest", AddClothesTag)
    AddPrefabPostInit("beefalohat", AddClothesTag)
    AddPrefabPostInit("blubbersuit", AddClothesTag)
    AddPrefabPostInit("brainjellyhat", AddClothesTag)
    AddPrefabPostInit("captainhat", AddClothesTag)
    AddPrefabPostInit("catcoonhat", AddClothesTag)
    AddPrefabPostInit("double_umbrellahat", AddClothesTag)
    AddPrefabPostInit("earmuffshat", AddClothesTag)
    AddPrefabPostInit("eyebrellahat", AddClothesTag)
    AddPrefabPostInit("featherhat", AddClothesTag)
    AddPrefabPostInit("flowerhat", AddClothesTag)
    AddPrefabPostInit("gashat", AddClothesTag)
    AddPrefabPostInit("grass_umbrella", AddClothesTag)
    AddPrefabPostInit("hawaiianshirt", AddClothesTag)
    AddPrefabPostInit("icehat", AddClothesTag)
    AddPrefabPostInit("onemanband", AddClothesTag)
    AddPrefabPostInit("palmleaf_umbrella", AddClothesTag)
    AddPrefabPostInit("piratehat", AddClothesTag)
    AddPrefabPostInit("raincoat", AddClothesTag)
    AddPrefabPostInit("rainhat", AddClothesTag)
    AddPrefabPostInit("reflectivevest", AddClothesTag)
    AddPrefabPostInit("shark_teethhat", AddClothesTag)
    AddPrefabPostInit("snakeskinhat", AddClothesTag)
    AddPrefabPostInit("spiderhat", AddClothesTag)
    AddPrefabPostInit("strawhat", AddClothesTag)
    AddPrefabPostInit("sweatervest", AddClothesTag)
    AddPrefabPostInit("tophat", AddClothesTag)
    AddPrefabPostInit("trunkvest_summer", AddClothesTag)
    AddPrefabPostInit("trunkvest_winter", AddClothesTag)
    AddPrefabPostInit("umbrella", AddClothesTag)
    AddPrefabPostInit("walrushat", AddClothesTag)
    AddPrefabPostInit("watermelonhat", AddClothesTag)
    AddPrefabPostInit("winterhat", AddClothesTag)
	AddPrefabPostInit("hivehat", AddClothesTag)
	AddPrefabPostInit("dragonheadhat", AddClothesTag)
	AddPrefabPostInit("dragonbodyhat", AddClothesTag)
	AddPrefabPostInit("dragontailhat", AddClothesTag)
	AddPrefabPostInit("deserthat", AddClothesTag)
	AddPrefabPostInit("goggleshat", AddClothesTag)
	
	-- Light
	function AddLightTag(inst)
		-- Sets up the Tagging function for Light Sources
				inst:AddTag("TweakLight")
	end
	
    AddPrefabPostInit("boat_lantern", AddLightTag)
    AddPrefabPostInit("boat_torch", AddLightTag)
    AddPrefabPostInit("bottlelantern", AddLightTag)
    AddPrefabPostInit("lantern", AddLightTag)
    AddPrefabPostInit("lighter", AddLightTag)
    AddPrefabPostInit("minerhat", AddLightTag)
    AddPrefabPostInit("molehat", AddLightTag)
    AddPrefabPostInit("nightlight", AddLightTag)
    AddPrefabPostInit("pumpkin_lantern", AddLightTag)
    AddPrefabPostInit("torch", AddLightTag)
	AddPrefabPostInit("redlantern", AddLightTag)
	AddPrefabPostInit("thurible", AddLightTag)
	
	-- Camping
	function AddCampingTag(inst)
		-- Sets up the Tagging function for Camping
				inst:AddTag("TweakCamping")
	end

	function AddPitTag(inst)
		-- Sets up the Tagging function to identify Fire Pits.  This is so that when infinite is set, they can decay past massive blaze, but not below regular fire
			inst:AddTag("TweakPit")
	end
		
    AddPrefabPostInit("bedroll_furry", AddCampingTag)
    AddPrefabPostInit("bedroll_straw", AddCampingTag)
    AddPrefabPostInit("campfire", AddCampingTag)
    AddPrefabPostInit("chiminea", AddCampingTag)
    AddPrefabPostInit("coldfire", AddCampingTag)
    AddPrefabPostInit("coldfirepit", AddCampingTag)
    AddPrefabPostInit("deluxe_firepit", AddCampingTag)
    AddPrefabPostInit("endo_firepit", AddCampingTag)
    AddPrefabPostInit("endothermic_torch", AddCampingTag)
    AddPrefabPostInit("firepit", AddCampingTag)
    AddPrefabPostInit("heat_star", AddCampingTag)
    AddPrefabPostInit("ice_star", AddCampingTag)
    AddPrefabPostInit("obsidianfirepit", AddCampingTag)
    AddPrefabPostInit("palmleaf_hut", AddCampingTag)
    AddPrefabPostInit("siestahut", AddCampingTag)
    AddPrefabPostInit("tent", AddCampingTag)
    AddPrefabPostInit("campfire", AddPitTag)
    AddPrefabPostInit("chiminea", AddPitTag)
    AddPrefabPostInit("coldfire", AddPitTag)
    AddPrefabPostInit("coldfirepit", AddPitTag)
    AddPrefabPostInit("deluxe_firepit", AddPitTag)
    AddPrefabPostInit("endo_firepit", AddPitTag)
    AddPrefabPostInit("endothermic_torch", AddPitTag)
    AddPrefabPostInit("firepit", AddPitTag)
    AddPrefabPostInit("heat_star", AddPitTag)
    AddPrefabPostInit("ice_star", AddPitTag)
    AddPrefabPostInit("obsidianfirepit", AddPitTag)
	AddPrefabPostInit("redlantern", AddCampingTag)
	
	
	-- Librarian's Books
	function AddBookTag(inst)
		-- Sets up the Tagging function for Camping
				inst:AddTag("TweakBook")
	end
	
	AddPrefabPostInit("book_birds", AddBookTag)
	AddPrefabPostInit("book_brimstone", AddBookTag)
	AddPrefabPostInit("book_gardening", AddBookTag)
	AddPrefabPostInit("book_sleep", AddBookTag)
	AddPrefabPostInit("book_tentacles", AddBookTag)
	
	-- Dried Meats
	----------
	function AddJerkyTag(inst)
		-- Sets up the Tagging function for preserved foods
				inst:AddTag("TweakJerky")
	end
	
    AddPrefabPostInit("jellyjerky", AddJerkyTag)
    AddPrefabPostInit("meat_dried", AddJerkyTag)
    AddPrefabPostInit("monstermeat_dried", AddJerkyTag)
    AddPrefabPostInit("seaweed_dried", AddJerkyTag)
    AddPrefabPostInit("smallmeat_dried", AddJerkyTag)
	
	
	-- All Other Food
	----------
	function AddFoodTag(inst)
		-- Sets up the Tagging function for preserved foods
				inst:AddTag("TweakFood")
	end
	
	if FOOD_SELECTION == "All" then
    AddPrefabPostInit("acorn_cooked", AddFoodTag)
    AddPrefabPostInit("baconeggs", AddFoodTag)
    AddPrefabPostInit("bananapop", AddFoodTag)
    AddPrefabPostInit("batwing", AddFoodTag)
    AddPrefabPostInit("batwing_cooked", AddFoodTag)
    AddPrefabPostInit("berries", AddFoodTag)
    AddPrefabPostInit("berries_cooked", AddFoodTag)
    AddPrefabPostInit("berries_juicy", AddFoodTag)
    AddPrefabPostInit("berries_juicy_cooked", AddFoodTag)	
    AddPrefabPostInit("bird_egg", AddFoodTag)
    AddPrefabPostInit("bird_egg_cooked", AddFoodTag)
    AddPrefabPostInit("bisque", AddFoodTag)
    AddPrefabPostInit("blue_cap", AddFoodTag)
    AddPrefabPostInit("blue_cap_cooked", AddFoodTag)
    AddPrefabPostInit("bonestew", AddFoodTag)
    AddPrefabPostInit("butter", AddFoodTag)
    AddPrefabPostInit("butterflymuffin", AddFoodTag)
    AddPrefabPostInit("butterflywings", AddFoodTag)
    AddPrefabPostInit("cactus_flower", AddFoodTag)
    AddPrefabPostInit("cactus_meat", AddFoodTag)
    AddPrefabPostInit("cactus_meat_cooked", AddFoodTag)
    AddPrefabPostInit("californiaroll", AddFoodTag)
    AddPrefabPostInit("carrot", AddFoodTag)
    AddPrefabPostInit("carrot_cooked", AddFoodTag)
    AddPrefabPostInit("carrot_seeds", AddFoodTag)
    AddPrefabPostInit("cave_banana", AddFoodTag)
    AddPrefabPostInit("cave_banana_cooked", AddFoodTag)
    AddPrefabPostInit("ceviche", AddFoodTag)
    AddPrefabPostInit("coconut", AddFoodTag)
    AddPrefabPostInit("coconut_cooked", AddFoodTag)
    AddPrefabPostInit("coffee", AddFoodTag)
    AddPrefabPostInit("cookedmeat", AddFoodTag)
    AddPrefabPostInit("cookedmonstermeat", AddFoodTag)
    AddPrefabPostInit("cookedsmallmeat", AddFoodTag)
    AddPrefabPostInit("coral_brain", AddFoodTag)
    AddPrefabPostInit("corn", AddFoodTag)
    AddPrefabPostInit("corn_cooked", AddFoodTag)
    AddPrefabPostInit("corn_seeds", AddFoodTag)
    AddPrefabPostInit("cutlichen", AddFoodTag)
    AddPrefabPostInit("dead_swordfish", AddFoodTag)
    AddPrefabPostInit("dragonfruit", AddFoodTag)
    AddPrefabPostInit("dragonfruit_cooked", AddFoodTag)
    AddPrefabPostInit("dragonfruit_seeds", AddFoodTag)
    AddPrefabPostInit("dragonpie", AddFoodTag)
    AddPrefabPostInit("dragoonheart", AddFoodTag)
    AddPrefabPostInit("drumstick", AddFoodTag)
    AddPrefabPostInit("drumstick_cooked", AddFoodTag)
    AddPrefabPostInit("durian", AddFoodTag)
    AddPrefabPostInit("durian_cooked", AddFoodTag)
    AddPrefabPostInit("durian_seeds", AddFoodTag)
    AddPrefabPostInit("eel", AddFoodTag)
    AddPrefabPostInit("eel_cooked", AddFoodTag)
    AddPrefabPostInit("eggplant", AddFoodTag)
    AddPrefabPostInit("eggplant_cooked", AddFoodTag)
    AddPrefabPostInit("eggplant_seeds", AddFoodTag)
    AddPrefabPostInit("fish", AddFoodTag)
    AddPrefabPostInit("fish_cooked", AddFoodTag)
    AddPrefabPostInit("fish_med", AddFoodTag)
    AddPrefabPostInit("fish_med_cooked", AddFoodTag)
    AddPrefabPostInit("fish_raw", AddFoodTag)
    AddPrefabPostInit("fish_raw_small", AddFoodTag)
    AddPrefabPostInit("fish_raw_small_cooked", AddFoodTag)
    AddPrefabPostInit("fishsticks", AddFoodTag)
    AddPrefabPostInit("fishtacos", AddFoodTag)
    AddPrefabPostInit("flowersalad", AddFoodTag)
    AddPrefabPostInit("foliage", AddFoodTag)
    AddPrefabPostInit("frogglebunwich", AddFoodTag)
    AddPrefabPostInit("froglegs", AddFoodTag)
    AddPrefabPostInit("froglegs_cooked", AddFoodTag)
    AddPrefabPostInit("fruitmedley", AddFoodTag)
    AddPrefabPostInit("goatmilk", AddFoodTag)
    AddPrefabPostInit("green_cap", AddFoodTag)
    AddPrefabPostInit("green_cap_cooked", AddFoodTag)
    AddPrefabPostInit("guacamole", AddFoodTag)
    AddPrefabPostInit("hail_ice", AddFoodTag)
    AddPrefabPostInit("honey", AddFoodTag)
    AddPrefabPostInit("honeyham", AddFoodTag)
    AddPrefabPostInit("honeynuggets", AddFoodTag)
    AddPrefabPostInit("hotchili", AddFoodTag)
    AddPrefabPostInit("ice", AddFoodTag)
    AddPrefabPostInit("icecream", AddFoodTag)
    AddPrefabPostInit("jammypreserves", AddFoodTag)
    AddPrefabPostInit("jellyfish_cooked", AddFoodTag)
    AddPrefabPostInit("jellyfish_dead", AddFoodTag)
    AddPrefabPostInit("jellyopop", AddFoodTag)
    AddPrefabPostInit("kabobs", AddFoodTag)
    AddPrefabPostInit("lightbulb", AddFoodTag)
    AddPrefabPostInit("limpets", AddFoodTag)
    AddPrefabPostInit("limpets_cooked", AddFoodTag)
    AddPrefabPostInit("lobsterbisque", AddFoodTag)
    AddPrefabPostInit("lobsterdinner", AddFoodTag)
    AddPrefabPostInit("mandrakesoup", AddFoodTag)
    AddPrefabPostInit("meat", AddFoodTag)
    AddPrefabPostInit("meatballs", AddFoodTag)
    AddPrefabPostInit("monsterlasagna", AddFoodTag)
    AddPrefabPostInit("monstermeat", AddFoodTag)
    AddPrefabPostInit("mussel", AddFoodTag)
    AddPrefabPostInit("mussel_cooked", AddFoodTag)
    AddPrefabPostInit("perogies", AddFoodTag)
    AddPrefabPostInit("petals", AddFoodTag)
    AddPrefabPostInit("petals_evil", AddFoodTag)
    AddPrefabPostInit("plantmeat", AddFoodTag)
    AddPrefabPostInit("plantmeat_cooked", AddFoodTag)
    AddPrefabPostInit("pomegranate", AddFoodTag)
    AddPrefabPostInit("pomegranate_cooked", AddFoodTag)
    AddPrefabPostInit("pomegranate_seeds", AddFoodTag)
    AddPrefabPostInit("powcake", AddFoodTag)
    AddPrefabPostInit("pumpkin", AddFoodTag)
    AddPrefabPostInit("pumpkin_cooked", AddFoodTag)
    AddPrefabPostInit("pumpkin_seeds", AddFoodTag)
    AddPrefabPostInit("pumpkincookie", AddFoodTag)
    AddPrefabPostInit("ratatouille", AddFoodTag)
    AddPrefabPostInit("red_cap", AddFoodTag)
    AddPrefabPostInit("red_cap_cooked", AddFoodTag)
    AddPrefabPostInit("seafoodgumbo", AddFoodTag)
    AddPrefabPostInit("seaweed", AddFoodTag)
    AddPrefabPostInit("seaweed_cooked", AddFoodTag)
    AddPrefabPostInit("seeds", AddFoodTag)
    AddPrefabPostInit("seeds_cooked", AddFoodTag)
    AddPrefabPostInit("shark_fin", AddFoodTag)
    AddPrefabPostInit("sharkfinsoup", AddFoodTag)
    AddPrefabPostInit("smallmeat", AddFoodTag)
    AddPrefabPostInit("stuffedeggplant", AddFoodTag)
    AddPrefabPostInit("surfnturf", AddFoodTag)
    AddPrefabPostInit("sweet_potato", AddFoodTag)
    AddPrefabPostInit("sweet_potato_cooked", AddFoodTag)
    AddPrefabPostInit("sweet_potato_seeds", AddFoodTag)
    AddPrefabPostInit("taffy", AddFoodTag)
    AddPrefabPostInit("tallbirdegg", AddFoodTag)
    AddPrefabPostInit("tallbirdegg_cooked", AddFoodTag)
    AddPrefabPostInit("trailmix", AddFoodTag)
    AddPrefabPostInit("tropical_fish", AddFoodTag)
    AddPrefabPostInit("trunk_cooked", AddFoodTag)
    AddPrefabPostInit("trunk_summer", AddFoodTag)
    AddPrefabPostInit("trunk_winter", AddFoodTag)
    AddPrefabPostInit("turkeydinner", AddFoodTag)
    AddPrefabPostInit("unagi", AddFoodTag)
    AddPrefabPostInit("waffles", AddFoodTag)
    AddPrefabPostInit("watermelon", AddFoodTag)
    AddPrefabPostInit("watermelon_cooked", AddFoodTag)
    AddPrefabPostInit("watermelon_seeds", AddFoodTag)
    AddPrefabPostInit("watermelonicle", AddFoodTag)
    AddPrefabPostInit("wetgoop", AddFoodTag)
    AddPrefabPostInit("wormlight", AddFoodTag)
	AddPrefabPostInit("blue_mushroomhat", AddFoodTag)
	AddPrefabPostInit("red_mushroomhat", AddFoodTag)
	AddPrefabPostInit("green_mushroomhat", AddFoodTag)
	AddPrefabPostInit("wormlight_lesser", AddFoodTag)
	end
	-- Shipwrecked Together Mod Items
	AddPrefabPostInit("donarmorblubbersuit", AddClothesTag)
	AddPrefabPostInit("donarmorlifejacket", AddClothesTag)
	AddPrefabPostInit("donarmorlimestone", AddArmorTag)
	AddPrefabPostInit("donarmorobsidian", AddArmorTag)
	AddPrefabPostInit("donarmorseashell", AddArmorTag)
	AddPrefabPostInit("donarmorsnakeskin", AddClothesTag)
	AddPrefabPostInit("donarmorwindbreaker", AddClothesTag)
	AddPrefabPostInit("donbottlelantern", AddLightTag)
	AddPrefabPostInit("doncactusarmour", AddArmorTag)
	AddPrefabPostInit("donchiminea", AddCampingTag)
	AddPrefabPostInit("donchiminea", AddPitTag)
	AddPrefabPostInit("doncoconut", AddFoodTag)
	AddPrefabPostInit("doncutlass", AddWeaponTag)
	AddPrefabPostInit("donharpoon", AddWeaponTag)
	AddPrefabPostInit("donhataerodynamic", AddClothesTag)
	AddPrefabPostInit("donhatbrainjelly", AddClothesTag)
	AddPrefabPostInit("donhatcaptain", AddClothesTag)
	AddPrefabPostInit("donhatdoubleumbrella", AddClothesTag)
	AddPrefabPostInit("donhatgasmask", AddClothesTag)
	AddPrefabPostInit("donhathornedhelmet", AddClothesTag)
	AddPrefabPostInit("donhatpirate", AddClothesTag)
	AddPrefabPostInit("donhatsharkteeth", AddClothesTag)
	AddPrefabPostInit("donhatsnakeskin", AddClothesTag)
	AddPrefabPostInit("donmachete", AddToolTag)
	AddPrefabPostInit("donobsidianspear", AddWeaponTag)
	AddPrefabPostInit("donsurfboard", AddBoatTag)
	AddPrefabPostInit("dontrident", AddWeaponTag)
	AddPrefabPostInit("dontropicalparasol", AddToolTag)

end

-- ARMOR
AddComponentPostInit("armor", function(Armor, inst)
	local TakeDamage_prev = Armor.TakeDamage
	function Armor:TakeDamage(damage_amount, ...)

		local DURABILITYSETTING = GetDurabilitySetting(inst)
		
		if DURABILITYSETTING ~= "Default" then
			if DURABILITYSETTING == "Infinite" then
				damage_amount = 0
			else
				damage_amount = damage_amount / DURABILITYSETTING
			end
		end

		return TakeDamage_prev(self, damage_amount, ...)
	end
	
end)

-- FINITE USES
AddComponentPostInit("finiteuses", function(FiniteUses, inst)
	local Use_prev = FiniteUses.Use
	function FiniteUses:Use(num, ...)

		local DURABILITYSETTING = GetDurabilitySetting(inst)
		
		if DURABILITYSETTING ~= "Default" then
			if DURABILITYSETTING == "Infinite" then
				num = 0
			else
				num = (num or 1) / DURABILITYSETTING
			end
		end
		
		return Use_prev(self, num, ...)
	end
	
end)

-- FUELED
AddComponentPostInit("fueled", function(Fueled, inst)
	local DoDelta_prev = Fueled.DoDelta
	function Fueled:DoDelta(amount, ...)
		
		local DURABILITYSETTING = GetDurabilitySetting(inst)

		if DURABILITYSETTING ~= "Default" then
			if amount >= 1 then  -- Check to see if we're adding fuel to our item, and thus do not need to tweak the value
				self.currentfuel = math.max(0, math.min(self.maxfuel, self.currentfuel + amount) )
			else
				if DURABILITYSETTING == "Infinite" then
					if self.currentfuel >= 270 and self.inst:HasTag("TweakPit") then
						-- do nothing
					else
						return
					end
				else
					amount = amount / DURABILITYSETTING
				end
			end
		end
		
		return DoDelta_prev(self, amount, ...)
	end
	
end)

-- PERISHABLE
local function Update(inst, dt)
    if inst.components.perishable then
		
		local modifier = 1
		
		local FoodTweak = 1
		if FOOD_PRESERVATION ~= "Default" then
			if FOOD_PRESERVATION ~= "Infinite" then
				FoodTweak = FOOD_PRESERVATION
			end
		else
			FoodTweak = 1
		end
		
		local owner = inst.components.inventoryitem and inst.components.inventoryitem.owner or nil
        if not owner and inst.components.occupier then
            owner = inst.components.occupier:GetOwner()
        end

		if owner then
			if owner:HasTag("fridge") then
				if FOOD_PRESERVATION == "Infinite" then
					modifier = 0
				elseif inst:HasTag("frozen") and not owner:HasTag("nocool") and not owner:HasTag("lowcool") then
					modifier = TUNING.PERISH_COLD_FROZEN_MULT
				else
					modifier = TUNING.PERISH_FRIDGE_MULT
				end
			elseif owner:HasTag("spoiler") then
				modifier = TUNING.PERISH_GROUND_MULT 
			elseif owner:HasTag("cage") and inst:HasTag("small_livestock") then
                modifier = TUNING.PERISH_CAGE_MULT
            end
		else
			modifier = TUNING.PERISH_GROUND_MULT 
		end

		if inst:GetIsWet() then
			modifier = modifier * TUNING.PERISH_WET_MULT
		end
		
		if GLOBAL.TheWorld.state.temperature < 0 then
			if inst:HasTag("frozen") and not inst.components.perishable.frozenfiremult then
				modifier = TUNING.PERISH_COLD_FROZEN_MULT
			else
				modifier = modifier * TUNING.PERISH_WINTER_MULT
			end
		end

		if inst.components.perishable.frozenfiremult then
			modifier = modifier * TUNING.PERISH_FROZEN_FIRE_MULT
		end

		if GLOBAL.TheWorld.state.temperature > TUNING.OVERHEAT_TEMP then
			modifier = modifier * TUNING.PERISH_SUMMER_MULT
		end

        modifier = modifier * inst.components.perishable.localPerishMultiplyer

		modifier = modifier * TUNING.PERISH_GLOBAL_MULT
		
		local old_val = inst.components.perishable.perishremainingtime
		local delta = dt or (10 + math.random()*GLOBAL.FRAMES*8)
		
		if inst.components.perishable.perishremainingtime then  
			
			local DURABILITYSETTING = GetDurabilitySetting(inst)
			
			if DURABILITYSETTING ~= "Default" then
				if DURABILITYSETTING == "Infinite" then
					inst.components.perishable.perishremainingtime = inst.components.perishable.perishremainingtime
				else
					inst.components.perishable.perishremainingtime = inst.components.perishable.perishremainingtime - ((delta*modifier)/DURABILITYSETTING)
				end
			else
				inst.components.perishable.perishremainingtime = inst.components.perishable.perishremainingtime - delta*modifier
			end
			
	        if math.floor(old_val*100) ~= math.floor(inst.components.perishable.perishremainingtime*100) then
		        inst:PushEvent("perishchange", {percent = inst.components.perishable:GetPercent()})
		    end
		end

		-- Cool off hot foods over time (faster if in a fridge)
		if inst.components.edible and inst.components.edible.temperaturedelta and inst.components.edible.temperaturedelta > 0 then
			if owner and owner:HasTag("fridge") then
				if not owner:HasTag("nocool") then
					inst.components.edible.temperatureduration = inst.components.edible.temperatureduration - 1
				end
			elseif GLOBAL.TheWorld.state.temperature < TUNING.OVERHEAT_TEMP - 5 then
				inst.components.edible.temperatureduration = inst.components.edible.temperatureduration - .25
			end
			if inst.components.edible.temperatureduration < 0 then inst.components.edible.temperatureduration = 0 end
		end
        
        --trigger the next callback
        if inst.components.perishable.perishremainingtime and inst.components.perishable.perishremainingtime <= 0 then
			inst.components.perishable:Perish()
        end
    end
end

AddComponentPostInit("perishable", function(Perishable, inst)
	if FOOD_PRESERVATION == "Default" then
		return
	end
	
	if Perishable.CustomUpdate == nil then
		-- Replace the original function
		function Perishable:StartPerishing()
			if self.updatetask ~= nil then
				self.updatetask:Cancel()
				self.updatetask = nil
			end

			local dt = 10 + math.random()*GLOBAL.FRAMES*8
			self.updatetask = self.inst:DoPeriodicTask(dt, Update, math.random()*2, dt)
		end
	else
		local CustomUpdate_prev = Perishable.CustomUpdate
		function Perishable:CustomUpdate(dt, ...)
			local DURABILITYSETTING = GetDurabilitySetting(inst)
			
			if DURABILITYSETTING ~= "Default" then
				if DURABILITYSETTING == "Infinite" then
					return
				else
					dt = dt/DURABILITYSETTING
				end
			end
			return CustomUpdate_prev(self, dt, ...)
		end	
	end
end)
-- Ressurect From Skeleton
local bekkitt_prefabs = {
    'skeleton_player', 
}

function apply_negative_effects(inst)
    if inst.LastResSource and inst.LastResSource:HasTag('bekkitt_skeleton_resp') then

        new_penalty = inst.components.health.penalty + GetModConfigData('bekkitt_skeleton_pen') 
        if new_penalty >= .75 then
            new_penalty = .75
        end
        inst.components.health.penalty = new_penalty
        inst.components.health:ForceUpdateHUD(false)
    end

end

function save_last_respawn_source(inst, data)
    if data then 
        inst.LastResSource = data.source
    end 
end

AddPlayerPostInit( 
    function(inst) 
        inst:ListenForEvent('respawnfromghost', save_last_respawn_source)  
        inst:ListenForEvent('ms_respawnedfromghost', apply_negative_effects)  
    end
)

local light_fire_on_haunt = function(inst, haunter)
    if ( inst.components.fueled ~= nil ) then
        inst.components.fueled:DoDelta( TUNING.LARGE_FUEL )
    end
    return true
end

for i, prefab_name in ipairs( bekkitt_prefabs ) do
    
    local allow_rez = GetModConfigData( prefab_name )

    if ( allow_rez ) then
        AddPrefabPostInit(
            prefab_name, 
            function(inst) 
                
                if ( inst.components.hauntable ~= nil ) then
                    inst:RemoveComponent('hauntable')
                end
                
                inst:AddComponent('hauntable')
            
                inst.components.hauntable:SetOnHauntFn( light_fire_on_haunt )
                
                inst.components.hauntable:SetHauntValue(TUNING.HAUNT_INSTANT_REZ)
                inst:AddTag('resurrector')
                inst:AddTag('bekkitt_skeleton_resp') 
            end
        )
    end
end
-- Increase Inventory Slots
local TheInput = GLOBAL.TheInput
local ThePlayer = GLOBAL.ThePlayer
local IsServer = GLOBAL.TheNet:GetIsServer()
local Inv = require "widgets/inventorybar"
local Vector3 = GLOBAL.Vector3
local TUNING = GLOBAL.TUNING
local MAXITEMSLOTS = GLOBAL.MAXITEMSLOTS
local makereadonly = GLOBAL.makereadonly
local SCALEMODE_PROPORTIONAL = GLOBAL.SCALEMODE_PROPORTIONAL
local TALKINGFONT = GLOBAL.TALKINGFONT
local ANCHOR_BOTTOM = GLOBAL.ANCHOR_BOTTOM
local IsServer = GLOBAL.TheNet:GetIsServer()
local net_entity = GLOBAL.net_entity
local HudCompass = require "widgets/hudcompass"
local Widget = require "widgets/widget"
local UIAnim = require "widgets/uianim"

WidgetsFiles = {
	"hudcompass",
}

Assets =
{
    Asset("IMAGE", "images/back.tex"),
    Asset("ATLAS", "images/back.xml"),
    Asset("IMAGE", "images/neck.tex"),
    Asset("ATLAS", "images/neck.xml"),
	Asset("IMAGE", "images/waist.tex"),
	Asset("ATLAS", "images/waist.xml"),
	Asset("ATLAS", "images/inventory_bg.xml")
}

ENABLEBACKPACK = false
INVENTORYSIZE = GetModConfigData("INVENTORYSIZE")
MAXITEMSLOTS = INVENTORYSIZE
EXTRASLOT = GetModConfigData("EXTRASLOT")

if EXTRASLOT == 1 then
    MAXITEMSLOTS = MAXITEMSLOTS + 1
end

if EXTRASLOT > 1 then
    MAXITEMSLOTS = MAXITEMSLOTS - 1
end

_G = GLOBAL
local TheNet = _G.rawget(_G, "TheNet")

local inventory = require("components/inventory")
local inventory_replica = require("components/inventory_replica")
local inv = require("widgets/inventorybar")
local InvSlot = require("widgets/invslot")
local Image = require("widgets/image")
local Widget = require("widgets/widget")
local EquipSlot = require("widgets/equipslot")
local ItemTile = require("widgets/itemtile")
local Text = require("widgets/text")
local ThreeSlice = require("widgets/threeslice")
local TEMPLATES = require "widgets/templates"
inventory.maxslots = MAXITEMSLOTS

GLOBAL.EQUIPSLOTS=
{
    HANDS = "hands",
    HEAD = "head",
    BODY = "body",
    BACK = "back",
    NECK = "neck",
	WAIST = "waist"
}
GLOBAL.EQUIPSLOT_IDS = {}
local slot = 0
for k, v in pairs(GLOBAL.EQUIPSLOTS) do
    slot = slot + 1
    GLOBAL.EQUIPSLOT_IDS[v] = slot
end
slot = nil

AddComponentPostInit("resurrectable", function(self, inst)
    local original_FindClosestResurrector = self.FindClosestResurrector
    local original_CanResurrect = self.CanResurrect
    local original_DoResurrect = self.DoResurrect

    self.FindClosestResurrector = function(self)
        if IsServer and self.inst.components.inventory then
            local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
            if item and item.prefab == "amulet" then
                return item
            end
        end
        original_FindClosestResurrector(self)
    end

    self.CanResurrect = function(self)
        if IsServer and self.inst.components.inventory then
            local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
            if item and item.prefab == "amulet" then
                return true
            end
        end
        original_CanResurrect(self)
    end

    self.DoResurrect = function(self)
        self.inst:PushEvent("resurrect")
        if IsServer and self.inst.components.inventory then
            local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
            if item and item.prefab == "amulet" then
                self.inst.sg:GoToState("amulet_rebirth")
                return true
            end
        end
        original_DoResurrect(self)
    end
end)

AddComponentPostInit("inventory", function(self, inst)
    local original_Equip = self.Equip
    self.Equip = function(self, item, old_to_active)
        if original_Equip(self, item, old_to_active) and item and item.components and item.components.equippable then
            local eslot = item.components.equippable.equipslot
            if self.equipslots[eslot] ~= item then
                if eslot == GLOBAL.EQUIPSLOTS.BACK and item.components.container ~= nil then
                    self.inst:PushEvent("setoverflow", { overflow = item })
                end
            end
            return true
        else
            return
        end
    end

    self.GetOverflowContainer = function()
        if self.ignoreoverflow then
            return
        end
        local item = self:GetEquippedItem(GLOBAL.EQUIPSLOTS.BACK)
        return item ~= nil and item.components.container or nil
    end
end)

AddGlobalClassPostConstruct("widgets/inventorybar", "Inv", function()
    local Inv_Refresh_base = Inv.Refresh or function() return "" end
    local Inv_Rebuild_base = Inv.Rebuild or function() return "" end

    function Inv:LoadExtraSlots(self)
        self.bg:SetScale(1.35,1,1.25)
        self.bgcover:SetScale(1.35,1,1.25)

        if self.addextraslots == nil then
            self.addextraslots = 1

            self:AddEquipSlot(GLOBAL.EQUIPSLOTS.BACK, "images/back.xml", "back.tex")
            self:AddEquipSlot(GLOBAL.EQUIPSLOTS.NECK, "images/neck.xml", "neck.tex")
			self:AddEquipSlot(GLOBAL.EQUIPSLOTS.WAIST, "images/waist.xml", "waist.tex")
            if self.inspectcontrol then
                local W = 68
                local SEP = 12
                local INTERSEP = 28
                local inventory = self.owner.replica.inventory
                local num_slots = inventory:GetNumSlots()
                local num_equip = #self.equipslotinfo
                local num_buttons = self.controller_build and 0 or 1
                local num_slotintersep = math.ceil(num_slots / 5)
                local num_equipintersep = num_buttons > 0 and 1 or 0
                local total_w = (num_slots + num_equip + num_buttons) * W + (num_slots + num_equip + num_buttons - num_slotintersep - num_equipintersep - 1) * SEP + (num_slotintersep + num_equipintersep) * INTERSEP
            	self.inspectcontrol.icon:SetPosition(-4, 6)
            	self.inspectcontrol:SetPosition((total_w - W) * .5 + 3, -6, 0)
            end
        end
    end

    function Inv:Refresh()
        Inv_Refresh_base(self)
        Inv:LoadExtraSlots(self)
    end

    function Inv:Rebuild()
        Inv_Rebuild_base(self)
        Inv:LoadExtraSlots(self)
    end
end)

AddPrefabPostInit("inventory_classified", function(inst)
    function GetOverflowContainer(inst)
        local item = inst.GetEquippedItem(inst, GLOBAL.EQUIPSLOTS.BACK)
        return item ~= nil and item.replica.container or nil
    end

    function Count(item)
        return item.replica.stackable ~= nil and item.replica.stackable:StackSize() or 1
    end

    function Has(inst, prefab, amount)
        local count =
            inst._activeitem ~= nil and
            inst._activeitem.prefab == prefab and
            Count(inst._activeitem) or 0

        if inst._itemspreview ~= nil then
            for i, v in ipairs(inst._items) do
                local item = inst._itemspreview[i]
                if item ~= nil and item.prefab == prefab then
                    count = count + Count(item)
                end
            end
        else
            for i, v in ipairs(inst._items) do
                local item = v:value()
                if item ~= nil and item ~= inst._activeitem and item.prefab == prefab then
                    count = count + Count(item)
                end
            end
        end

        local overflow = GetOverflowContainer(inst)
        if overflow ~= nil then
            local overflowhas, overflowcount = overflow:Has(prefab, amount)
            count = count + overflowcount
        end

        return count >= amount, count
    end

    if not IsServer then
        inst.GetOverflowContainer = GetOverflowContainer
        inst.Has = Has
    end
end)

AddStategraphPostInit("wilson", function(self)
    for key,value in pairs(self.states) do
        if value.name == 'amulet_rebirth' then
            local original_amulet_rebirth_onexit = self.states[key].onexit


            self.states[key].onexit = function(inst)
                local item = inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
                if item and item.prefab == "amulet" then
                    item = inst.components.inventory:RemoveItem(item)
                    if item then
                        item:Remove()
                        item.persists = false
                    end
                end
                original_amulet_rebirth_onexit(inst)
            end
        end
    end
end)

function backpackpostinit(inst)
    if IsServer then
        inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.BACK
    end
end

function amuletpostinit(inst)
    if IsServer then
        inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.NECK
    end
end

function compasspostinit(inst)
	if IsServer then
		inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.WAIST
	end
end

AddPrefabPostInit("amulet", amuletpostinit)
AddPrefabPostInit("blueamulet", amuletpostinit)
AddPrefabPostInit("purpleamulet", amuletpostinit)
AddPrefabPostInit("orangeamulet", amuletpostinit)
AddPrefabPostInit("greenamulet", amuletpostinit)
AddPrefabPostInit("yellowamulet", amuletpostinit)

AddPrefabPostInit("backpack", backpackpostinit)
AddPrefabPostInit("krampus_sack", backpackpostinit)
AddPrefabPostInit("piggyback", backpackpostinit)
AddPrefabPostInit("icepack", backpackpostinit)
AddPrefabPostInit("pirateback", backpackpostinit)

AddPrefabPostInit("compass", compasspostinit)

if INVENTORYSIZE ~= 15 then

    local inventory_CTorBase = inventory._ctor or function() return true end
    function inventory._ctor(self, inst)
        self.inst = inst
        self.isopen = false
        self.isvisible = false

        self.ignoreoverflow = false
        self.ignorefull = false
        self.ignoresound = false

        self.itemslots = { }
        self.maxslots = MAXITEMSLOTS

        self.equipslots = { }

        self.activeitem = nil
        self.acceptsstacks = true
        self.ignorescangoincontainer = false
        self.opencontainers = { }

        if inst.replica.inventory.classified ~= nil then
            makereadonly(self, "maxslots")
            makereadonly(self, "acceptsstacks")
            makereadonly(self, "ignorescangoincontainer")
        end
    end
	
    local InventoryGetNumSlotsBase = inventory_replica.GetNumSlots
    function inventory_replica:GetNumSlots()
        local result = InventoryGetNumSlotsBase(self)
        return MAXITEMSLOTS
    end

    local function addItemSlotNetvarsInInventory(inst)
        if (#inst._items < MAXITEMSLOTS) then
            for i = #inst._items + 1, MAXITEMSLOTS do
                table.insert(inst._items, net_entity(inst.GUID, "inventory._items[" .. tostring(i) .. "]", "items[" .. tostring(i) .. "]dirty"))
            end
        end
    end
    AddPrefabPostInit("inventory_classified", addItemSlotNetvarsInInventory)

    local HUD_ATLAS = "images/hud.xml"
    local W = 64
    local SEP = 7
    local YSEP = 8
    local INTERSEP = 15

    local inv_CTorBase = inv._ctor or function() return true end
    function inv._ctor(self, owner)
        inv_CTorBase(self, owner)

        self.root:KillAllChildren()
        self.bg = self.root:AddChild(ThreeSlice(HUD_ATLAS, "inventory_corner.tex", "inventory_filler.tex"))
        self.newbg = self.root:AddChild(Image("images/inventory_bg.xml", "inventory_bg.tex"))
        self.newbg:SetVRegPoint(ANCHOR_BOTTOM)
        if MAXITEMSLOTS == 45 then
            self.newbg:SetScale(1.393, 1.128, 0)
        elseif MAXITEMSLOTS == 46 or MAXITEMSLOTS == 44 then
            self.newbg:SetScale(1.45, 1.128, 0)
        elseif MAXITEMSLOTS == 26 or MAXITEMSLOTS == 24 then
            self.newbg:SetScale(0.89, 1.128, 0)
        else
            self.newbg:SetScale(0.84, 1.128, 0)
        end
        self.newbg:SetPosition(Vector3(0, -93, 0))
		
		self.hudcompass = self.root:AddChild(HudCompass(owner, true))
		self.hudcompass:SetScale(1.5, 1.5)
		self.hudcompass:SetPosition(620, 70, 0)

        self.repeat_time = .2

        self.actionstring = self.root:AddChild(Widget("actionstring"))
        self.actionstring:SetScaleMode(SCALEMODE_PROPORTIONAL)

        self.actionstringtitle = self.actionstring:AddChild(Text(TALKINGFONT, 35))
        self.actionstringtitle:SetColour(204 / 255, 180 / 255, 154 / 255, 1)

        self.actionstringbody = self.actionstring:AddChild(Text(TALKINGFONT, 25))
        self.actionstringbody:EnableWordWrap(true)
        self.actionstring:Hide()

        self.root:SetPosition(self.in_pos)
        self:StartUpdating()
    end

    local function BackpackGet(inst, data)
        local owner = ThePlayer
        if owner ~= nil and owner.HUD ~= nil and owner.replica.inventory:IsHolding(inst) then
            local inv = owner.HUD.controls.inv
            if inv ~= nil then
                inv:OnItemGet(data.item, inv.backpackinv[data.slot], data.src_pos, data.ignore_stacksize_anim)
            end
        end
    end

    local function BackpackLose(inst, data)
        local owner = ThePlayer
        if owner ~= nil and owner.HUD ~= nil and owner.replica.inventory:IsHolding(inst) then
            local inv = owner.HUD.controls.inv
            if inv then
                inv:OnItemLose(inv.backpackinv[data.slot])
            end
        end
    end

	
    local function InventorybarRework(self)
        function inv:Rebuild()
            if self.cursor then
                self.cursor:Kill()
                self.cursor = nil
            end

            if self.toprow then
                self.toprow:Kill()
            end

            if self.bottomrow then
                self.bottomrow:Kill()
            end

            self.toprow = self.root:AddChild(Widget("toprow"))
            self.bottomrow = self.root:AddChild(Widget("toprow"))
            self.bottomrow:SetPosition(0, - W - SEP, 0)
            self.inv = { }
            self.equip = { }
            self.backpackinv = { }

            local row_offset =(W + SEP)

            local inventory = self.owner.replica.inventory
            local overflow = inventory:GetOverflowContainer()

            local y = 0
            local eslot_order = { }

            local num_slots = MAXITEMSLOTS

            if EXTRASLOT == 1 then
                num_slots = MAXITEMSLOTS - 1
            end
			
			if EXTRASLOT > 1 then
                num_slots = MAXITEMSLOTS + 1
            end

            local num_equip = #self.equipslotinfo

            local T = num_slots + 5

            local num_intersep =(T / 10) -1
            local total_w =(num_slots -((num_slots - 5) / 2)) *(W) +(num_slots -((num_slots - 5) / 2) -1 - num_intersep) *(SEP) +(INTERSEP * num_intersep)
            local total_e = num_equip * 64 + SEP *(num_equip - 1)

            for k, v in ipairs(self.equipslotinfo) do
                local slot = EquipSlot(v.slot, v.atlas, v.image, self.owner)
                self.equip[v.slot] = self.toprow:AddChild(slot)
                local x = - total_e / 2 + W / 2 +(k - 1) * W +(k - 1) * SEP
                slot:SetPosition(x, y + row_offset + 2, 0)
                table.insert(eslot_order, slot)

                local item = inventory:GetEquippedItem(v.slot)
                if item then
                    slot:SetTile(ItemTile(item, inventory))
                end

            end

            if EXTRASLOT > 0 then
                if MAXITEMSLOTS > 40 then
                    for k = 1, T / 5 do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = math.floor((k - 1 - T / 2) / 5)
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP + 5
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end

                    for k = T / 5 + 1, T / 5 + 6 do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = 0
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP - 19
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end

                    for k =((T / 5) + 7),(T / 2 + 1) do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = math.floor((k + 5 - 2 - T / 2) / 5)
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP - 3
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end
					
					if EXTRASLOT == 1 then
						for k =((T / 2) + 2),((T / 2) +((T / 2) -5) / 2 + 1) do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 2 - T / 2) * W +(k - 2 - T / 2) * SEP - 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end

						for k =((T / 2) +((T / 2) -5) / 2 + 1) + 1,(T - 5) + 1 do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k + 5 - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k + 5 - 2 - T / 2) * W +(k + 5 - 2 - T / 2) * SEP + 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end
					else
						for k =((T / 2) + 2),((T / 2) +((T / 2) -5) / 2 ) do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 2 - T / 2) * W +(k - 2 - T / 2) * SEP - 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end

						for k =((T / 2) +((T / 2) -5) / 2 + 1) ,(T - 5) - 1 do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k + 5  - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k + 5  - T / 2) * W +(k + 5  - T / 2) * SEP + 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end
					end
                else
                    for k = 1, T / 6 do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = math.floor((k - 1 - T / 2) / 5)
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP - 12
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end

                    for k = T / 6 + 1, T / 6 + 6 do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = 0
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP - 28
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end

                    for k =((T / 6) + 7),(T / 2 + 1) do
                        local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                        self.inv[k] = self.toprow:AddChild(slot)
                        local interseps = math.floor((k + 5 - 2 - T / 2) / 5)
                        local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP - 18
                        slot:SetPosition(x, y, 0)

                        local item = inventory:GetItemInSlot(k)
                        if item then
                            slot:SetTile(ItemTile(item, inventory))
                        end
                    end
					if EXTRASLOT == 1 then
						for k =((T / 2) + 2),((T / 2) +((T / 2) -5) / 2 + 1) do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 2 - T / 2) * W +(k - 2 - T / 2) * SEP - 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end

						for k =((T / 2) +((T / 2) -5) / 2 + 1) + 1,(T - 5) + 1 do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k + 5 - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k + 5 - 2 - T / 2) * W +(k + 5 - 2 - T / 2) * SEP + 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end
					else
						for k =((T / 2) + 2),((T / 2) +((T / 2) -5) / 2 ) do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k - 2 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 2 - T / 2) * W +(k - 2 - T / 2) * SEP - 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end

						for k =((T / 2) +((T / 2) -5) / 2 + 1) ,(T - 5) - 1 do
							local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
							self.inv[k] = self.toprow:AddChild(slot)
							local interseps = math.floor((k + 5 - T / 2) / 5)
							local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k + 5 - T / 2) * W +(k + 5 - T / 2) * SEP + 36
							slot:SetPosition(x, y + row_offset, 0)

							local item = inventory:GetItemInSlot(k)
							if item then
								slot:SetTile(ItemTile(item, inventory))
							end
						end
					end
                end
            else
                for k = 1, T / 2 do
                    local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                    self.inv[k] = self.toprow:AddChild(slot)
                    local interseps = math.floor((k - 1) / 5)
                    local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP
                    slot:SetPosition(x, y, 0)

                    local item = inventory:GetItemInSlot(k)
                    if item then
                        slot:SetTile(ItemTile(item, inventory))
                    end
                end

                for k =((T / 2) + 1),((T / 2) +((T / 2) -5) / 2) do
                    local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                    self.inv[k] = self.toprow:AddChild(slot)
                    local interseps = math.floor((k - 1 - T / 2) / 5)
                    local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k - 1 - T / 2) * W +(k - 1 - T / 2) * SEP
                    slot:SetPosition(x, y + row_offset, 0)

                    local item = inventory:GetItemInSlot(k)
                    if item then
                        slot:SetTile(ItemTile(item, inventory))
                    end
                end

                for k =((T / 2) +((T / 2) -5) / 2 + 1),(T - 5) do
                    local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, inventory)
                    self.inv[k] = self.toprow:AddChild(slot)
                    local interseps = math.floor((k + 5 - 1 - T / 2) / 5)
                    local x = - total_w / 2 + W / 2 + interseps *(INTERSEP - SEP) +(k + 5 - 1 - T / 2) * W +(k + 5 - 1 - T / 2) * SEP
                    slot:SetPosition(x, y + row_offset, 0)

                    local item = inventory:GetItemInSlot(k)
                    if item then
                        slot:SetTile(ItemTile(item, inventory))
                    end
                end
            end

            local image_name = "self_inspect_" .. self.owner.prefab .. ".tex"
            local atlas_name = "images/hud.xml"

            if not self.controller_build then
                self.bg:SetScale(1.22, 1, 1)
                self.bgcover:SetScale(1.22, 1, 1)
                self.inspectcontrol = self.root:AddChild(TEMPLATES.IconButton(atlas_name, image_name, "Inspect Self", false, false, function() self.owner.HUD:InspectSelf() end, { size = 40 }, "self_inspect_mod.tex"))
                self.inspectcontrol.icon:SetScale(.7)
                self.inspectcontrol.icon:SetPosition(-4, 6)
                self.inspectcontrol:SetScale(1.25)
                self.inspectcontrol:SetPosition((total_w - W) * .5 + 3, 150 - 6, 0)
            else
                self.bg:SetScale(1.15, 1, 1)
                self.bgcover:SetScale(1.15, 1, 1)

                if self.inspectcontrol ~= nil then
                    self.inspectcontrol:Kill()
                    self.inspectcontrol = nil
                end
            end


            local old_backpack = self.backpack
            if self.backpack then
                self.inst:RemoveEventCallback("itemget", BackpackGet, self.backpack)
                self.inst:ListenForEvent("itemlose", BackpackLose, self.backpack)
                self.backpack = nil
            end

            local new_backpack = inventory.overflow
            local do_integrated_backpack = _G.TheInput:ControllerAttached() and new_backpack

            if do_integrated_backpack then

                local num = new_backpack.components.container.numslots
                local total_wb = 0
                local backpack_controller_size_max = 0

                backpack_controller_size_max = 25
                total_wb =(num_slots + 5) / 2 * W +((num_slots + 5) / 2 - 1 - 4) * SEP + 4 * INTERSEP

                if num > backpack_controller_size_max then

                    for k = backpack_controller_size_max + 1, num do
                        local item = new_backpack.components.container:GetItemInSlot(k)
                        new_backpack.components.container:DropItem(item)
                    end

                    new_backpack.components.container:SetNumSlots(backpack_controller_size_max, num)
                    num = backpack_controller_size_max
                end

                for k = 1, num do
                    local slot = InvSlot(k, HUD_ATLAS, "inv_slot.tex", self.owner, new_backpack.components.container)
                    self.backpackinv[k] = self.bottomrow:AddChild(slot)
                    local interseps_backpack = math.floor((k - 1) / 5)
                    local x = - total_wb / 2 + W / 2 + interseps_backpack *(INTERSEP - SEP) +(k - 1) * W +(k - 1) * SEP
                    slot:SetPosition(x, y, 0)

                    local item = new_backpack.components.container:GetItemInSlot(k)
                    if item then
                        slot:SetTile(ItemTile(item))
                    end
                end

                self.backpack = inventory.overflow
                self.inst:ListenForEvent("itemget", BackpackGet, self.backpack)
                self.inst:ListenForEvent("itemlose", BackpackLose, self.backpack)

            end

            if old_backpack and not self.backpack then
                self:SelectSlot(self.inv[1])
                self.current_list = self.inv
            end

            if do_integrated_backpack then
                self.root:SetPosition(self.in_pos)
            else
                self.root:SetPosition(self.out_pos)
            end

            self.actionstring:MoveToFront()

            self:SelectSlot(self.inv[1])
            self.current_list = self.inv
            self:UpdateCursor()

            if self.cursor then
                self.cursor:MoveToFront()
            end

            self.rebuild_pending = false
        end

        local oldOnUpdate = self.OnUpdate

        function self:OnUpdate(dt)

            oldOnUpdate(self, dt)

            self.openhint:Hide()
        end
    end


    AddClassPostConstruct("widgets/inventorybar", InventorybarRework)

end

local SERVER_SIDE = _G.TheNet:GetIsServer()

if not SERVER_SIDE then
    return
end

AddPrefabPostInit("backpack",
function(inst)
    if ENABLEBACKPACK == true then
        if inst.components.inventoryitem then
            inst.components.inventoryitem.cangoincontainer = true
        end
    else
        if inst.components.inventoryitem then
            inst.components.inventoryitem.cangoincontainer = false
        end
    end
end )