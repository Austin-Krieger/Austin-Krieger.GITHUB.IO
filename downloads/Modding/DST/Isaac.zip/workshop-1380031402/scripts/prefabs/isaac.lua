local MakePlayerCharacter = require "prefabs/player_common"
 
local assets = {
 
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),
 
        Asset( "ANIM", "anim/isaac.zip" ),
        Asset( "ANIM", "anim/ghost_isaac_build.zip" ),
}

local prefabs = {}

local start_inv = {
        -- Custom starting items
}
 
-- This initializes for both clients and the host
local common_postinit = function(inst)
        -- Minimap icon
        inst.MiniMapEntity:SetIcon( "isaac.tex" )
end

-- Night light
local function Nightlight(inst)
        if TheWorld.state.phase == "day" then
                inst.Light:Enable(false)
        elseif TheWorld.state.phase == "dusk" or TheWorld.state.phase == "night" then
                inst.Light:Enable(true)
        end
end
-- Moonlight Boost
local function Moonlight(inst, power, speed, defense)
        inst.components.combat.damagemultiplier = (power*0.5)
        inst.components.health:StartRegen(power*0.125, 1)
        inst.components.locomotor.walkspeed = (speed*4)
        inst.components.locomotor.runspeed = (speed*6)
        inst.components.health:SetAbsorptionAmount(defense*1)
end
-- Fix glowing
local function Glowfix(inst)
        inst.Light:Enable(true)
        inst.Light:SetRadius(6)
        inst.Light:SetFalloff(.5)
        inst.Light:SetIntensity(0.9)
        inst.Light:SetColour(255/255,255/255,205/255)
end

 -- This initializes for the host only
local master_postinit = function(inst)
        -- choose which sounds this character will play
        inst.soundsname = "wilson"
        -- Stats
        inst.components.health:SetMaxHealth(250)
        inst.components.hunger:SetMax(150)
        inst.components.sanity:SetMax(200)
        inst.components.temperature.inherentinsulation = 45

        -- Checks for Day/Dusk/Night/Cave, & Health Conditions.
        local refreshTime = 1/10
        inst:DoPeriodicTask(refreshTime, function() Nightlight(inst, refreshTime) end)

        -- Glow in the Dark!
        inst.entity:AddLight()
        inst.Light:Enable(true)
        inst.Light:SetRadius(6)
        inst.Light:SetFalloff(.5)
        inst.Light:SetIntensity(0.9)
        inst.Light:SetColour(255/255,255/255,205/255)

        inst:ListenForEvent("ms_respawnedfromghost", Glowfix)

        -- No Loss of Sanity at Night
        inst.components.sanity.night_drain_mult = -5

        -- Loses Sanity from Monsters ( can't be specific unfortunately )
        --inst.components.sanity.neg_aura_mult = 2.5
        
        -- Loses Sanity during Day
        --inst.components.sanity.dapperness = TUNING.DAPPERNESS_LARGE * (-1)

	if GetModConfigData("ABSORBANT", "workshop-1380031402") == 1 then
		inst:AddComponent("absorbant")
	end
	
	inst:AddComponent("devilmode")
        
        if GetModConfigData("CRYBABY", "workshop-1380031402") == 1 then
	       inst:AddComponent("crybaby")
	end

        -- Local Variables for Stat Changes
        local power = 1
        local speed = 1
        local defense = 0

        -- ORIGINAL MOONLIGHT BUFF WAS POWER = 5 & SPEED = 3; THEN ADDED DEFENSE WHICH IS 0.75
        inst:WatchWorldState( "startday", function() Moonlight(inst, 0.5, 1, 0) end )
        inst:WatchWorldState( "startdusk", function() Moonlight(inst, 0.75, 1.25, 0) end )
        inst:WatchWorldState( "startnight", function() Moonlight(inst, 1, 1.5, 0) end )
        inst:WatchWorldState( "isfullmoon", function() Moonlight(inst, 5, 3, 0.75) end )

        if TheWorld.state.isfullmoon then power = 5; speed = 3; defense = 0.75
        elseif TheWorld.state.isday then power = 0.5; speed = 1; defense = 0
        elseif TheWorld.state.isdusk then power = 0.75; speed = 1.25; defense = 0
        elseif TheWorld.state.isnight then power = 1; speed = 1.5; defense = 0 end
        Moonlight(inst, power, speed, defense)
end

return MakePlayerCharacter("isaac", prefabs, assets, common_postinit, master_postinit, start_inv)