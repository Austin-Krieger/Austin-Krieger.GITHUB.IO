local sanity_thresholdDevil = nil
local hpBUFF = nil
local dmgBUFF = nil
local msBUFF = nil
local resBUFF = nil
local devilmodeActive = nil
local movementspeedIsaac = nil
local devilModeHealth = nil

local Devilmode = Class(function(self, inst)
    self.inst = inst
    sanity_thresholdDevil = GetModConfigData("SANITYTHRESHOLDDEVIL", "workshop-1380031402") / 100
	hpBUFF = GetModConfigData("HPBUFF", "workshop-1380031402") / 100 + 1
	dmgBUFF = GetModConfigData("DMGBUFF", "workshop-1380031402") / 100 + 1
	msBUFF = GetModConfigData("MSBUFF", "workshop-1380031402") / 100 + 1
	resBUFF = GetModConfigData("RESBUFF", "workshop-1380031402") / 100
	devilmodeActive = true
	movementspeedIsaac = TUNING.WILSON_RUN_SPEED
	
	self.inst:DoPeriodicTask(1, function(inst) devilmode1(inst) end)
end)


function devilmode1(inst)
	if sanity_thresholdDevil ~= nil and inst.components.sanity:GetPercent() <= sanity_thresholdDevil then --if Lamb then
		if devilmodeActive == true then --If the devilmode is active
		
			--MSBUFF
			inst.components.locomotor.walkspeed = movementspeedIsaac * msBUFF
			inst.components.locomotor.runspeed = movementspeedIsaac * msBUFF
			--MSBUFF
			
			--HPBUFF
			devilModeHealth = inst.components.health.currenthealth --Need this to calculate the HP after the buff activates
			inst.components.health:SetMaxHealth(inst.components.health.maxhealth * hpBUFF)
			inst.components.health:SetCurrentHealth(devilModeHealth * hpBUFF) --new HP after the buff
			inst.components.health:DoDelta(0) --Used to updated the UI
			--HPBUFF
			
			--DMG RESISTANCE
			inst.components.health:SetAbsorptionAmount(resBUFF)
			--DMG RESISTANCE
			
			--DMGBUFF
			inst.components.combat.damagemultiplier = dmgBUFF
			--DMGBUFF
			
			devilmodeActive = false --Set it to inactive so this whole block won't repeat
			inst.components.talker:Say("Revel in the power of darkness!")
		end
	else
		if devilmodeActive == false then --It can only reach this block if the treshold is not reached
		
			--MSBUFF
			inst.components.locomotor.walkspeed = movementspeedIsaac
			inst.components.locomotor.runspeed = movementspeedIsaac
			--MSBUFF
			
			--HPBUFF
			devilModeHealth = inst.components.health.currenthealth --Need this to calculate the HP after the buff activates
			inst.components.health:SetMaxHealth(200)
			inst.components.health:SetCurrentHealth(devilModeHealth / hpBUFF) --new HP after the buff
			inst.components.health:DoDelta(0) --Used to updated the UI
			--HPBUFF
			
			--RESBUFF
			inst.components.health:SetAbsorptionAmount(0)
			--RESBUFF
			
			--DMGBUFF
			inst.components.combat.damagemultiplier = 1
			--DMGBUFF
			
			devilmodeActive = true
			inst.components.talker:Say("I am a lamb, the lord is my shepherd!")
		end
	end
end

function Devilmode:GetDebugString()
	return
end

return Devilmode
