local time_to_cry = nil
local sanity_thresholdCrybaby = nil
local Crybaby = Class(function(self, inst)
    self.inst = inst
    time_to_cry = math.random(180 , 300)
    sanity_thresholdCrybaby = GetModConfigData("SANITYTHRESHOLDCRY", "workshop-1380031402") / 100
	
	self.inst:DoPeriodicTask(1, function(inst) cry(inst) end)
end)


function cry(inst)
	if sanity_thresholdCrybaby ~= nil and inst.components.sanity:GetPercent() < sanity_thresholdCrybaby then
		if time_to_cry >= 1 then 									--if not crying yet
			time_to_cry = time_to_cry - 1 							--take some time off the timer
		else														--otherwise cry
			for i, v in ipairs(AllPlayers) do						--Get list of all players
				if v.prefab == "isaac" then							--If character is Isaac
					v:PushEvent("emote", { anim = "emoteXL_sad", fx = "tears", fxdelay = 17 * FRAMES, mounted = true })
				end
			end
			time_to_cry = math.random(180 , 300)					--new timer
		end
	end
end

function Crybaby:GetDebugString()
	return
end

return Crybaby
