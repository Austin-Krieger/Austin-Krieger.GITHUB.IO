local absorbant_Regen = nil
local Absorbant = Class(function(self, inst)
    self.inst = inst
	absorbant_Regen = GetModConfigData("ABSORBANTREGEN", "workshop-1380031402")
	self.inst:DoPeriodicTask(absorbant_Regen, function(inst) regenerateHealth(inst) end)
end)


function regenerateHealth(inst)
	if TheWorld.state.israining then
		inst.components.health:DoDelta(1)
	end

	if TheWorld.state.isdusk then
		inst.components.health:DoDelta(1)
	end

	if TheWorld.state.isnight then
		inst.components.health:DoDelta(1)
	end
end

function Absorbant:GetDebugString()
	return
end

return Absorbant