PrefabFiles = {
	"isaac",
}

-- Quick Pick
function pick(inst)
    if inst.components.pickable then
    inst.components.pickable.quickpick = true
    end
end

AddPrefabPostInit("sapling", pick)
AddPrefabPostInit("marsh_bush", pick)
AddPrefabPostInit("reeds", pick)
AddPrefabPostInit("grass", pick)
AddPrefabPostInit("berrybush2", pick)
AddPrefabPostInit("berrybush", pick)
AddPrefabPostInit("flower_cave", pick)
AddPrefabPostInit("flower_cave_double", pick)
AddPrefabPostInit("flower_cave_triple", pick)
AddPrefabPostInit("red_mushroom", pick)
AddPrefabPostInit("green_mushroom", pick)
AddPrefabPostInit("blue_mushroom", pick)
AddPrefabPostInit("cactus", pick)
AddPrefabPostInit("lichen", pick)
AddPrefabPostInit("tallbirdegg", pick)

-- Back to character modding
Assets = {
    Asset( "IMAGE", "images/saveslot_portraits/isaac.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/isaac.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/isaac.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/isaac.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/isaac_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/isaac_silho.xml" ),

    Asset( "IMAGE", "bigportraits/isaac.tex" ),
    Asset( "ATLAS", "bigportraits/isaac.xml" ),
	
	Asset( "IMAGE", "images/map_icons/isaac.tex" ),
	Asset( "ATLAS", "images/map_icons/isaac.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_isaac.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_isaac.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_isaac.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_isaac.xml" ),

}

local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS

-- The character select screen lines
STRINGS.CHARACTER_TITLES.isaac = "Isaac"
STRINGS.CHARACTER_NAMES.isaac = "The Sacrificed"
STRINGS.CHARACTER_DESCRIPTIONS.isaac = "Devilmode\nAbsorbant\nCrybaby"
STRINGS.CHARACTER_QUOTES.isaac = "\"Who am I?\""

-- Custom speech strings
STRINGS.CHARACTERS.ISAAC = require "speech_isaac"

-- The character's name as appears in-game 
STRINGS.NAMES.ISAAC = "Isaac"

-- The default responses of examining the character
STRINGS.CHARACTERS.GENERIC.DESCRIBE.ISAAC = 
{
	GENERIC = "It's Isaac!",
	ATTACKER = "That Isaac looks shifty...",
	MURDERER = "Murderer!",
	REVIVER = "Isaac, friend of ghosts.",
	GHOST = "Isaac could use a heart.",
}

-- Let the game know character is male, female, or robot
table.insert(GLOBAL.CHARACTER_GENDERS.MALE, "isaac")


AddMinimapAtlas("images/map_icons/isaac.xml")
AddModCharacter("isaac")

local starting_inventory = GetModConfigData("inv_start")
AddPrefabPostInit("isaac", function(inst)
    if inst.OnNewSpawn then
        inst.old_OnNewSpawn = inst.OnNewSpawn
    end
     
    inst.OnNewSpawn = function(inst)
        if inst.components.inventory ~= nil then
            inst.components.inventory.ignoresound = true
            for i, v in ipairs(starting_inventory.split(starting_inventory,",")) do
                inst.components.inventory:GiveItem(GLOBAL.SpawnPrefab(v))
            end
            inst.components.inventory.ignoresound = false
        end
        if inst.old_OnNewSpawn then
            return inst:old_OnNewSpawn(inst)
        end
    end
end)