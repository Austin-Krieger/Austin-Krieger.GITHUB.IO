name = "More Actions"
description = "Jump, shove, push, hide, take refuge, and search."

author = "Isosurface"
version = "1.2.9"

forumthread = ""

api_version = 10

icon_atlas = "modicon.xml"
icon = "modicon.tex"

dst_compatible = true

client_only_mod = false
all_clients_require_mod = true
server_filter_tags = {"actions"}

priority = 0