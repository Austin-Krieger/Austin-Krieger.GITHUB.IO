local _G = _G or GLOBAL

local classic = {		
		DEERCLOPS_HEALTH = 2000 * 2, -- harder for multiplayer
		DEERCLOPS_DAMAGE = 150,		
		
		BEARGER_HEALTH = 3000 * 2, -- harder for multiplayer
		BEARGER_DAMAGE = 200,

		DRAGONFLY_HEALTH = 27500,
		DRAGONFLY_DAMAGE = 150,

		MOOSE_HEALTH = 3000 * 2, -- harder for multiplayer
		MOOSE_DAMAGE = 150,

		LAVAE_HEALTH = 500,
		LAVAE_DAMAGE = 50,

		MOSSLING_HEALTH = 350 * 1.5, -- harder for multiplayer
		MOSSLING_DAMAGE = 50,

		LEIF_HEALTH = 2000 * 1.5, -- harder for multiplayer
		LEIF_DAMAGE = 150,		
		
		SPIDERQUEEN_HEALTH = 1250 * 2,
		SPIDERQUEEN_DAMAGE = 80,
		
		--NB: New in 1.03:
		
		TOADSTOOL_HEALTH = 52500,
		TOADSTOOL_DAMAGE = 100,
		
		WARG_HEALTH = 600 * 3,
		WARG_DAMAGE = 50,

		KOALEFANT_HEALTH = 500 * 2, -- harder for multiplayer
		KOALEFANT_DAMAGE = 50,
		KNIGHT_DAMAGE = 40,
		KNIGHT_HEALTH = 300 * 3, -- harder for multiplayer
		BISHOP_DAMAGE = 40,
		BISHOP_HEALTH = 300 * 3, -- harder for multiplayer
		ROOK_DAMAGE = 45,
		ROOK_HEALTH = 300 * 3, -- harder for multiplayer
		MINOTAUR_DAMAGE = 100,
		MINOTAUR_HEALTH = 2500 * 4, -- harder for multiplayer
		SPIDER_WARRIOR_HEALTH = 200 * 2, -- harder for multiplayer
		SPIDER_WARRIOR_DAMAGE = 20,
		
		--1.04
		BEEQUEEN_HEALTH = 22500,
		BEEQUEEN_DAMAGE = 120,
		
		--1.05
		KLAUS_HEALTH = 10000,
		KLAUS_DAMAGE = 75,

		STALKER_HEALTH = 4000,
		STALKER_DAMAGE = 200,
		
		ANTLION_HEALTH = 6000,
		--no ANTLION damage.
}

for k,v in pairs(classic) do
	local c = GetModConfigData(k) or 0
	if c and c ~= 0 then
		TUNING[k] = c
	end
end


-------------------Server Side--------------------
if _G.TheNet and _G.TheNet:GetIsServer() then

dragonfly_restore = GetModConfigData("dragonfly_restore")

if not dragonfly_restore then
	print("No restore HP for Dragonfly.")
	local function dragonfly_health_down(inst)
		if inst and inst:IsValid() and inst.persists and inst.components.health then
			local h = inst.components.health
			local m = math.min(h.currenthealth,h.save_min_health)
			h.currenthealth = m
			h.save_min_health = m
		end
	end

	AddPrefabPostInit("dragonfly",function(inst)
		inst.components.health.save_min_health = 50000
		inst:DoPeriodicTask(4+math.random(),dragonfly_health_down)
	end)
end

dragonfly_regen = GetModConfigData("dragonfly_regen") or 0

if dragonfly_regen > 0 then
	print("Slow regen of HP for Dragonfly: +"..dragonfly_regen.." per min.")
	local tm = dragonfly_regen > 60 and 1 or 60/dragonfly_regen
	local hp = dragonfly_regen * tm / 60
	AddPrefabPostInit("dragonfly",function(inst)
		inst:DoPeriodicTask(tm+math.random()*0.1,function(inst)
			if inst:IsValid() then	
				local h = inst.components.health
				h:DoDelta(hp,false,"regen")
				if h.save_min_health then
					h.save_min_health = h.save_min_health + hp
				end
			end
		end)
	end)
end

dragonfly_speed =  GetModConfigData("dragonfly_speed") or 1
if dragonfly_speed ~= 1 then
	TUNING.DRAGONFLY_SPEED = TUNING.DRAGONFLY_SPEED * dragonfly_speed
	TUNING.DRAGONFLY_FIRE_SPEED = TUNING.DRAGONFLY_FIRE_SPEED * dragonfly_speed
end

lavae_speed =  GetModConfigData("lavae_speed") or 1
if lavae_speed ~= 1 then
	AddPrefabPostInit("lavae",function(inst)
		inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed * lavae_speed
	end)
end

end



	
