--[[
Hint for owners of dedicated servers how to change modoverrides.lua:

----------- Full list of options: ---------

["workshop-436164138"] = {
	enabled = true,
	configuration_options =
	{
		DRAGONFLY_HEALTH = 27500, -- default is 27500 for DST. Also you can use 0 to keep original DST value.
		DRAGONFLY_DAMAGE = 0, -- "0" means "Do not tweak" (It's 150 by default).

		LAVAE_HEALTH = 0, -- Use default game value (500)
		LAVAE_DAMAGE = 0, -- Use default game value (50)

		DEERCLOPS_HEALTH = 2000, -- classic (default x2 for DST )
		DEERCLOPS_DAMAGE = 150, -- default=150
		
		BEARGER_HEALTH = 3000, -- classic (default x2 for DST )
		BEARGER_DAMAGE = 200, --default=200

		MOOSE_HEALTH = 3000, -- classic (default x2 for DST )
		MOOSE_DAMAGE = 150, --default=150

		MOSSLING_HEALTH = 350, -- classic (default x1.5 for DST )
		MOSSLING_DAMAGE = 50, --default=50

		LEIF_HEALTH = 2000, -- classic (default x1.5 for DST )
		LEIF_DAMAGE = 150,	--default=150
		
		SPIDERQUEEN_HEALTH = 1250, --classic (default x2 for DST )
		SPIDERQUEEN_DAMAGE = 80, --default is 80

		dragonfly_restore = false, --default is true
		dragonfly_regen = 60, --default is 0
		dragonfly_speed = 0.8, --default is 1.	  1 == 100%,	0.8 == 80% etc
		lavae_speed = 0.8, --default is 1

		TOADSTOOL_HEALTH = 20000, --(default is 52500)
		TOADSTOOL_DAMAGE = 100, --default 100
		WARG_HEALTH = 600 * 3,
		WARG_DAMAGE = 50,
		KOALEFANT_HEALTH = 500 * 2, -- harder for multiplayer
		KOALEFANT_DAMAGE = 50,
		KNIGHT_HEALTH = 300 * 3, -- harder for multiplayer
		KNIGHT_DAMAGE = 40,
		BISHOP_HEALTH = 300 * 3, -- harder for multiplayer
		BISHOP_DAMAGE = 40,
		ROOK_HEALTH = 300 * 3, -- harder for multiplayer
		ROOK_DAMAGE = 45,
		MINOTAUR_HEALTH = 2500 * 4, -- harder for multiplayer
		MINOTAUR_DAMAGE = 100,
		SPIDER_WARRIOR_HEALTH = 200 * 2, -- harder for multiplayer
		SPIDER_WARRIOR_DAMAGE = 20,
		
		BEEQUEEN_HEALTH = 22500,
		BEEQUEEN_DAMAGE = 120,

		KLAUS_HEALTH = 10000,
		KLAUS_DAMAGE = 75,

		STALKER_HEALTH = 4000,
		STALKER_DAMAGE = 200,
		
		ANTLION_HEALTH = 6000,
	}
},


--]]
name = "Classic Giant's Health"
forumthread = ""
author = "star"
version = "1.05"
version_compatible = "1.05"
description = "It restores classic parameters of giants.\nVersion: " .. version
	
api_version = 10
priority,c = -0.001,0
dont_starve_compatible = false
reign_of_giants_compatible = false
dst_compatible = true
all_clients_require_mod = false
client_only_mod = false
server_filter_tags,t = {"classic","giants","health"},{}

icon_atlas = "preview.xml"
icon = "preview.tex"

--Структура данных настроек.
--Первый номер - всегда название (без _HEALTH или _DAMAGE)
--Второй номер - всегда значение по умолчанию.
--Третий номер (для здоровья) - значение по умолчанию для DS. Используется как база для последних опций "х1.5" и т.д.
--
local classic = { --#2 - DST Default
		{"DEERCLOPS", 2000 * 2, 2000, 1500, 1200, 1000, 750, 500,}, -- harder for multiplayer
		{"DEERCLOPS", 150,120,100,80,50,30},		
		
		{"BEARGER", 3000 * 2, 3000, 2500, 2000, 1500, 1200, 1000, 750, 500,}, -- harder for multiplayer
		{"BEARGER", 200,150,120,100,80,50,30},

		{"DRAGONFLY", 27500, 2750, 2200, 1800, 1500, 1200, 1000, 800, 500, 300, 150,},
		{"DRAGONFLY", 150,120,100,80,50,30},

		{"MOOSE", 3000 * 2, 3000, 2500, 2000, 1500, 1200, 1000,500,}, -- harder for multiplayer
		{"MOOSE", 150,120,100,80,50,30},

		{"LAVAE", 500, 500, 400, 300, 200, 100,},
		{"LAVAE", 50,40,30,20},

		{"MOSSLING", 350 * 1.5, 350, 250, 150, 100,}, -- harder for multiplayer
		{"MOSSLING", 50,40,30,20},

		{"LEIF", 2000 * 1.5, 2000, 1500, 1000, 500, }, -- harder for multiplayer
		{"LEIF", 150,120,100,80,50,30},		
		
		{"SPIDERQUEEN", 1250 * 2, 1250, 1000, 900, 700, 500, },
		{"SPIDERQUEEN", 80,50,30,20},

		--New in 1.03:
		{"TOADSTOOL", 52500, 40000, 30000, 27500, 20000, 15000, 10000, 5000, 4000, 3000, 2000, 1000, 200000, 250000, 300000, 500000},
		{"TOADSTOOL", 100, 80, 60, 50, 40, 30, 20},
		{"WARG", 600 * 3, 600, 400, 200, 100, },
		{"WARG", 50, 40, 30, 20},
		{"KOALEFANT", 500 * 2, 500, 400, 300, },
		{"KOALEFANT", 50, 40, 30, 20},
		{"KNIGHT", 300 * 3, 300, 200, 100, },
		{"KNIGHT", 40, 30, 20},
		{"BISHOP", 300 * 3, 300, 200, 100, },
		{"BISHOP", 40, 30, 20},
		{"ROOK", 300 * 3, 300, 200, 100, },
		{"ROOKE", 45, 40, 30, 20},
		{"MINOTAUR", 2500 * 4, 2500, 2000, 1500, 1000, },
		{"MINOTAUR", 100, 80, 60, 50, 40, 30,},
		{"SPIDER_WARRIOR", 200 * 2, 200, 150, 100,},
		{"SPIDER_WARRIOR", 20, 10},
		
		--New in 1.04
		{"BEEQUEEN", 22500, 15000, 12000, 10000, 7500, 5000, 4000, 3000, 2000, 1000, },
		{"BEEQUEEN", 120, 100, 90, 80, 70, 60, 50, 40, 20, 10, 5, },
		--New in 1.05
		{"KLAUS", 10000, 8000, 5000, 4000, 3000, 2000, 1500, 1000, 500, },
		{"KLAUS", 75, 50, 40, 30, 20, 10, },
		{"STALKER", 4000, 3000, 2000, 1500, 1000, 500, },
		{"STALKER", 200, 150, 120, 100, 75, 50, 40, 20, },
		{"ANTLION", 6000, 5000, 4000, 3000, 2000, 1000, 500, },
		{"ANTLION", 0, } --no damage
}

local function inc(val,mul)
	return {description = (val*mul).." (x"..mul..")", data = (val*mul), hover = " "}
end

--не показывать "DS"
local exclude_DS_ver = {TOADSTOOL=1, BEEQUEEN=1, KLAUS=1, STALKER=1, ANTLION=1, }

--Создает опции для структуры v (строчка из classic)
--d==true означает, что это здоровье и надо добавить соответствующие комменты.
local function make(v,d)
	local t,n = {},3
	for i=2,#v do
		t[i] = {description = v[i]..(i==2 and " (DST)" or ""), data = v[i], hover = " "}
	end
	t[1] = {description = "Default DST", data = 0, hover = "Do not tweak this variable."}
	t[2].hover = "Default DST value."
	if d and exclude_DS_ver[v[1]] == nil then
		t[3].description = t[3].description .. " (DS)"
		t[3].hover = "Classic health value for Don't Starve."
		t[#v+1] = {description = "10 (Easy)", data = 10, hover = "Super easy!"}
		local ds = t[3].data
		t[#v+2] = inc(ds,1.5)
		t[#v+3] = inc(ds,2)
		t[#v+4] = inc(ds,3)
		t[#v+5] = inc(ds,4)
		t[#v+6] = inc(ds,5)
		local found
		for i=1,#t do
			if t[i].data <31000 and t[i].data > 24000 then
				found = true
				break
			end
		end
		if found == nil then
			t[#v+7] = {description = "27500", data = 27500, hover = "Trolling ;)"}
		end
	end
	--t.default = d and v[d] or 0
	return t
end


configuration_options=previous_configuration or old_config or t or {}
local function add(n,h) --добавляет classic[n] в опции
	local v = classic[n]
	if not v then return end
	c=c+1
	local name = v[1]:sub(1,1).. v[1]:sub(2):lower()
	h=n%2==1 --Нечетные номера означают здоровье, иначе урон.
	t[c]={
		name = v[1] .. "_".. (h and "HEALTH" or "DAMAGE"),
		label = name .. " ".. (h and "Health" or "Damage"),
		hover = (h and "Max health of " or "Damage of ")..name,
		options = make(v,h),
		default = h and n<8 and v[3] or 0,
	}
end

for i=1,#classic do
	--[=[ Реверсное добавление. Уже не нужно.
	local n = i%4
	if n==2 then
		add(i+1)
	elseif n==3 then
		add(i-1)
	else
		add(i)
	end
	--]=]
	add(i)
end


t[c+1] = {
	name = "dragonfly_restore",
	label = "Dragonfly restores HP",
	hover = "Dragonfly will restore health to maximum if no players to attack.\nThis is default behaviour by Klei.",
	options = {
		{description = "Yes", data = true, hover = "Default Klei value!"},
		{description = "No", data = false, hover = "Yes, it will be much easier."},
	},
	default = true,
}
t[c+2] = {
	name = "dragonfly_regen",
	label = "Dragonfly slow regen",
	hover = "Dragonfly will slowly regen health.",
	options = {
		{description = "No", data = 0, hover = "Default DST"},
		{description = "+20/min", data = 20},
		{description = "+30/min", data = 30},
		{description = "+45/min", data = 45},
		{description = "+1/sec", data = 60},
		{description = "+2/sec", data = 120},
		{description = "+3/sec", data = 180},
		{description = "+5/sec", data = 300},
		{description = "+10/sec", data = 600},
	},
	default = 0,
}
t[c+3] = {
	name = "dragonfly_speed",
	label = "Dragonfly speed mult",
	hover = "Note that Dragonfly has different values of speed\nfor each transform (normal and fire).",
	options = {
		{description = "75%", data = 0.75},
		{description = "80%", data = 0.80},
		{description = "85%", data = 0.85},
		{description = "90%", data = 0.90},
		{description = "95%", data = 0.95},
		{description = "100%", data = 1.0},
		{description = "105%", data = 1.05},
		{description = "110%", data = 1.1},
	},
	default = 1,
}
t[c+4] = {
	name = "lavae_speed",
	label = "Lavae speed mult",
	--hover = "Dragonfly will slowly regen health.",
	options = {
		{description = "75%", data = 0.75},
		{description = "80%", data = 0.80},
		{description = "85%", data = 0.85},
		{description = "90%", data = 0.90},
		{description = "95%", data = 0.95},
		{description = "100%", data = 1.0},
		{description = "105%", data = 1.05},
		{description = "110%", data = 1.1},
	},
	default = 1,
}






