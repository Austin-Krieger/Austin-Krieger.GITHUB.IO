-- Slower Sanity Drain
if GetModConfigData("SanityDrainRate") ~= "Off" then
GLOBAL.TUNING.SANITY_GHOST_PLAYER_DRAIN = 0
elseif GetModConfigData("SanityDrainRate") ~= "Easy" then
GLOBAL.TUNING.SANITY_GHOST_PLAYER_DRAIN = -0.01
elseif GetModConfigData("SanityDrainRate") ~= "Normal" then 
GLOBAL.TUNING.SANITY_GHOST_PLAYER_DRAIN = -0.05
elseif GetModConfigData("SanityDrainRate") ~= "Hard" then 
GLOBAL.TUNING.SANITY_GHOST_PLAYER_DRAIN = -0.15
end

if GetModConfigData("DaytimeSanityGain")=="Off" then
GLOBAL.TUNING.SANITY_DAY_GAIN = 0
elseif GetModConfigData("DaytimeSanityGain")=="On" then
GLOBAL.TUNING.SANITY_DAY_GAIN = 0.1
end

-- Chester 4 Everyone
TUNING.CHESTEREVERYONE = 
{
        CRAFT = GetModConfigData("Craft"),
        TECH = GetModConfigData("Science"),
        CHESTCOUNT = GetModConfigData("maxchesters"),
        EYEBONELEVEL = 2,
        OWNERSHIP = GetModConfigData("ownership")
}

modimport("customtechtree.lua")
AddNewTechType("EYEBONE")

GLOBAL.TECH.EYETECH = {}

GLOBAL.TECH.EYETECH.EYEBONE = TUNING.CHESTEREVERYONE.EYEBONELEVEL

if TUNING.CHESTEREVERYONE.TECH == 1 then
        GLOBAL.TECH.EYETECH.SCIENCE = 1
        AddTechHint(GLOBAL.TECH.EYETECH,"Use a science machine to build this!")
elseif TUNING.CHESTEREVERYONE.TECH == 2 then
        GLOBAL.TECH.EYETECH.SCIENCE = 2
        AddTechHint(GLOBAL.TECH.EYETECH,"Use a alchemy engine to build this!")
elseif TUNING.CHESTEREVERYONE.TECH == 3 then
        GLOBAL.TECH.EYETECH.MAGIC = 2
        AddTechHint(GLOBAL.TECH.EYETECH,"Use a prestihatitator to build this!")
elseif TUNING.CHESTEREVERYONE.TECH == 4 then
        GLOBAL.TECH.EYETECH.MAGIC = 3
        AddTechHint(GLOBAL.TECH.EYETECH,"Use a shadow manipulator to build this!")
end

--- CRAFTING RECIPES
GLOBAL.STRINGS.RECIPE_DESC.CHESTER_EYEBONE = "Get Your Very Own Chester!" 

if TUNING.CHESTEREVERYONE.CRAFT == 0 then
        AddRecipe("chester_eyebone", {Ingredient("twigs", 2),Ingredient("rope", 1),Ingredient("goldnugget", 2)}, GLOBAL.RECIPETABS.TOOLS, GLOBAL.TECH.EYETECH, nil, nil, true)
elseif TUNING.CHESTEREVERYONE.CRAFT == 1 then
        AddRecipe("chester_eyebone", {Ingredient("livinglog", 1),Ingredient("rope", 1),Ingredient("goldnugget", 1),Ingredient("nightmarefuel", 1)}, GLOBAL.RECIPETABS.TOOLS, GLOBAL.TECH.EYETECH, nil, nil, true)
elseif TUNING.CHESTEREVERYONE.CRAFT == 2 then
        AddRecipe("chester_eyebone", {Ingredient("livinglog", 2),Ingredient("rope", 1),Ingredient("gears", 2),Ingredient("nightmarefuel", 2)}, GLOBAL.RECIPETABS.TOOLS, GLOBAL.TECH.EYETECH, nil, nil, true)
elseif TUNING.CHESTEREVERYONE.CRAFT == 3 then
        AddRecipe("chester_eyebone", {Ingredient("livinglog", 1),Ingredient("rope", 1),Ingredient("deerclops_eyeball", 1),Ingredient("nightmarefuel", 1)}, GLOBAL.RECIPETABS.TOOLS, GLOBAL.TECH.EYETECH, nil, nil, true)
end

local function GetSpawnPoint(pt)
        local theta = math.random() * 2 * GLOBAL.PI
        local radius = 4
        local offset = GLOBAL.FindWalkableOffset(pt, theta, radius, 12, true)
        return offset ~= nil and (pt + offset) or nil
end

local function ChesterEveryone(inst)
        if not GLOBAL.TheWorld.ismastersim then
                return
        end

        --OnDespawn
        local OnDespawn_prev = inst.OnDespawn
        inst.OnDespawn = function(inst)
                if not GLOBAL.TheWorld:HasTag("cave") then
                        if inst.CHESTEREVERYONE.chester and #inst.CHESTEREVERYONE.chester > 0 then
                                for i, v in ipairs(inst.CHESTEREVERYONE.chester) do
                                        -- Don't allow chester to despawn with irreplaceable items
                                        inst.CHESTEREVERYONE.chester[i].components.container:DropEverythingWithTag("irreplaceable")
                                
                                        -- We need time to save before despawning.
                                        inst.CHESTEREVERYONE.chester[i]:DoTaskInTime(0.1, function(chester)
                                                if chester and chester:IsValid() then
                                                        chester:Remove()
                                                end
                                        end)
                                end
                        end

                        if inst.CHESTEREVERYONE.eyebone and #inst.CHESTEREVERYONE.eyebone > 0 then
                                for i, v in ipairs(inst.CHESTEREVERYONE.eyebone) do
                                        -- Eyebone drops from whatever its in
                                        local owner = inst.CHESTEREVERYONE.eyebone[i].components.inventoryitem.owner
                                        if owner then
                                                --drop items from containers/inv's
                                                if owner.components.container then
                                                        owner.components.container:DropItem(inst.CHESTEREVERYONE.eyebone[i])
                                                elseif owner.components.inventory then
                                                        owner.components.inventory:DropItem(inst.CHESTEREVERYONE.eyebone[i])
                                                end
                                        end
                                        -- Remove eyebone
                                        inst.CHESTEREVERYONE.eyebone[i]:DoTaskInTime(0.1, function(eyebone)
                                                if eyebone and eyebone:IsValid() then
                                                        eyebone:Remove()
                                                end
                                        end)
                                end
                        end
                end
                return OnDespawn_prev(inst)
        end
        
        --OnSave
        local OnSave_prev = inst.OnSave
        inst.OnSave = function(inst, data)
                local references = OnSave_prev(inst, data)
                if GLOBAL.TheWorld:HasTag("cave") then
                        --pass through the data but dont do anything else
                        data.CHESTEREVERYONE = inst.CHESTEREVERYONE or {}
                else
                        data.CHESTEREVERYONE = {}
                        data.CHESTEREVERYONE.eyebone = {}
                        data.CHESTEREVERYONE.eyebonerefs = {}
                        data.CHESTEREVERYONE.chester = {}
                        data.CHESTEREVERYONE.chesterrefs = {}

                        if inst.CHESTEREVERYONE.chester and #inst.CHESTEREVERYONE.chester > 0 then
                                for i, v in ipairs(inst.CHESTEREVERYONE.chester) do
                                        -- Save chester
                                        data.CHESTEREVERYONE.chester[i], data.CHESTEREVERYONE.chesterrefs[i] = inst.CHESTEREVERYONE.chester[i]:GetSaveRecord()          
                                end     
                        end

                        if inst.CHESTEREVERYONE.eyebone and #inst.CHESTEREVERYONE.eyebone > 0 then
                                for i, v in ipairs(inst.CHESTEREVERYONE.eyebone) do
                                        -- Save eyebone
                                        data.CHESTEREVERYONE.eyebone[i], data.CHESTEREVERYONE.eyebonerefs[i] = inst.CHESTEREVERYONE.eyebone[i]:GetSaveRecord()
                                end
                        end

                end

                return references
        end
        
        --OnLoad
        local OnLoad_prev = inst.OnLoad
        inst.OnLoad = function(inst, data, newents)
                if GLOBAL.TheWorld:HasTag("cave") then
                        --pass through the data but dont spawn the eyebone's or chester's
                        inst.CHESTEREVERYONE = data.CHESTEREVERYONE or {}
                        --also VERY important dont allow the player to craft eyebones down there as they would disapear on travel to the surface
                        inst.components.builder.eyebone_bonus = 0
                else
                        inst.CHESTEREVERYONE = {}
                        inst.CHESTEREVERYONE.eyebone = {}
                        inst.CHESTEREVERYONE.chester = {}
                        if data.CHESTEREVERYONE then
                                if data.CHESTEREVERYONE.chester ~= nil and #data.CHESTEREVERYONE.chester > 0 then
                                        for i, v in ipairs(data.CHESTEREVERYONE.chester) do
                                                -- Load chester
                                                inst.CHESTEREVERYONE.chester[i] = GLOBAL.SpawnSaveRecord(data.CHESTEREVERYONE.chester[i], data.CHESTEREVERYONE.chesterrefs[i])
                                                inst.CHESTEREVERYONE.chester[i]:AddTag("claimed_chester")
                                                inst.CHESTEREVERYONE.chester[i].persists = false
                                        end
                                end

                                if data.CHESTEREVERYONE.eyebone ~= nil and #data.CHESTEREVERYONE.eyebone > 0 then
                                        for i, v in ipairs(data.CHESTEREVERYONE.eyebone) do
                                                -- Load chester
                                                inst.CHESTEREVERYONE.eyebone[i] = GLOBAL.SpawnSaveRecord(data.CHESTEREVERYONE.eyebone[i], data.CHESTEREVERYONE.eyebonerefs[i])
                                                inst.CHESTEREVERYONE.eyebone[i].CHESTEREVERYONE.owner = inst
                                                inst.CHESTEREVERYONE.eyebone[i].CHESTEREVERYONE.eyenum = i
                                                inst.CHESTEREVERYONE.eyebone[i].persists = false
                                                inst.CHESTEREVERYONE.eyebone[i].ownership = ownership
                                
                                                -- Look for eyebone at spawn point and re-equip
                                                inst:DoTaskInTime(0, function(inst,i)
                                                        if inst.CHESTEREVERYONE.eyebone[i] and inst:IsNear(inst.CHESTEREVERYONE.eyebone[i],4) then
                                                                --inst.components.inventory:GiveItem(inst.eyebone)
                                                                inst:ReturnEyebone(i)
                                                        end
                                                end, i)
                                        end
                                end
                        end

                        if (#inst.CHESTEREVERYONE.eyebone or 0) < TUNING.CHESTEREVERYONE.CHESTCOUNT then
                                inst.components.builder.eyebone_bonus = TUNING.CHESTEREVERYONE.EYEBONELEVEL
                        end
                end
                return OnLoad_prev(inst, data, newents)
        end
        --OnNewSpawn
        local OnNewSpawn_prev = inst.OnNewSpawn
        inst.OnNewSpawn = function(inst)
                inst.CHESTEREVERYONE = {}
                inst.CHESTEREVERYONE.eyebone = {}
                inst.CHESTEREVERYONE.chester = {}
                inst.components.builder.eyebone_bonus = TUNING.CHESTEREVERYONE.EYEBONELEVEL
                if OnNewSpawn_prev then
                        return OnNewSpawn_prev(inst)
                end
        end
        
        if GLOBAL.TheNet:GetServerGameMode() == "wilderness" then
                local function ondeath(inst, data)
                        -- Kill player's chester in wilderness mode :(
                        for i, v in ipairs(inst.CHESTEREVERYONE.chester) do
                                if inst.CHESTEREVERYONE.chester[i] then
                                        inst.CHESTEREVERYONE.chester[i].components.health:Kill()
                                end
                        end
                        for i, v in ipairs(inst.CHESTEREVERYONE.eyebone) do
                                if inst.CHESTEREVERYONE.eyebone[i] then
                                        inst.CHESTEREVERYONE.eyebone[i]:Remove()
                                end
                        end
                end
                inst:ListenForEvent("death", ondeath)
        end

        inst.ReturnEyebone = function(inst,i)
                if inst.CHESTEREVERYONE.eyebone[i] and inst.CHESTEREVERYONE.eyebone[i]:IsValid() then
                        if inst.CHESTEREVERYONE.eyebone[i].components.inventoryitem.owner ~= inst then
                                inst.components.inventory:GiveItem(inst.CHESTEREVERYONE.eyebone[i])
                        end
                end
                if inst.CHESTEREVERYONE.chester[i] and not inst:IsNear(inst.CHESTEREVERYONE.chester[i], 20) then
                        local pt = inst:GetPosition()
                        local spawn_pt = GetSpawnPoint(pt)
                        if spawn_pt ~= nil then
                                inst.CHESTEREVERYONE.chester[i].Physics:Teleport(spawn_pt:Get())
                                inst.CHESTEREVERYONE.chester[i]:FacePoint(pt:Get())
                        end
                end
        end
end


GLOBAL.c_returneyebone = function(inst,i)
        if not inst then
                inst = GLOBAL.ThePlayer or GLOBAL.AllPlayers[1]
        end
        if not inst or not inst.ReturnEyebone then 
                print("Error: Cannot return eyebone")
                return 
        end
        inst:ReturnEyebone(inst,i)
end

AddPlayerPostInit(ChesterEveryone)

local function Chester(inst)
    inst:AddTag("_named")

        if not GLOBAL.TheWorld.ismastersim then
                return
        end
        inst.components.inspectable.nameoverride = "chester"
        inst:AddComponent("named")
end

AddPrefabPostInit("chester",Chester)

local function ChesterEyebone(inst)
        local SPAWN_DIST = 30

        local function OpenEye(inst)
            if not inst.isOpenEye then
                inst.isOpenEye = true
                inst.components.inventoryitem:ChangeImageName(inst.openEye)
                inst.AnimState:PlayAnimation("idle_loop", true)
            end
        end

        local function CloseEye(inst)
            if inst.isOpenEye then
                inst.isOpenEye = nil
                inst.components.inventoryitem:ChangeImageName(inst.closedEye)
                inst.AnimState:PlayAnimation("dead", true)
            end
        end

        local function GetSpawnPoint(pt)
            local theta = math.random() * 2 * GLOBAL.PI
            local radius = SPAWN_DIST
            local offset = GLOBAL.FindWalkableOffset(pt, theta, radius, 12, true)
            return offset ~= nil and (pt + offset) or nil
        end

        local function SpawnChester(inst)
            if not inst.CHESTEREVERYONE.owner then
                print("Error: Eyebone has no linked player!")
                return
            end
            local pt = inst:GetPosition()
            local spawn_pt = GetSpawnPoint(pt)
            if spawn_pt ~= nil then
                --print("    at", spawn_pt)
                local chester = GLOBAL.SpawnPrefab("chester")
                if chester ~= nil then
                    chester.Physics:Teleport(spawn_pt:Get())
                    chester:FacePoint(pt:Get())
                    if inst.CHESTEREVERYONE.owner and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester then
                        inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester[inst.CHESTEREVERYONE.eyenum] = chester
                    end
                    return chester
                end
            end
        end

        local StartRespawn

        local function StopRespawn(inst)
            if inst.respawntask ~= nil then
                inst.respawntask:Cancel()
                inst.respawntask = nil
                inst.respawntime = nil
            end
        end

        local function RebindChester(inst,chester)
            chester = chester or (inst.CHESTEREVERYONE.owner and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester[inst.CHESTEREVERYONE.eyenum])
            chester = chester or GLOBAL.FindEntity(inst,16,nil,{"chester"},{"claimed_chester"},nil)
            if chester ~= nil then
                if inst.CHESTEREVERYONE.owner then
                    chester.components.named:SetName(inst.CHESTEREVERYONE.owner.name.."'s Chester")
                    chester:AddTag("claimed_chester")
                    chester.persists = false
                    if inst.CHESTEREVERYONE.ownership then
                        chester:AddTag(ownershiptag)
                        chester:AddTag("uid_" .. inst.CHESTEREVERYONE.owner.userid)
                    end
                end
                OpenEye(inst)
                inst:ListenForEvent("death", function()
                    if inst.CHESTEREVERYONE.owner and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester then
                        inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester[inst.CHESTEREVERYONE.eyenum] = nil
                    end 
                    StartRespawn(inst, TUNING.CHESTER_RESPAWN_TIME) 
                end, chester)

                if chester.components.follower.leader ~= inst then
                    chester.components.follower:SetLeader(inst)
                end
                return true
            end
        end

        local function RespawnChester(inst)
            StopRespawn(inst)
            RebindChester(inst, 
                (inst.CHESTEREVERYONE.owner and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester and inst.CHESTEREVERYONE.owner.CHESTEREVERYONE.chester[inst.CHESTEREVERYONE.eyenum]) 
                or GLOBAL.FindEntity(inst,16,nil,{"chester"},{"claimed_chester"},nil)
                or SpawnChester(inst))
        end

        StartRespawn = function(inst, time)
            StopRespawn(inst)

            time = time or 0
            inst.respawntask = inst:DoTaskInTime(time, RespawnChester)
            inst.respawntime = GLOBAL.GetTime() + time
            CloseEye(inst)
        end

        local function FixChester(inst)
            inst.fixtask = nil
            if not RebindChester(inst) then
                CloseEye(inst)
                
                if inst.components.inventoryitem.owner ~= nil then
                    local time_remaining = inst.respawntime ~= nil and math.max(0, inst.respawntime - GLOBAL.GetTime()) or 0
                    StartRespawn(inst, time_remaining)
                end
            end
        end

        local function OnPutInInventory(inst)
                if not GLOBAL.TheWorld:HasTag("cave") then
                        local owner = inst.components.inventoryitem:GetGrandOwner()
                        if owner ~= nil and owner:HasTag("player") then
                                if inst.CHESTEREVERYONE.owner == nil then
                                        if (#owner.CHESTEREVERYONE.eyebone or 0) < TUNING.CHESTEREVERYONE.CHESTCOUNT then
                                                owner.CHESTEREVERYONE.eyebone[#owner.CHESTEREVERYONE.eyebone + 1] = inst
                                                inst.CHESTEREVERYONE.owner = owner
                                                inst.CHESTEREVERYONE.eyenum = #owner.CHESTEREVERYONE.eyebone
                                                inst.persists = false
                                                inst.components.named:SetName(owner.name.."'s Eye Bone")
                                                inst.ownership = ownership
                                        else 
                                                inst:DoTaskInTime(0, function(inst, owner)
                                                        if owner.components.inventory ~= nil then
                                                                owner.components.inventory:DropItem(inst, true, true)
                                                        end
                                                end, owner)
                                                if owner.components.talker then
                                                        owner.components.talker:Say("I can't do that.")
                                                end
                                        end
                                end
                                if (#owner.CHESTEREVERYONE.eyebone or 0) >= TUNING.CHESTEREVERYONE.CHESTCOUNT and owner.components.builder then
                                        owner.components.builder.eyebone_bonus = 0
                                end
                        end
                end
            if inst.fixtask == nil then
                inst.fixtask = inst:DoTaskInTime(1, FixChester)
            end
        end
    inst:AddTag("_named")

    if not GLOBAL.TheWorld.ismastersim then
        return
    end

    inst.fixtask.fn = FixChester
    inst.components.inventoryitem:SetOnPutInInventoryFn(OnPutInInventory)
    inst.components.inspectable.nameoverride = "chester_eyebone"
    inst:AddComponent("named")
    inst.CHESTEREVERYONE = {}
end
AddPrefabPostInit("chester_eyebone",ChesterEyebone)

-- Craftable Gears
local Recipetabs = GLOBAL.RECIPETABS
local Ingredient = GLOBAL.Ingredient
local Strings = GLOBAL.STRINGS

Strings.RECIPE_DESC.GEARS = "A useful collection of mechanical...stuff."

local science = GetModConfigData("GearScienceRequired")

local materials = {
        { name = "Log", material = "log" },
        { name = "Cut Stone", material = "cutstone" },
        { name = "Gold Nugget", material = "goldnugget" },
        { name = "Purple Gem", material = "purplegem" },
        { name = "Red Gem", material = "redgem" },
        { name = "Blue Gem", material = "bluegem" },
}
local formula = { }
local fsize = 0

for i = 1, #materials do
        local name = materials[i]["name"]
        local material = materials[i]["material"]
        local count = GetModConfigData(name)
        if count > 0 then
                fsize = fsize + 1
                formula[fsize] = Ingredient(material, count)
        end
end

AddRecipe(
        "gears", formula, Recipetabs.REFINE,
        { SCIENCE = science, MAGIC = 0, ANCIENT = 0 },
        nil, nil, nil, nil, nil, nil
)
-- Increase Equipment Stack Size
local MaxStack = GetModConfigData("StackSize")
local DropWholeStack = GetModConfigData("DropWholeStack")
local DST = GLOBAL.TheSim:GetGameID() == "DST"

local function CanDropAll(act)
    if act.invobject ~= nil and act.invobject:HasTag("trap") then
        if DST then
            if act.invobject:HasTag("dropall") then
                return true
            end
        else
            if GLOBAL.TheInput:IsControlPressed(GLOBAL.CONTROL_FORCE_STACK) then
                return true
            end
        end
    end
    return false
end

GLOBAL.STRINGS.ACTIONS.DROP.DROPALL = "Drop All"

local oldactiondrop = GLOBAL.ACTIONS.DROP.fn
GLOBAL.ACTIONS.DROP.fn = function(act)
    if CanDropAll(act) then
        if act.invobject:HasTag("dropall") then                       
            act.invobject:RemoveTag("dropall")
        end 
        return act.doer.components.inventory ~= nil and act.doer.components.inventory:DropItem(act.invobject,true,false,act.pos) or nil    
    end
    return oldactiondrop(act)
end 

local oldactiondropstr = GLOBAL.ACTIONS.DROP.strfn
GLOBAL.ACTIONS.DROP.strfn = function(act)
    if CanDropAll(act) then
        return "DROPALL"
    end 
    return oldactiondropstr(act)
end

if DST then
    local function dropall(inst, doer, pos, actions, right)
        if inst:HasTag("trap") and not right and inst.replica.inventoryitem:IsHeldBy(doer) then
            if doer.components.playercontroller ~= nil then
                if doer.components.playercontroller:IsControlPressed(GLOBAL.CONTROL_FORCE_STACK) then
                    if not inst:HasTag("dropall") then
                        inst:AddTag("dropall")
                    end 
                else
                    if inst:HasTag("dropall") then
                        inst:RemoveTag("dropall")
                    end
                end
            end
            table.insert(actions, GLOBAL.ACTIONS.DROP)
        end
    end
    AddComponentAction("POINT", "inventoryitem", dropall)
end 

local function DecreaseSizeByOne(inst)
    local size = inst.components.stackable:StackSize() - 1
    inst.components.stackable:SetStackSize(size)    
end

local function CaseOne(inst, components1, components2)
    local percent = components1:GetPercent() + components2:GetPercent()
    if percent > 1 then
        percent = percent - 1
    else
        DecreaseSizeByOne(inst)
    end
    components1:SetPercent(percent)
end

local function CaseTwo(item, components1, components2)
    local sourceper = components1:GetPercent()
    if sourceper < 1 then
        local itemper = components2:GetPercent()
        local percentleft = 1 - sourceper
        if itemper > percentleft then
            local percent = itemper - percentleft
            components2:SetPercent(percent)
            components1:SetPercent(1)
        else
            if item.components.stackable:StackSize() > 1 then
                components1:SetPercent(1)
                local percent = 1 - (percentleft - itemper)
                components2:SetPercent(percent)
                DecreaseSizeByOne(item)
            else
                local percent = sourceper + itemper
                components1:SetPercent(percent)
                item:Remove()
                return true
            end
        end
        if components2:GetPercent() < 0.01 then
            item:Remove()
            return true
        end
    end
    return false
end

local function newstackable(self)
    local _Put = self.Put
    self.Put = function(self, item, source_pos)
        if item.prefab == self.inst.prefab then
            local instper, itemper
            local newtotal = item.components.stackable:StackSize() + self.inst.components.stackable:StackSize()
            if item.components.finiteuses ~= nil then
                instper = self.inst.components.finiteuses
                itemper = item.components.finiteuses
            elseif item.components.fueled ~= nil then
                instper = self.inst.components.fueled
                itemper = item.components.fueled
            elseif item.components.armor ~= nil then
                instper = self.inst.components.armor
                itemper = item.components.armor
            end
            
            if instper ~= nil and itemper ~= nil then
                if newtotal <= self.inst.components.stackable.maxsize then
                    CaseOne(self.inst, instper, itemper)
                else                        
                    if CaseTwo(item, instper, itemper) then
                        return nil
                    end
                end
            end
            
        end
        return _Put(self, item, source_pos)
    end
end

AddComponentPostInit("stackable", newstackable)

if DropWholeStack then

    local function newdropitem(self)
        local _DropItem = self.DropItem
        self.DropItem = function(self, item, wholestack, randomdir, pos)
            if item == nil or item.components.inventoryitem == nil then
                return
            end
            if item.components.stackable ~= nil and item.components.equippable ~= nil and item.components.equippable.equipstack
                    and not item:HasTag("projectile") then
                wholestack = true
            end
            return _DropItem(self, item, wholestack, randomdir, pos)
        end
    end

    AddComponentPostInit("inventory", newdropitem)
end

local function newarmor(self)
    local _SetCondition = self.SetCondition
    self.SetCondition = function(self, amount)
        local armorhp = math.min(amount, self.maxcondition)
        if armorhp <= 0 then
            if self.inst.components.stackable ~= nil and self.inst.components.stackable:StackSize() > 1 then
                DecreaseSizeByOne(self.inst)
                amount = self.maxcondition
            end 
        end
        _SetCondition(self, amount)
    end
end

AddComponentPostInit("armor", newarmor)

local function onfinish(inst)
    DecreaseSizeByOne(inst)
    if inst.components.finiteuses ~= nil then
        inst.components.finiteuses:SetPercent(1)
    elseif inst.components.fueled ~= nil then
        inst.components.fueled:SetPercent(1)
    end         
end

local function newsectionfn(_sectionfn, newsection, oldsection, inst, dlc)
    if newsection == 0 then
        if inst.components.stackable:StackSize() > 1 then
            onfinish(inst)
        else
            if dlc then
                _sectionfn(newsection, oldsection, inst)
            else
                _sectionfn(newsection, oldsection)
            end
        end 
    end 
end

if not DST or (DST and GLOBAL.TheNet:GetIsServer()) then

    local function addstackable(inst)
    
        if inst.components.inventoryitem == nil then
            return
        end 
    
        if inst.components.equippable == nil then
            if not inst:HasTag("trap") and not inst:HasTag("mine") and inst.components.instrument == nil and
                        inst.components.sewing == nil and inst.components.fertilizer == nil then
                return
            end 
        end 
    
        if inst.components.container ~= nil then
            return
        end
    
        if inst.components.stackable ~= nil then
            return
        end
        
        if inst.components.fueled ~= nil and inst.components.fueled.accepting and inst.components.fueled.ontakefuelfn ~= nil then
            return
        end
        
        inst:AddComponent("stackable")
        inst.components.stackable.maxsize = MaxStack
        if inst:HasTag("trap") then
            inst.components.stackable.forcedropsingle = true
        end
        if inst.components.projectile == nil or (inst.components.projectile ~= nil and not inst.components.projectile.cancatch) then
            if inst.components.throwable == nil then
                if inst.components.equippable ~= nil then
                    inst.components.equippable.equipstack = true
                end 
            end 
        end
            
        if inst.components.finiteuses == nil then
            if inst.components.fueled == nil then
                return
            end     
        end
            
        if inst.components.finiteuses ~= nil then
            local _onfinished = inst.components.finiteuses.onfinished and inst.components.finiteuses.onfinished or nil
            if _onfinished ~= nil then
                inst.components.finiteuses.onfinished = function (inst)         
                    if inst.components.stackable:StackSize() > 1 then
                        onfinish(inst)
                    else
                        _onfinished(inst)
                    end 
                end
            end
        elseif inst.components.fueled ~= nil then
            local _sectionfn = inst.components.fueled.sectionfn and inst.components.fueled.sectionfn or nil
            if _sectionfn ~= nil then
                if DST or (not DST and (GLOBAL.IsDLCEnabled(GLOBAL.REIGN_OF_GIANTS) or GLOBAL.IsDLCEnabled(GLOBAL.CAPY_DLC))) then
                    inst.components.fueled.sectionfn = function (newsection, oldsection, inst)
                        newsectionfn(_sectionfn, newsection, oldsection, inst, true)
                    end
                else
                    inst.components.fueled.sectionfn = function (newsection, oldsection)
                        newsectionfn(_sectionfn, newsection, oldsection, inst, false)
                    end
                end 
            else
                local _depleted = inst.components.fueled.depleted and inst.components.fueled.depleted or nil
                if _depleted ~= nil then
                    inst.components.fueled.depleted = function (inst)   
                        if inst.components.stackable:StackSize() > 1 then
                            onfinish(inst)
                        else
                            _depleted(inst)
                        end 
                    end
                end 
            end 
        end
    end
    AddPrefabPostInitAny(addstackable)
end