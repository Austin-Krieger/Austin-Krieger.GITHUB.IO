name = "Mod Pack II"
description = "Multiple Mods Part II"
author = "ownsaucepimp"
version = "1.0.0"
forumthread = ""
api_version = 10
dst_compatible = true
dont_starve_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
    -- Slower Sanity Drain
    {
        name = "SanityDrainRate", 
        label = "Ghost Sanity Drain",
        options = {
                {description = "Off", data = "Off"},
                {description = "Easy", data = "Easy"},
                {description = "Normal", data = "Normal"},
                {description = "Hard", data = "Hard"},
            },
        default = "Easy",
    },
    {
        name = "DaytimeSanityGain",
        label = "Daytime Sanity Gain",
        options = {
                {description = "On", data = "On"},
                {description = "Off", data = "Off"},
            },
        default = "Off",
    },
    -- Chester 4 Everyone
    {
        name = "Craft",
        label = "Crafting Difficulty",
        hover = "The Difficulty of Crafting Chesters.",
        options =
        {
            {description = "Easy", data = 0, hover = "2 Twigs, 1 Rope, 2 Gold."},
            {description = "Medium", data = 1, hover = "1 Living Log, 1 Rope, 1 Gold, 1 Nightmare Fuel."},
            {description = "Hard", data = 2, hover = "2 Living Log, 1 Rope, 2 Gears, 2 Nightmare Fuel."},
            {description = "Hardcore", data = 3, hover = "1 Living Log, 1 Rope, 1 Deerclops Eyeball, 1 Nightmare Fuel."},
        },
        default = 0
    },
    {
        name = "Science",
        label = "Machine Required",
        hover = "What Tech Level do you need to craft Chesters?",
        options =
        {
            {description = "None", data = 0, hover = "Requires: Nothing!"},
            {description = "Tech 1", data = 1, hover = "Requires: Science Machine!"},
            {description = "Tech 2", data = 2, hover = "Requires: Alchemy Engine!"},
            {description = "Magic 1", data = 3, hover = "Requires: Prestihatitator!"},
            {description = "Magic 2", data = 4, hover = "Requires: Shadow Manipulator!"},
        },
        default = 0,
    },
    {
        name = "maxchesters",
        label = "Max Chesters",
        hover = "Max Chester's Per Player?",
        options =
        {
            {description = "1", data = 1},
            {description = "2", data = 2},
            {description = "3", data = 3},
            {description = "4", data = 4},
            {description = "5", data = 5},
            {description = "6", data = 6},
            {description = "7", data = 7},
            {description = "8", data = 8},
            {description = "9", data = 9},
            {description = "10", data = 10},
        },
        default = 4,
    },
    {
        name = "Ownership",
        label = "Ownership Restriction?",
        options =
        {
            {description = "Enable", data = true},
            {description = "Disable", data = false}
        },
        default = false,
    },
    -- Craftable Gears
    {
        name = "GearScienceRequired",
        label = "Gear Science Required",
        options = {
            { description = "Science Machine", data = 1, hover = "Science Machine" },
            { description = "Alchemy Engine", data = 2, hover = "Alchemy Engine" },
        },
        default = 2
    },
    {
        name = "Log",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 0
    },
    {
        name = "Cut Stone",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 4
    },
    {
        name = "Gold Nugget",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 6
    },
    {
        name = "Purple Gem",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 1
    },
    {
        name = "Red Gem",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 0
    },
    {
        name = "Blue Gem",
        options = {
            { description = "0", data = 0, },
            { description = "1", data = 1, },
            { description = "2", data = 2, },
            { description = "3", data = 3, },
            { description = "4", data = 4, },
            { description = "5", data = 5, },
            { description = "6", data = 6, },
            { description = "7", data = 7, },
            { description = "8", data = 8, },
            { description = "9", data = 9, },
        },
        default = 0
    },
    -- Increase Equipment Stack Size
    {
        name = "StackSize",
        label = "Max stack size",
        hover = "Choose max stack size for your equipments.",
        options =   
        {
            {description = "5", data = 5},
            {description = "10", data = 10},
            {description = "15", data = 15},
            {description = "20", data = 20},
            {description = "25", data = 25},
            {description = "30", data = 30},
            {description = "35", data = 35},
            {description = "40", data = 40},
        },
        default = 10,
    },
    {
        name = "DropWholeStack",
        label = "Drop whole stack",
        hover = "Items are slippery it will drop whole stack.",
        options =   
        {
            {description = "Yes", data = true},
            {description = "No", data = false},
        },
        default = true,
    },
}