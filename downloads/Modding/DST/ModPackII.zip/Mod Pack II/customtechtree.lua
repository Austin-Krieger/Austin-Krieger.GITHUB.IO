--this means the method hooks get proccessed once
if GLOBAL.rawget(GLOBAL,"AddNewTechType") and GLOBAL.rawget(GLOBAL,"AddTechHint") and GLOBAL.rawget(GLOBAL,"AddPrototyperTree") then
    AddNewTechType = GLOBAL.AddNewTechType
    AddTechHint = GLOBAL.AddTechHint
    AddPrototyperTree = GLOBAL.AddPrototyperTree
    return
end
 
 
--keep a separate list of all the custom techs for use with techname_bonus
--more effecient than itterating through all the techs... just go through the custom ones...
local CUSTOM_TECH_BONUS = {}
local CUSTOM_TECH_KEY = {}
local CUSTOM_TECH_HINT = {}
 
local TechTree = GLOBAL.require("techtree")
 
function AddNewTechType(techtype)
    --add tech to all tech list
    TechTree.AVAILABLE_TECH[#TechTree.AVAILABLE_TECH + 1] = techtype
    --add to this list for custom bonus proccessing
    CUSTOM_TECH_BONUS[#CUSTOM_TECH_BONUS + 1] = techtype
    --set global.tech.none.techtype to 0 to prevent crashes
    GLOBAL.TECH.NONE[techtype] = 0
    --add our new techtype to all existing recipes as 0 or if its already there then we leave it as it should be
    --we only need to do this once as all recipes from here on out will have it at 0 or provided value
    for k, v in pairs(GLOBAL.AllRecipes) do
        v.level[techtype] = (v.level[techtype] or 0)
    end
    --add our new techtype to all existing prototyping machines as 0 or if its already there then we leave it as it should be
    --we only need to do this once as all future proto trees will have it at 0 or provided value
    for k, v in pairs(TUNING.PROTOTYPER_TREES) do
        v[techtype] = (v[techtype] or 0)
    end
end
 
function AddTechHint(Tech,NewHint)
    --adding the tech that you want to one list and the hint to the next
    CUSTOM_TECH_KEY[#CUSTOM_TECH_KEY + 1] = Tech
    CUSTOM_TECH_HINT[#CUSTOM_TECH_HINT + 1] = NewHint
end
 
function AddPrototyperTree(TreeName,Tech)
    --adds a prototyper tree to TUNING.PROTOTYPER_TREES how it should be done
    --note: this is only for what the prototyper machine should output
    --creating a tech for recipes can be done by doing: GLOBAL.TECH.TECHNAME = {TECHTYPE = 1, OTHERTECHTYPE = 3}
    TUNING.PROTOTYPER_TREES[TreeName] = TechTree.Create(Tech)
end
 
--cant edit the replica with AddComponentPostInit
local function BuilderReplicaTech(replica)
    if not GLOBAL.TheWorld.ismastersim then return end
    local Old_SetTechTrees = replica.SetTechTrees
    function replica:SetTechTrees(techlevels)
        --we have to deal with custom bonus's in here as we dont have a good place to put custom code in Builder:EvaluateTechTrees
        --its passed by reference so its perfectly fine to do it here
        if self.inst.components.builder ~= nil and self.inst.components.builder.current_prototyper ~= nil then
            --it handles our bonus correctly if it doesnt have a prototyper machine found...
            local techChanged = false
            for i, v in ipairs(CUSTOM_TECH_BONUS) do
                local currentTech = techlevels[v] or 0
                techlevels[v] = (techlevels[v] or 0) + (self.inst.components.builder[string.lower(v).."_bonus"] or 0)
                if currentTech ~= techlevels[v] then
                    techChanged = true
                end
            end
            --if we change the tech tree reupdate any dependencies by calling this again
            --this isnt ideal but this is still the best way currently
            if techChanged then
                self.inst:PushEvent("techtreechange", { level = self.accessible_tech_trees })
            end
        end
        Old_SetTechTrees(self,techlevels)
    end
end
 
local function CompareTech(recipetech,createdtech)
    --comparine two tech trees
    for i, v in ipairs(TechTree.AVAILABLE_TECH) do
        if (recipetech[v] or 0) == (createdtech[v] or 0) then
            return false
        end
    end
    return true
end
 
local function RecipeHint(recipepopup)
    if not GLOBAL.TheWorld.ismastersim then return end
    local recipe_hint = nil
 
    local Old_setMultilineTruncatedString = recipepopup.teaser.SetMultilineTruncatedString
    function recipepopup.teaser:SetMultilineTruncatedString(str, maxlines, maxwidth, maxcharsperline, ellipses)
        --only do stuff if the str is the CANTRESEARCH text and also make sure recipe_hint isnt nil
        if str == GLOBAL.STRINGS.UI.CRAFTING.CANTRESEARCH and recipe_hint ~= nil then
            for i, v in ipairs(CUSTOM_TECH_KEY) do
                --compare each custom tech to the recipe's tech if it matches exactly then its the same tech and can have a custom hint
                if CompareTech(recipe_hint.level,v) then
                    --set str as custom hint
                    str = CUSTOM_TECH_HINT[i]
                    break
                end
            end
        end
        Old_setMultilineTruncatedString(self, str, maxlines, maxwidth, maxcharsperline, ellipses)
    end
 
    local Old_Refresh = recipepopup.Refresh
    function recipepopup:Refresh()
        --get the recipe so i can compare tech level
        recipe_hint = self.recipe
        Old_Refresh(self)
        recipe_hint = nil
    end
end
 
local function PlayerClassifiedTech(inst)
    for i, v in ipairs(CUSTOM_TECH_BONUS) do
        inst[string.lower(v) .. "bonus"] = GLOBAL.net_tinybyte(inst.GUID, "builder." .. string.lower(v) .. "_bonus")
    end
end
 
local function DoMethodHooks()
    AddClassPostConstruct("widgets/recipepopup", RecipeHint)
    AddClassPostConstruct("components/builder_replica",BuilderReplicaTech)
    AddPrefabPostInit("player_classified",PlayerClassifiedTech)
end
 
GLOBAL.AddNewTechType = AddNewTechType
GLOBAL.AddTechHint = AddTechHint
GLOBAL.AddPrototyperTree = AddPrototyperTree
 
DoMethodHooks()