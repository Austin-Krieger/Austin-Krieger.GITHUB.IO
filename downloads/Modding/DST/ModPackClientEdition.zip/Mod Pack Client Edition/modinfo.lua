name = "Mod Pack Client Edition"
description = "Multiple Client Mods"
author = "ownsaucepimp"
version = "1.0.0"
forumthread = ""
icon_atlas = "modicon.xml"
icon = "modicon.tex"
dst_compatible = true
client_only_mod = true
all_clients_require_mod = false

api_version = 10

configuration_options =
{
    -- Minimap HUD
    {
        name = "Minimap Size",
        options =
        {
            {description = "Tiny", data = 0.125},
            {description = "Small", data = 0.175},
            {description = "Medium", data = 0.225},
            {description = "Large", data = 0.275},
            {description = "Huge", data = 0.325},
            {description = "Giant", data = 0.375},
        },
        default = 0.225,
    },
    {
        name = "Position",
        options =
        {
            {description = "Top Right", data = "top_right"},
            {description = "Top Left", data = "top_left"},
            {description = "Top Center", data = "top_center"},
            {description = "Middle Left", data = "middle_left"},
            {description = "Middle Center", data = "middle_center"},
            {description = "Middle Right", data = "middle_right"},
            {description = "Bottom Left", data = "bottom_left"},
            {description = "Bottom Center", data = "bottom_center"},
            {description = "Bottom Right", data = "bottom_right"},
        },
        default = "top_right"
    },
    {
        name = "Horizontal Margin",
        options =
        {
            {description = "None", data = 0},
            {description = "Very Tiny", data = 5},
            {description = "Tiny", data = 12.5},
            {description = "Very Small", data = 25},
            {description = "Small", data = 50},
            {description = "Medium", data = 125},
            {description = "Large", data = 235},
            {description = "Huge", data = 350},
            {description = "Giant", data = 450},
        },
        default = 235
    },
    {
        name = "Vertical Margin",
        options =
        {
            {description = "None", data = 0},
            {description = "Very Tiny", data = 5},
            {description = "Tiny", data = 12.5},
            {description = "Very Small", data = 25},
            {description = "Small", data = 50},
            {description = "Medium", data = 125},
            {description = "Large", data = 235},
            {description = "Very Large", data = 300},
            {description = "Huge", data = 350},
            {description = "Giant", data = 450},
        },
        default = 25
    },
    {
        name = "Updates Per Second",
        label = "Update throttling",
        hover = "Minimap's throttled updates per second, can help with FPS issues",
        options =
        {
            {description = "Default", data = 0, hover = "Throttling disabled, always keep map up-to-date"},
            {description = "10 ups", data = 0.1, hover = "Update the map 10 times per second"},
            {description = "8 ups", data = 0.125, hover = "Update the map 8 times per second"},
            {description = "6 ups", data = 0.166, hover = "Update the map 6 times per second"},
            {description = "5 ups", data = 0.20, hover = "Update the map 5 times per second"},
            {description = "4 ups", data = 0.25, hover = "Update the map 4 times per second"},
            {description = "3 ups", data = 0.333, hover = "Update the map 3 times per second"},
            {description = "2 ups", data = 0.5, hover = "Update the map 2 times per second"},
            {description = "1 ups", data = 1, hover = "Update the map every second"},
            {description = "4/5 ups", data = 1.25, hover = "Update the map 4 times in 5 seconds"},
            {description = "2/3 ups", data = 1.5, hover = "Update the map 2 times in 3 seconds"},
            {description = "1/2 ups", data = 2, hover = "Update the map every 2 seconds"},
            {description = "1/3 ups", data = 3, hover = "Update the map every 3 seconds"},
            {description = "1/4 ups", data = 4, hover = "Update the map every 4 seconds"},
            {description = "1/5 ups", data = 5, hover = "Update the map every 5 seconds"},
            {description = "1/6 ups", data = 6, hover = "Update the map every 6 seconds"},
            {description = "1/8 ups", data = 8, hover = "Update the map every 8 seconds"},
            {description = "1/10 ups", data = 10, hover = "Update the map every 10 seconds"},
            {description = "1/30 ups", data = 30, hover = "Update the map every 30 seconds"},
        },
        default = 0
    },
    -- Item Info
    {
        name = "INFO_SCALE",
        label = "Info scale",
        hover = "Sets the tooltips' info scale",
        options =   ScaleValues,
        default = 0.8,
    },
    {
        name = "TIME_FORMAT",
        label = "Time format",
        hover = "Set the display time format",
        options =   {
                        {description = "Hours", data = 0},
                        {description = "Days", data = 1},
                    },
        default = 0,
    },
    {
        name = "PERISHABLE",
        label = "Perish info",
        hover = "Set the way you want to see the stale and perish timer",
        options =   {
                        {description = "Perish only", data = 0},
                        {description = "Stale>perish", data = 1},
                        {description = "Both", data = 2},
                    },
        default = 2,
    },
    {
        name = "SHOW_INFO_HANDS",
        label = "Show hands",
        hover = "Set to Yes if you want to see your hands equipped item info",
        options =   {
                        {description = "Yes", data = true},
                        {description = "No", data = false},
                    },
        default = true,
    },
    {
        name = "SHOW_INFO_BODY",
        label = "Show body",
        hover = "Set to Yes if you want to see your body equipped item info",
        options =   {
                        {description = "Yes", data = true},
                        {description = "No", data = false},
                    },
        default = true,
    },
    {
        name = "SHOW_INFO_HEAD",
        label = "Show head",
        hover = "Set to Yes if you want to see your head equipped item info",
        options =   {
                        {description = "Yes", data = true},
                        {description = "No", data = false},
                    },
        default = true,
    },
    {
        name = "EQUIP_SCALE",
        label = "Equipped scale",
        hover = "Sets the equipped item info scale. This doesn't affects the tooltips",
        options =   ScaleValues,
        default = 0.5,
    },
    {
        name = "SHOW_PREFABNAME",
        label = "Prefab name",
        hover = "Set to Yes if you want to display the item's prefab",
        options =   {
                        {description = "Yes", data = true},
                        {description = "No", data = false},
                    },
        default = false,
    },
    {
        name = "SHOW_BACKGROUND",
        label = "Show background",
        hover = "Set to Yes if you want to see a background behind your equipped item's info",
        options =   {
                        {description = "Yes", data = true},
                        {description = "No", data = false},
                    },
        default = false,
    },
    {
        name = "HORIZONTAL_MARGIN",
        label = "Bottom Margin",
        hover = "Set the equip info bottom margin",
        options =   MarginValues,
        default = 100,
    },
    {
        name = "VERTICAL_MARGIN",
        label = "Right Margin",
        hover = "Set the equip info right margin",
        options =   MarginValues,
        default = 100,
    },
}