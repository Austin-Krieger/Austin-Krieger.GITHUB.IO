-- Craftable Living Logs
STRINGS = GLOBAL.STRINGS
RECIPETABS = GLOBAL.RECIPETABS
Recipe = GLOBAL.Recipe
Ingredient = GLOBAL.Ingredient
TECH = GLOBAL.TECH

local living_log = GLOBAL.Recipe("livinglog", {Ingredient("log", 1),Ingredient("nightmarefuel", 1) }, RECIPETABS.REFINE, TECH.MAGIC_TWO )
STRINGS.RECIPE_DESC.LIVINGLOG = "Shove your inner demons into this wood."

-- Extended Indicators
local MaxIndicator = GetModConfigData("MaxIndicator")
local IndicatorSize = GetModConfigData("IndicatorSize")
local PlayerIndicators = GetModConfigData("PlayerIndicators")

GLOBAL.TUNING.MIN_INDICATOR_RANGE = 0
GLOBAL.TUNING.MAX_INDICATOR_RANGE = MaxIndicator

local iconScale
local arrowScale

if PlayerIndicators == 1 then
    if IndicatorSize == 1 then --Tiny
        iconScale = 0.4
        arrowScale = 0.25
    elseif IndicatorSize ==2 then --Small
        iconScale = 0.55
        arrowScale = 0.3
    elseif IndicatorSize == 3 then --Medium
        iconScale = 0.7
        arrowScale = 0.35
    else --Large
        iconScale = 0.8
        arrowScale = 0.4
    end
else --Disable the player indicators
    iconScale = 0
    arrowScale = 0
end

local function TargetIndicator(self, owner, target)
    self.icon:SetScale(iconScale)
    self.arrow:SetScale(arrowScale)
end

AddClassPostConstruct("widgets/targetindicator", TargetIndicator)

-- Larger Campfire Collisions
function setNewTemp(self)
    if GLOBAL.TheWorld.ismastersim and GetModConfigData("change_"..self.prefab) then
        
        local sz_delta = ((type(GetModConfigData("change_"..self.prefab)) == "number" and (GetModConfigData("change_"..self.prefab)))
        or (((GetModConfigData("change_"..self.prefab) == "max") 
                and (((self.components.heater.endothermic)
                and (math.max(((type(GetModConfigData("sz_coldfire")) == "number" and GetModConfigData("sz_coldfire")) or 0), ((type(GetModConfigData("sz_coldfirepit")) == "number" and GetModConfigData("sz_coldfirepit")) or 0)))) 
            or (math.max(((type(GetModConfigData("sz_campfire")) == "number" and GetModConfigData("sz_campfire")) or 0), ((type(GetModConfigData("sz_firepit")) == "number" and GetModConfigData("sz_firepit")) or 0)))))
        or (((self.components.heater.endothermic)
                and (math.min(((type(GetModConfigData("sz_coldfire")) == "number" and GetModConfigData("sz_coldfire")) or 0), ((type(GetModConfigData("sz_coldfirepit")) == "number" and GetModConfigData("sz_coldfirepit")) or 0))))
            or (math.min(((type(GetModConfigData("sz_campfire")) == "number" and GetModConfigData("sz_campfire")) or 0), ((type(GetModConfigData("sz_firepit")) == "number" and GetModConfigData("sz_firepit")) or 0))))))
        sz_delta = sz_delta - .3

        local temp_mult = ((type(GetModConfigData("temp_mult") == "number") and GetModConfigData("temp_mult")) or 1)/(1-(sz_delta*sz_delta)/100)

        local oldHeatFn = self.components.heater.heatfn
        self.components.heater.heatfn = function(inst)
            return oldHeatFn(inst)*temp_mult
        end
    end
end
    
function setNewCapsule(self)
    if GLOBAL.TheWorld.ismastersim then
        local newrad = GetModConfigData("sz_"..self.prefab)
        if type(newrad) == "number" then
            self.entity:AddPhysics():SetCapsule(newrad, 2)
        end
    end
end

AddPrefabPostInit("firepit", setNewCapsule)
AddPrefabPostInit("campfire", setNewCapsule)
AddPrefabPostInit("coldfire", setNewCapsule)
AddPrefabPostInit("coldfirepit", setNewCapsule)

AddPrefabPostInit("campfirefire", setNewTemp)
AddPrefabPostInit("coldfirefire", setNewTemp)

-- No Thermal Stone Durability
local old_TemperatureChange
local old_heatrock_fn

local function new_TemperatureChange(inst, data)
    inst.components.fueled = {
        GetPercent = function() return 1 end,
        SetPercent = function() end,
    }
    old_TemperatureChange(inst, data)
    inst.components.fueled = nil
end

local function new_heatrock_fn(inst)
    if GLOBAL.TheWorld.ismastersim then
        inst:RemoveComponent("fueled")

        local function switchListenerFns(t)
            local listeners = t["temperaturedelta"]
            local listener_fns = listeners[inst]
            old_TemperatureChange = listener_fns[1]
            listener_fns[1] = new_TemperatureChange
        end

        switchListenerFns(inst.event_listeners)
        switchListenerFns(inst.event_listening)
    end
end

AddPrefabPostInit("heatrock", new_heatrock_fn)

-- Gold Survival Kit
TUNING.ARMOR_GOLD = GetModConfigData("ARMOR_LIFE")              -- Hit points
TUNING.ARMOR_GOLD_ABSORPTION = GetModConfigData("ARMOR_ABSORB")     -- Damage absorbtion
TUNING.SWORD_GOLD_USES = GetModConfigData("SWORD_LIFE")
TUNING.SWORD_GOLD_DAMAGE = GetModConfigData("SWORD_DAMAGE")
TUNING.HAT_GOLD = GetModConfigData("HAT_LIFE") 
TUNING.HAT_GOLD_ABSORBTION = GetModConfigData("HAT_ABSORB") 
HAT_MISS = GetModConfigData("HAT_MISS")
PrefabFiles = {
  "armor_gold",
  "sword_gold",
  "hat_gold",
 }

GLOBAL.STRINGS.NAMES.ARMOR_GOLD = "Gold Armor"
STRINGS.RECIPE_DESC.ARMOR_GOLD = "An armor made of gold"
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.ARMOR_GOLD = "I'm rich"

GLOBAL.STRINGS.NAMES.SWORD_GOLD = "Gold Sword"
STRINGS.RECIPE_DESC.SWORD_GOLD = "Mob clearing tool"
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.SWORD_GOLD = "Now thats a weapon"

GLOBAL.STRINGS.NAMES.HAT_GOLD = "Gold Helmet"
STRINGS.RECIPE_DESC.HAT_GOLD = "Something to protect my precious brain"
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.HAT_GOLD = "I feel protected"

AddRecipe("hat_gold", { Ingredient("footballhat", 1), Ingredient("rope", 2), Ingredient("goldnugget", 6)}, RECIPETABS.WAR,  TECH.SCIENCE_TWO, nil, nil, nil, nil, nil, "images/inventoryimages/hat_gold.xml", "hat_gold.tex")
AddRecipe("armor_gold", { Ingredient("rope", 4), Ingredient("pigskin", 3), Ingredient("goldnugget", 8)}, RECIPETABS.WAR,  TECH.SCIENCE_TWO, nil, nil, nil, nil, nil, "images/inventoryimages/armor_gold.xml", "armor_gold.tex")
AddRecipe("sword_gold", { Ingredient("log", 2), Ingredient("rope", 4), Ingredient("goldnugget", 6)}, RECIPETABS.WAR,  TECH.SCIENCE_TWO, nil, nil, nil, nil, nil, "images/inventoryimages/sword_gold.xml", "sword_gold.tex")

do
    local MISS_CHANCE = HAT_MISS
    local inventory = GLOBAL.require "components/inventory"
    local old_ApplyDamage = inventory.ApplyDamage
    function inventory:ApplyDamage(damage,...)
        local armor = self:GetEquippedItem(GLOBAL.EQUIPSLOTS.BODY)
        if hat and hat.prefab=="hat_gold" and math.random() < MISS_CHANCE then
            return 0
        end
        return  old_ApplyDamage(self,damage,...)
    end 
end
-- Change Character
GLOBAL.KEYCODE = GetModConfigData("keycodep")

local function ChangeCharacter(player)
    local world = GLOBAL.TheWorld
    if not player.sg:HasStateTag("busy") then
        player.components.inventory:DropEverything(true)
        world:PushEvent("ms_playerdespawnanddelete", player) 
    end
    
end 

AddModRPCHandler(modname, "ChangeCharacter", ChangeCharacter)

local function SendChangeCharacterRPC() 
    SendModRPCToServer(MOD_RPC[modname]["ChangeCharacter"])
end

GLOBAL.TheInput:AddKeyDownHandler(GLOBAL.KEYCODE, function()
local player = GLOBAL.ThePlayer

if player and not player.HUD:IsChatInputScreenOpen() and not player.HUD:IsConsoleScreenOpen() and not player.HUD.writeablescreen then
 
 SendModRPCToServer(MOD_RPC[modname]["ChangeCharacter"])
 end 
 end)