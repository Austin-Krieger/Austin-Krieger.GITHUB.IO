name = "Mod Pack III"
description = "Multiple Mods Part III"
author = "ownsaucepimp"
version = "1.0.0"
forumthread = ""
api_version = 10
dst_compatible = true
dont_starve_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
    -- Extended Indicators
    {
        name = "PlayerIndicators",
        label = "Player Indicators",
        options =   {
                        {description = "Enabled", data = 1},
                        {description = "Disabled", data = 2},
                    },
        default = 1,
    },
    {
        name = "IndicatorSize",
        label = "Indicator Size",
        options =   {
                        {description = "Tiny", data = 1},
                        {description = "Small", data = 2},
                        {description = "Medium", data = 3},
                        {description = "Large", data = 4},
                    },
        default = 3,
    },
    {
        name = "MaxIndicator",
        label = "Max Indicator Range",
        options =   {
                        {description = "Original", data = 50},
                        {description = "Double", data = 100},
                        {description = "Huge", data = 250},
                        {description = "Unlimited", data = 7000},
                    },
        default = 7000,
    },
    -- Larger Campfire Collisions
    {
        name = "sz_campfire",
        label = "Campfire Size",
        options = {
            {description = "0.2 (default)", data = "default"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = 1,
    },
    {
        name = "sz_coldfire",
        label = "Coldfire Size",
        options = {
            {description = "0.3 (default)", data = "default"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = 1,
    },
    {
        name = "sz_firepit",
        label = "Firepit Size",
        options = {
            {description = "0.3 (default)", data = "default"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = 1,
    },
    {
        name = "sz_coldfirepit",
        label = "Coldfirepit Size",
        options = {
            {description = "0.3 (default)", data = "default"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = 1,
    },
    {
        name = "change_campfirefire",
        label ="Compensate Hot",
        options = {
            {description = "No", data = false},
            {description = "Min size", data = "min"},
            {description = "Max size", data = "max"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = false,
    },  
    {
        name = "change_coldfirefire",
        label = "Compensate Cold",
        options = {
            {description = "No", data = false},
            {description = "Min size", data = "min"},
            {description = "Max size", data = "max"},
            {description = "0.5", data = .5},
            {description = "0.7", data = .7},
            {description = "1.0", data = 1},
            {description = "1.5", data = 1.5},
            {description = "2.0", data = 2},
        },
        default = false,
    },
    {
        name = "temp_mult",
        label = "xHeat (not recommended)",
        options = {
            {description = "None", data = false},
            {description = "1.1", data = 1.1},
            {description = "1.2", data = 1.2},
            {description = "1.3", data = 1.3},
            {description = "1.4", data = 1.4},
            {description = "1.5", data = 1.5},
            {description = "1.7", data = 1.7},
            {description = "2.0", data = 2},
            {description = "2.5", data = 2.5},
            {description = "3.0", data = 3},
        },
        default = false,
    },
    -- Gold Survival Kit
    {
        name = "SWORD_DAMAGE",
        label = "Change sword's damage",
        options =   {
                        {description = "50", data = 50},
                        {description = "75", data = 75},
                        {description = "100", data = 100},
                        {description = "125", data = 125},
                        {description = "150", data = 150},
                        {description = "175%", data = 175},
                        {description = "200%", data = 200},
                        {description = "250%", data = 250},
                    },

        default = 250,
    },
    {
        name = "SWORD_LIFE",
        label = "Change swords's uses",
        options =   {
                        {description = "250", data = 250},
                        {description = "500", data = 500},
                        {description = "750", data = 750},
                        {description = "1000", data = 1000},
                        {description = "1250", data = 1250},
                        {description = "1500", data = 1500},
                        {description = "2000", data = 2000},
                    },

        default = 2000,
    },
    {
        name = "ARMOR_LIFE",
        label = "Change armor's life",
        options =   {
                        {description = "250", data = 250},
                        {description = "500", data = 500},
                        {description = "750", data = 750},
                        {description = "1000", data = 1000},
                        {description = "1250", data = 1250},
                        {description = "1500", data = 1500},
                        {description = "2000", data = 2000},
                    },

        default = 2000,
    },
    {
        name = "ARMOR_ABSORB",
        label = "Change armor's damage absobtion",
        options =   {
                        {description = "70%", data = 0.7},
                        {description = "75%", data = 0.75},
                        {description = "80%", data = 0.8},
                        {description = "85%", data = 0.85},
                        {description = "90%", data = 0.90},
                        {description = "95%", data = 0.95},
                        {description = "99%", data = 0.99},
                    },

        default = 0.99,
    },
    {
        name = "HAT_LIFE",
        label = "Change helmet's life",
        options =   {
                        {description = "250", data = 250},
                        {description = "500", data = 500},
                        {description = "750", data = 750},
                        {description = "1000", data = 1000},
                        {description = "1250", data = 1250},
                        {description = "1500", data = 1500},
                        {description = "2000", data = 2000},
                    },

        default = 2000,
    },
    {
        name = "HAT_ABSORB",
        label = "Change helmet's damage absobtion",
        options =   {
                        {description = "70%", data = 0.7},
                        {description = "75%", data = 0.75},
                        {description = "80%", data = 0.8},
                        {description = "85%", data = 0.85},
                        {description = "90%", data = 0.90},
                        {description = "95%", data = 0.95},
                        {description = "99%", data = 0.99},
                    },

        default = 0.99,
    },
    {
        name = "HAT_MISS",
        label = "Change helmet's miss feature",
        options =   {
                        {description = "5%", data = 0.05},
                        {description = "10%", data = 0.10},
                        {description = "15%", data = 0.15},
                        {description = "20%", data = 0.2},
                        {description = "30%", data = 0.3},
                        {description = "40%", data = 0.4},
                        {description = "50%", data = 0.5},
                        {description = "60%", data = 0.6},
                        {description = "70%", data = 0.7},
                        {description = "80%", data = 0.8},
                        {description = "90%", data = 0.9},
                    },

        default = 0.15,
    },
    -- Change Character
    {
        name = "keycodep",
        label = "Button",
        options = 
        {
            {description = "← Backspace", data = 8, hover = "Press Backspace for despawn."},
            {description = "\\", data = 92, hover = "Press Backslash for despawn."},
            {description = "O", data = 111, hover = "Press O for despawn."},
            {description = "P", data = 112, hover = "Press P for despawn."},
            {description = "V", data = 118, hover = "Press V for despawn."},
            {description = "X", data = 120, hover = "Press X for despawn."},
            {description = "Z", data = 122, hover = "Press Z for despawn."},
            {description = "R", data = 82, hover = "Press R for respawn."},
        },
        default = 112,
    },
}