local assets = {
	Asset("ANIM", "anim/arm_upper_armor.zip"),
    Asset("ANIM", "anim/armor_gold.zip"),
    Asset("ATLAS", "images/inventoryimages/armor_gold.xml"),
    Asset("IMAGE", "images/inventoryimages/armor_gold.tex"),
}

local prefabs = {
}

local function OnBlocked(owner) 
    owner.SoundEmitter:PlaySound("dontstarve/wilson/hit_armour") 
end

local function onequip(inst, owner) 
   owner.AnimState:OverrideSymbol("swap_body", "armor_gold", "armor_gold")
	owner.AnimState:OverrideSymbol("arm_upper", "arm_upper_armor", "arm_upper_armor")
 
    inst:ListenForEvent("blocked", OnBlocked, owner)
	owner.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
end

local function onunequip(inst, owner) 
    owner.AnimState:ClearOverrideSymbol("swap_body")
	owner.AnimState:ClearOverrideSymbol("arm_upper")
    inst:RemoveEventCallback("blocked", OnBlocked, owner)
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("armor_gold")
    inst.AnimState:SetBuild("armor_gold")
    inst.AnimState:PlayAnimation("anim")

	inst:AddTag("golden")
    

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/armor_gold.xml"

    inst:AddComponent("armor")
    inst.components.armor:InitCondition(TUNING.ARMOR_GOLD, TUNING.ARMOR_GOLD_ABSORPTION)
	
	inst:AddComponent("waterproofer")
    inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_MED)  -- 50%
	
	inst:AddComponent("insulator")
        inst.components.insulator:SetSummer()
        inst.components.insulator:SetInsulation(TUNING.INSULATION_SMALL)     -- Gives small protection against direct sun (Duration:1/8 of a day)
		inst.components.insulator:SetWinter()
		inst.components.insulator:SetInsulation(TUNING.INSULATION_LARGE)     -- Wool and pigskin(~leather) give good isolation against the cold. (Duration:half of a day)

    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("common/inventory/armor_gold", fn, assets, prefabs)
